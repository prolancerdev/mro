from rest_framework import serializers
from .models import BrowseStep

class BrowseStepSerializer(serializers.ModelSerializer):
    class Meta:
        model = BrowseStep
        fields = ['id', 'run', 'name', 'notes', 'exception', 'screenshot', 'html_source', 'timestamp_added', 'timestamp_modified']

    def create(self, validated_data):
        # Create new BrowseStep instance
        return BrowseStep.objects.create(**validated_data)
