from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view, parser_classes
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from rest_framework.response import Response
from .models import BrowseStep, Run, Task
from penpal.models import PenPal
from .serializers import BrowseStepSerializer  # You'll create this next

from django.http import JsonResponse
import redis
import json


def extract_single_values(data):
    """Extract single values from QueryDict or dictionary."""
    new_data = {}
    for key, value in data.items():
        # Extract the first item if it's a list, otherwise just assign the value
        new_data[key] = value[0] if isinstance(value, list) else value
    return new_data


@csrf_exempt
@api_view(['POST'])
@parser_classes((MultiPartParser, FormParser))
def save_browse_step(request):
    request_data = extract_single_values(request.data)

    try:
        run_id = request_data.get('run')
        run = Run.objects.get(id=run_id)
    except Run.DoesNotExist:
        return Response({'error': 'Run not found'}, status=404)

    serializer = BrowseStepSerializer(data=request_data, context={'run': run})
    if serializer.is_valid():
        serializer.save(run=run)
        return Response(serializer.data, status=201)
    else:
        return Response(serializer.errors, status=400)

@csrf_exempt
@api_view(['POST'])
@parser_classes([JSONParser])
def create_run(request):
    penpal_id = request.data.get('penpal_id')
    if not penpal_id:
        return Response({'error': 'Penpal ID is required'}, status=400)

    try:
        penpal = PenPal.objects.get(id=penpal_id)
    except PenPal.DoesNotExist:
        return Response({'error': 'PenPal not found'}, status=404)

    run = Run.objects.create(penpal=penpal)
    # from penpal.notify import send_simple_message
    # send_simple_message("NEW RUN - Penpal {}".format(penpal.id))
    return Response({'run_id': run.id}, status=201)


@api_view(['PUT'])
def update_task_status(request, penpal_id, task_id):
    # Try to get the specified task and penpal
    try:
        penpal = PenPal.objects.get(id=penpal_id)
        task = Task.objects.get(id=task_id, penpal=penpal)
    except (PenPal.DoesNotExist, Task.DoesNotExist):
        return Response({'error': 'Task or PenPal not found'}, status=404)

    # Update the 'status' field if it's in the request
    status = request.data.get('status')
    # if status and int(status) == 4:
    #     from penpal.notify import send_simple_message
    #     send_simple_message("COMPLETED RUN - Penpal {}".format(penpal.id))

    if status in dict(Task.STATUS_CHOICES).keys():
        task.status = status
        task.save()
    else:
        return Response({'error': 'Invalid status value'}, status=400)

    # Respond with the updated task data
    return Response({'task_id': task.id, 'status': task.status})


@csrf_exempt  # If you're not using CSRF tokens for this API
def get_task(request):
    r = redis.Redis.from_url(settings.REDIS_URL)  # Use your Heroku REDIS_URL
    queue_name = 'task_queue_list'  # Make sure this matches your list_name in the push method

    task_data_str = r.rpop(queue_name)  # Pop a task from the right side of the list

    if task_data_str:
        task_data_str = task_data_str.decode('utf-8')
        task = json.loads(task_data_str)
        return JsonResponse({'status': 'success', 'task': task})
    else:
        return JsonResponse({'status': 'no_task'})
