from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from .models import PenPal, Task
from unittest.mock import patch

class TaskUpdateTest(APITestCase):
    def setUp(self):
        self.penpal = PenPal.objects.create(first_name="Test Penpal")
        self.task = Task.objects.create(
            penpal=self.penpal,
            status=1,
            run_time=None
        )

    @patch('penpal.notify.send_simple_message')
    def test_update_task_status(self, send_simple_message):
        # Define the URL for updating the task
        url = reverse('update_task_status', args=[self.penpal.id, self.task.id])
        
        # Define the new status to update
        new_status = 2
        data = {'status': new_status}
        
        # Make the PUT request
        response = self.client.put(url, data, format='json')
        
        # Check that the response status code is 200 (OK)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Check the response content
        response_data = response.json()
        self.assertEqual(response_data['task_id'], self.task.id)
        self.assertEqual(response_data['status'], new_status)

        # Optionally, reload the task from the database and check the field has been updated
        self.task.refresh_from_db()
        self.assertEqual(self.task.status, new_status)



    @patch('penpal.notify.send_simple_message')
    def test_update_task_status(self, send_simple_message):
        # Define the URL for updating the task
        url = reverse('update_task_status', args=[self.penpal.id, self.task.id])
        
        # Define the new status to update
        new_status = 4
        data = {'status': new_status}
        
        # Make the PUT request
        response = self.client.put(url, data, format='json')
        
        # Check that the response status code is 200 (OK)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Check the response content
        response_data = response.json()
        self.assertEqual(response_data['task_id'], self.task.id)
        self.assertEqual(response_data['status'], new_status)

        # Optionally, reload the task from the database and check the field has been updated
        self.task.refresh_from_db()
        self.assertEqual(self.task.status, new_status)