import requests
from requests_toolbelt.multipart.encoder import MultipartEncoder

# Replace these variables with your actual data
run_id = '13'
name = 'test step'
notes = 'some notes'
html_source = '<html>...</html>'  # Your actual HTML content here
screenshot_path = 'beforeloadpotentially.png'  # Path to your screenshot file

# URL of your Django API endpoint
url = 'http://localhost:8000/api/save_browse_step/'

# Prepare the data for the POST request
multipart_data = MultipartEncoder(
    fields={
        'run': run_id,
        'name': name,
        'notes': notes,
        'html_source': html_source,
        # Use 'filename' for the screenshot to tell the server a file is being uploaded
        'screenshot': ('screenshot.png', open(screenshot_path, 'rb'), 'image/png')
    }
)

# Make the POST request
response = requests.post(url, data=multipart_data, headers={'Content-Type': multipart_data.content_type})

# Print out the response from the server
print(response.status_code)
print(response.json())
