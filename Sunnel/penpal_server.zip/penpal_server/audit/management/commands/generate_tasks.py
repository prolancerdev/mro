from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
import random
import pytz
from penpal.models import PenPal
from audit.models import Task

class Command(BaseCommand):
    help = 'Generate tasks for each PenPal until midnight Eastern Time'

    def handle(self, *args, **options):
        # Time zone definitions
        utc = pytz.timezone('UTC')
        eastern = pytz.timezone('America/New_York')

        # Current time in UTC and Eastern Time
        now_utc = timezone.now().astimezone(utc)
        now_eastern = now_utc.astimezone(eastern)
        # Midnight in Eastern Time for the current day
        midnight_eastern = now_eastern.replace(hour=23, minute=59, second=59, microsecond=0)
        midnight_utc = midnight_eastern.astimezone(utc)

        penpals = PenPal.objects.all()

        for penpal in penpals:
            run_time_utc = now_utc
            while run_time_utc < midnight_utc:
                interval = timedelta(minutes=random.randint(20, 40))
                run_time_utc += interval  # Scheduling in UTC

                # Check against midnight in Eastern Time but using UTC for comparison
                if run_time_utc > midnight_utc:
                    break

                Task.objects.create(
                    penpal=penpal, 
                    run_time=run_time_utc,  # Store in UTC
                    status=1  # Assuming status=1 is 'Not Started'
                )
                self.stdout.write(self.style.SUCCESS(f'Successfully created task for {penpal} at {run_time_utc.astimezone(eastern)}'))

        self.stdout.write(self.style.SUCCESS('Successfully created all tasks'))
