from django.core.management.base import BaseCommand
from django.utils import timezone
from django.db.models import Max
from penpal.models import PenPal
from audit.models import Task


class Command(BaseCommand):
    help = 'Process the latest unstarted task per penpal where the run_time has passed and mark prior tasks as defunct'

    def handle(self, *args, **options):
        now = timezone.now()
        penpals = PenPal.objects.all()

        for penpal in penpals:
            # Find the latest task for each penpal that is not yet pushed and whose run time has passed
            latest_task = Task.objects.filter(
                penpal=penpal, status=1, run_time__lt=now
            ).order_by('-run_time').first()

            if latest_task:
                # Mark all other 'Not Pushed' tasks for this penpal as 'Defunct'
                Task.objects.filter(
                    penpal=penpal, status=1, run_time__lt=latest_task.run_time
                ).exclude(id=latest_task.id).update(status=5)

                # Update the latest task to 'Pushed But Not Started'
                latest_task.status = 2  # 'Pushed But Not Started'
                print("pushing to redis queue!")
                latest_task.push_to_redis_queue()
                print("pushed to redis queue!")
                latest_task.save()
                self.stdout.write(self.style.SUCCESS(f'Updated task {latest_task.id} for {penpal} to "Pushed But Not Started" and marked previous tasks as defunct'))

        self.stdout.write(self.style.SUCCESS('Completed processing tasks'))
