from django.contrib import admin
from .models import Run, BrowseStep, Task
from django.utils.html import mark_safe

@admin.register(Run)
class RunAdmin(admin.ModelAdmin):
    list_display = ('penpal', 'timestamp_added', 'timestamp_modified')
    list_filter = ('penpal', 'timestamp_added')
    search_fields = ('penpal__name',)  # Assuming PenPal has a 'name' field. Adjust as necessary.


@admin.register(BrowseStep)
class BrowseStepAdmin(admin.ModelAdmin):
    list_display = ('name', 'notes', 'run', 'timestamp_added', 'timestamp_modified')
    list_filter = ('run', 'timestamp_added')
    search_fields = ('name', 'notes', 'exception')
    readonly_fields = ('screenshot_preview',)

    fieldsets = (
        (None, {
            'fields': ('run', 'name', 'notes', 'exception')
        }),
        ('Details', {
            'fields': ('html_source', 'screenshot', 'screenshot_preview'),
            'classes': ('collapse',),
        }),
    )

    def screenshot_preview(self, obj):
        if obj.screenshot:
            return mark_safe(f'<img src="{obj.screenshot.url}" width="150" height="auto" />')
        return "No Image"
    screenshot_preview.short_description = 'Screenshot Preview'


@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('penpal', 'date_created', 'last_modified', 'run_time', 'status')
    list_filter = ('status', 'date_created', 'last_modified')
    search_fields = ('penpal__name',)
    ordering = ('-date_created',)
    actions = ['push_tasks_to_redis_queue']

    def push_tasks_to_redis_queue(self, request, queryset):
        for task in queryset:
            result = task.push_to_redis_queue()
            if result:
                self.message_user(request, f"Task {task.id} successfully pushed to Redis queue.")
            else:
                self.message_user(request, f"Task {task.id} is already in the Redis queue.")

    push_tasks_to_redis_queue.short_description = "Push selected tasks to Redis queue"
