import redis
from urllib.parse import urlparse
from django.conf import settings

from django.db import models
# Adjust the import path according to your project structure
from penpal.models import PenPal
from penpal.storage_backends import PrivateMediaStorage


class Run(models.Model):
    penpal = models.ForeignKey(
        PenPal, on_delete=models.CASCADE, related_name='runs')
    timestamp_added = models.DateTimeField(auto_now_add=True)
    timestamp_modified = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Run for {self.penpal} at {self.timestamp_added}"


class BrowseStep(models.Model):
    run = models.ForeignKey(Run, on_delete=models.CASCADE,
                            related_name='browse_steps')
    name = models.CharField(max_length=255, null=True, blank=True)
    notes = models.TextField(blank=True, null=True)
    exception = models.TextField(blank=True, null=True)
    screenshot = models.ImageField(
        storage=PrivateMediaStorage(), blank=True, null=True)
    html_source = models.TextField(blank=True, null=True)
    timestamp_added = models.DateTimeField(auto_now_add=True)
    timestamp_modified = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name} on Run {self.run.id}"


class Task(models.Model):
    STATUS_CHOICES = (
        (1, 'Not Pushed'),
        (2, 'Pushed But Not Started'),
        (3, 'Processing'),
        (4, 'Completed'),
        (5, 'Defunct'),
    )

    # Foreign Key linking to PenPal
    penpal = models.ForeignKey(
        PenPal, on_delete=models.CASCADE, related_name='tasks')

    # Date fields
    run_time = models.DateTimeField(null=True, blank=True)
    date_created = models.DateTimeField(auto_now_add=True)
    last_modified = models.DateTimeField(auto_now=True)

    # Status field
    status = models.IntegerField(choices=STATUS_CHOICES, default=1)

    def push_to_redis_queue(self):
        # Parse the Heroku REDIS_URL to get connection parameters
        redis_url = settings.REDIS_URL
        url = urlparse(redis_url)
        red_instance = redis.Redis(host=url.hostname, port=url.port,
                                   password=url.password, ssl=True, ssl_cert_reqs=None)

        # Construct the task data
        task_data = {
            'task_id': self.id,
            'penpal_id': self.penpal_id
        }
        import json

        # Inside your push_to_redis_queue method or wherever you're adding to Redis:
        task_data_json = json.dumps(task_data)

        # Queue name
        queue_name = 'task_queue'
        list_name = f"{queue_name}_list"  # For the queue
        # Push the task data to the Redis list (queue)
        red_instance.rpush(list_name, task_data_json)
        self.status = 2
        self.save()
        return True

    def __str__(self):
        return f"Task for {self.penpal} Status: {self.get_status_display()}"
