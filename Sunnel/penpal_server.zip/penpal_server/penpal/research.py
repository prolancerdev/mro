"""
def clean_up_strings(list_of_strings):
    cleaned_strings = []
    for string in list_of_strings:
        # Strip leading and trailing whitespace and quotation marks
        cleaned_string = string.strip().strip('"')
        # Replace unnecessarily escaped single quotes
        cleaned_string = cleaned_string.replace("\\'", "'")
        cleaned_strings.append(cleaned_string)
    return cleaned_strings

queries = clean_up_strings(res_2['text'].split('\n'))

answer_data = []

from langchain.agents import create_openai_functions_agent

from langchain.agents import load_tools
tools = load_tools(["serpapi"])

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are very powerful research assistant",
        ),
        ("user", "Find me the answer to: {query}"),
        MessagesPlaceholder(variable_name="agent_scratchpad"),
    ]
)

llm_with_tools = llm.bind_tools(tools)
from langchain.agents.format_scratchpad.openai_tools import (
    format_to_openai_tool_messages,
)
from langchain.agents.output_parsers.openai_tools import OpenAIToolsAgentOutputParser

from langchain import SerpAPIWrapper

from langchain.agents import AgentExecutor, create_react_agent, Tool
from langchain.agents import AgentType
from langchain.chat_models import ChatOpenAI

search = SerpAPIWrapper()
tools = [
    Tool(
        name = "Search",
        func=search.run,
        description="useful for when you need to answer questions about current events or real-time data or external information."),
]
from langchain import hub
prompt = hub.pull("hwchase17/react")
agent = create_react_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

for query in queries:
    print("Original Query")
    print(query)
    result = query_optimizer_chain.invoke({"user_query": query})
    optimized_query = result['text']
    clean_query = optimized_query.replace("Optimized Query:", "").strip()
    print("Clean Query")
    print(clean_query)
    try:
        res = agent_executor.invoke({"input": "Find answer to: {}".format(clean_query)})
    except ValueError as e:
        print(e)
        output = "Error: Did not get a search result back..."
    else:
        output = res['output']
    answer_data.append([clean_query, output])

print(answer_data)


"""