from django.contrib import admin
from .models import Recipient, PenPal, Thread, Message

class RecipientAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'middle_name', 'last_name')
    search_fields = ('first_name', 'middle_name', 'last_name')

admin.site.register(Recipient, RecipientAdmin)

class PenPalAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email_address', 'timestamp_added', 'timestamp_modified')
    search_fields = ('first_name', 'last_name', 'email_address')
    list_filter = ('timestamp_added', 'timestamp_modified')

admin.site.register(PenPal, PenPalAdmin)

class ThreadAdmin(admin.ModelAdmin):
    list_display = ('recipient', 'penpal', 'starting_message')
    search_fields = ('recipient__first_name', 'recipient__last_name', 'penpal__first_name', 'penpal__last_name')
    list_filter = ('penpal',)

admin.site.register(Thread, ThreadAdmin)

class MessageAdmin(admin.ModelAdmin):
    list_display = ('is_from_recipient', 'recipient', 'penpal', 'raw_subject_text', 'thread', 'timestamp_sent', 'timestamp_added', 'timestamp_modified', 'run', 'posted', 'answered', 'response_to')
    search_fields = ('recipient__first_name', 'recipient__last_name', 'penpal__first_name', 'penpal__last_name', 'subject_line', 'body')
    list_filter = ('timestamp_sent', 'timestamp_added', 'is_from_recipient')
    raw_id_fields = ('thread',)  # Improves performance for admin pages with many ForeignKey relationships

admin.site.register(Message, MessageAdmin)