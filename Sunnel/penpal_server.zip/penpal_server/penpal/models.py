import os
from cryptography.fernet import Fernet

from django.db import models
from django.conf import settings

import re
from django.utils.dateparse import parse_datetime
from datetime import datetime
import difflib


class Recipient(models.Model):
    first_name = models.CharField(max_length=255, null=True, blank=True)
    middle_name = models.CharField(max_length=255, null=True, blank=True)
    last_name = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class PenPal(models.Model):
    recipient = models.ForeignKey(
        Recipient, on_delete=models.CASCADE, null=True, blank=True)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email_address = models.EmailField()
    timestamp_added = models.DateTimeField(auto_now_add=True)
    timestamp_modified = models.DateTimeField(auto_now=True)

    encrypted_username = models.TextField(
        blank=True, null=True)  # Store encrypted username
    encrypted_password = models.TextField(
        blank=True, null=True)  # Store encrypted password

    @staticmethod
    def get_fernet():
        key = os.getenv('PENPAL_ENCRYPTION_KEY').encode()
        return Fernet(key)

    def set_credentials(self, username, password):
        f = self.get_fernet()
        self.encrypted_username = f.encrypt(username.encode()).decode()
        self.encrypted_password = f.encrypt(password.encode()).decode()
        self.save()

    def get_credentials(self):
        f = self.get_fernet()
        username = f.decrypt(self.encrypted_username.encode()).decode()
        password = f.decrypt(self.encrypted_password.encode()).decode()
        return username, password

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class Thread(models.Model):
    recipient = models.ForeignKey(
        Recipient, on_delete=models.CASCADE, related_name='threads')
    penpal = models.ForeignKey(
        PenPal, on_delete=models.CASCADE, related_name='threads')
    starting_message = models.ForeignKey(
        'Message', on_delete=models.CASCADE, related_name='starting_thread')

    def __str__(self):
        return f"Thread between {self.recipient} and {self.penpal} starting with {self.starting_message}"


class Message(models.Model):
    recipient = models.ForeignKey(
        Recipient, on_delete=models.CASCADE, related_name='messages_sent', null=True, blank=True)
    penpal = models.ForeignKey(PenPal, on_delete=models.CASCADE,
                               related_name='messages_received', null=True, blank=True)
    is_from_recipient = models.BooleanField(
        default=False, null=True, blank=True)
    approved = models.BooleanField(default=False, null=True, blank=True)
    full_text = models.TextField(null=True, blank=True)
    body = models.TextField(null=True, blank=True)
    subject_line = models.CharField(max_length=255)
    timestamp_sent = models.DateTimeField(null=True, blank=True)
    timestamp_added = models.DateTimeField(auto_now_add=True)
    timestamp_modified = models.DateTimeField(auto_now=True)
    thread = models.ForeignKey(
        Thread, on_delete=models.CASCADE, related_name='messages', null=True, blank=True)

    raw_message_id = models.CharField(null=True, blank=True, max_length=255)
    raw_from_text = models.CharField(null=True, blank=True, max_length=255)
    raw_date_text = models.CharField(null=True, blank=True, max_length=255)
    raw_subject_text = models.CharField(null=True, blank=True, max_length=255)
    raw_message_text = models.TextField(null=True, blank=True)

    run = models.ForeignKey(
        "audit.Run", on_delete=models.CASCADE, null=True, blank=True)
    response_to = models.ForeignKey(
        "penpal.Message", related_name="message_originating", null=True, blank=True, on_delete=models.CASCADE)
    posted = models.BooleanField(default=False)
    answered = models.BooleanField(default=False)

    def __str__(self):
        return f"Message from {self.recipient} to {self.penpal}: {self.subject_line}"

    def notify_new(self):
        from penpal.notify import send_simple_message
        return send_simple_message("!!NEW MSG!! from penpal: {}".format(self.penpal.id))

    def identify_or_create_thread(self):
        # Check for the presence of a prior message pattern
        if not re.search(r"\d{1,2}/\d{1,2}/\d{4} \d{1,2}:\d{2} (AM|PM) wrote", self.raw_message_text):
            # No prior message found, treat this as the first message in a new thread
            new_thread = Thread.objects.get_or_create(
                recipient=self.recipient,
                penpal=self.penpal,
                starting_message=self
            )[0]
            self.thread = new_thread
            self.save()
            return

        # If prior messages exist, proceed with matching logic
        return self.match_or_create_thread_based_on_similarity()

    def extract_last_message(self):
        # Define the regex pattern
        pattern = re.compile(
            r"on \d{1,2}/\d{1,2}/\d{4} \d{1,2}:\d{2}(?::\d{2})? (AM|PM) wrote:?"
        )

        # Use finditer to find all matches of the pattern in the text, which gives us match objects
        matches = list(re.finditer(pattern, self.raw_message_text))

        # If no matches are found, the entire text could be considered as the last message or handled as needed
        if not matches:
            return text

        # Get the last match object
        last_match = matches[-1]

        # Extract everything after the last match
        # The end() method of the match object gives us the end position of the match in the string
        last_message = self.raw_message_text[last_match.end():].strip()
        return last_message

    def match_or_create_thread_based_on_similarity(self):
        # Normalize the new message text for comparison
        last_message = self.extract_last_message()
        if not last_message:
            return
        normalized_new_message = self.normalize_text(last_message)
        similarity_threshold = 0.97

        for thread in Thread.objects.filter(penpal=self.penpal, recipient=self.recipient, starting_message__isnull=False):
            msg = thread.starting_message
            normalized_msg = self.normalize_text(msg.body)
            similarity = difflib.SequenceMatcher(
                None, normalized_new_message, normalized_msg).ratio()
            if similarity >= similarity_threshold:
                self.thread = thread
                self.save()

    def normalize_text(self, text):
        """Function to normalize text for comparison."""
        return ' '.join(text.lower().split())

    def post_process(self):
        from django.utils.dateparse import parse_datetime
        from datetime import datetime

        import re

        # 1. Determine if the message is from the user
        if self.penpal:
            name_in_from = self.penpal.first_name in self.raw_from_text and self.penpal.last_name in self.raw_from_text
            self.is_from_user = not name_in_from

        # 2. Convert raw date text to datetime and save
        if not self.timestamp_sent:
            self.timestamp_sent = datetime.strptime(
                self.raw_date_text, '%m/%d/%Y %I:%M:%S %p')

        # 3. Clean subject text
        if not self.subject_line:
            clean_subject = re.sub(r'^\s*(RE:\s*)+', '',
                                   self.raw_subject_text, flags=re.IGNORECASE)
            self.subject_line = clean_subject

        # 4. Extract message body
        if not self.body:
            divider_pattern = r'-{5,}.*?wrote:'
            body_parts = re.split(
                divider_pattern, self.raw_message_text, flags=re.IGNORECASE | re.DOTALL)
            self.body = body_parts[0].strip(
            ) if body_parts else self.raw_message_text

        # 5. Extract recipient
        if not self.recipient:
            if self.penpal:
                if self.penpal.recipient:
                    self.recipient = self.penpal.recipient

        if not self.thread:
            self.identify_or_create_thread()

        # Save changes without triggering infinite loop
        self.save()
