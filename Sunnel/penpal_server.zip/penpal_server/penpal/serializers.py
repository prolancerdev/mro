from rest_framework import serializers
from .models import Message

class MessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Message
        fields = ['id', 'raw_message_id', 'raw_from_text', 'raw_date_text', 'raw_subject_text', 'raw_message_text', 'run', 'recipient', 'penpal', 'posted', 'answered']
