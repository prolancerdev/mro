import requests
import os

MAILGUN_API_KEY = os.environ.get('MAILGUN_API_KEY')

from datetime import datetime


def send_simple_message(alert):
    msg = "{} - {}".format(datetime.now().strftime('%B %d, %Y'), alert)
    return requests.post(
		"https://api.mailgun.net/v3/sandbox44a04fc6440547ceb051ff090163f93d.mailgun.org/messages",
		auth=("api", MAILGUN_API_KEY),
		data={"from": "Mailgun Sandbox <postmaster@sandbox44a04fc6440547ceb051ff090163f93d.mailgun.org>",
			"to": "suneelius@protonmail.com",
			"subject": msg,
			"text": msg})
