from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from django.http import JsonResponse
from rest_framework import status
from .models import Message, Recipient, PenPal
from django.conf import settings
from audit.models import Run
from .serializers import MessageSerializer

@api_view(['POST'])
@permission_classes([])
def save_message(request):
    raw_message_id = request.data.get('raw_message_id')
    penpal_id = request.data.get('penpal')
    recipient_id = PenPal.objects.get(id=int(penpal_id)).recipient_id
    input_data = request.data
    input_data['recipient'] = recipient_id
    recipient_id = request.data.get('recipient')
    if Message.objects.filter(
        raw_message_id=raw_message_id, 
        penpal_id=penpal_id,
        recipient_id=recipient_id,
    ).exists():
        print("Message already exists: {}".format(raw_message_id))
        return Response({}, status=status.HTTP_201_CREATED)

    else:
        serializer = MessageSerializer(data=input_data)
        if serializer.is_valid():
            message = serializer.save()
            message.post_process()
            message.notify_new()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET'])
def get_answered_messages(request):
    penpal_id = request.query_params.get('penpal_id')
    if not penpal_id:
        return Response({'error': 'penpal_id parameter is required'}, status=400)

    try:
        # Ensure the PenPal exists
        penpal = PenPal.objects.get(id=penpal_id)
    except PenPal.DoesNotExist:
        return Response({'error': 'PenPal not found'}, status=404)

    # Retrieve messages that are from the recipient, have been answered, and belong to the given PenPal
    answered_messages = Message.objects.filter(
        penpal=penpal,
        is_from_recipient=True,
        # answered=True
    )

    # Extract raw_message_ids
    raw_message_ids = [message.raw_message_id for message in answered_messages]
    return Response({'raw_message_ids': raw_message_ids})


@api_view(['GET'])
def get_message_response(request):
    raw_message_id = request.query_params.get('raw_message_id')
    penpal_id = request.query_params.get('penpal_id')

    try:
        penpal = PenPal.objects.get(id=penpal_id)
        # Get the original message based on raw_message_id and penpal
        original_message = Message.objects.filter(raw_message_id=raw_message_id, penpal=penpal).first()

        if not original_message:
            return JsonResponse({'error': 'Original message not found'}, status=404)

        # Find any response message where the 'response_to' field points to the original message
        response_message = Message.objects.filter(response_to=original_message).first()

        response_data = {
            'message_id': original_message.id,
            'raw_message_id': original_message.raw_message_id,
            'answered': original_message.answered,
            'response': None  # Default to None if no response is found
        }

        # If there is a response message, add its details
        if response_message:
            response_data['response'] = {
                'message_id': response_message.id,
                'body': response_message.body,
                'posted': response_message.posted
            }

        return JsonResponse(response_data)

    except PenPal.DoesNotExist:
        return JsonResponse({'error': 'PenPal not found'}, status=404)


@api_view(['PUT'])
def update_message_status(request, penpal_id, message_id):
    # Try to get the specified message and penpal
    try:
        penpal = PenPal.objects.get(id=penpal_id)
        message = Message.objects.get(id=message_id, penpal=penpal)
    except (PenPal.DoesNotExist, Message.DoesNotExist):
        return Response({'error': 'Message or PenPal not found'}, status=404)

    # Update the 'answered' or 'posted' fields if they're in the request
    answered = request.data.get('answered')
    posted = request.data.get('posted')
    if answered is not None:
        message.answered = answered
    if posted is not None:
        message.posted = posted
    message.save()

    # Respond with the updated message data
    return Response({'message_id': message.id, 'answered': message.answered, 'posted': message.posted})
