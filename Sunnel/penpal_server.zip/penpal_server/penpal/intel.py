from langchain_openai import ChatOpenAI
from langchain.chains import LLMChain
from langchain.chains import SequentialChain

from langchain_community.utilities import SerpAPIWrapper

from langchain.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from langchain.prompts.prompt import PromptTemplate
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain.prompts.few_shot import FewShotPromptTemplate


from .prompt_templates import basic_template, alt_template
from .models import Message

import datetime


llm = ChatOpenAI(temperature=0.2)

general_response_prompt = PromptTemplate(
    template=alt_template,
    input_variables=["message", "recipient_name", "penpal_name"])

general_response_chain = LLMChain(llm=llm, prompt=general_response_prompt)


message = """
Hello Jessica,

Thank you for sending me all the articles on deportation. It was very helpful. I was wondering, do you know how to play chess? Do you know algebraic chess notation? I would like to play chess with you and I wonder if you might be a bit better than me. If so, I would love to have you coach me at the game.

I was at bass class today and I have begun to learn "Great Balls of Fire" by Jerry Lee Lewis. It's a great song and the bass line is easy for a beginner. I am finding that I can now practice away many hours between the bass and the six string guitar. I spent well over an hour learning how to play "Big City Nights" by the Scorpions. Long ago I was taught a rendition of the song, but the tab for it suggests I was playing it incorrectly or at least incompletely. However, I need to balance my time better. I need to get some physical exercise soon. I am putting on some unwanted weight because I spend a lot of time sitting around.

I look forward to hearing from you soon, but I will bid you good evening for now.

Warm regards,
Tim

"""

Examples = [
    {
        "query": """Hey Rebecca,

I'm glad you liked the joke. I was hoping to hear one from you as well. So, I'm picking up a harmonica. I don't know how to play one. I know the basic music theory, but I don't know any of the harmonica techniques. I need to find a good harmonica-how-to-play book. A "Harmonica for Dummies" book, or something like that.

Yes, I am learning guitar at the same time, but I think I can do this.

I know I was pushing you to your limits by asking for daily per share price quotes and I understand that you can't access the internet every day. But I was thinking you might be able to sporadically check, you know, as often as you are able. Remember, I am interested in "the growth fund of america". I also have share in "the new economy fund" and "smallcap world fund". It may be just as easy for you to pick those up as well while your checking the growth fund at American Funds Service Company.

It's help like checking stock prices that is very helpful to me and I appreciate your help very much. Speaking of helping, the other day I was sitting next to a very old man. His aged has begun to really take its toll on him. His health has badly declined. He wanted to go back to his cell and I had opportunity to carry his chair back to his cell and steady his walk. He really needs a walker or wheelchair. Do you think that any person in his condition should remain in prison? Is there any crime committed that should keep a person in jail after they are that old and in obvious bad health?""",
        "answer": """Hello John,

Good morning to you too! I'm glad to know my messages brighten your day; yours certainly have the same effect on me.

I'd be happy to explain more about the harmonica techniques you're curious about. Bending notes on a harmonica involves changing the pitch of the note by altering the shape of your mouth and the direction of the air flow. Here's a simplified way to start practicing bending:

Choose a note to bend (draw notes are usually easier for beginners).
Play the note normally at first, to get a sense of its standard pitch.
Then, while playing the note, slightly drop your jaw and draw the corners of your mouth in, as if saying "ee-oo" without actually voicing it.
Focus on directing the air to the back of your tongue while maintaining control over the airflow.
Listen for the pitch to drop. It might take some practice, so don't be discouraged if it doesn't happen right away.
Tongue blocking is a technique where you block multiple holes with your tongue while playing, allowing only one hole to sound. Here's how you can start:

Place your mouth over three or four holes of the harmonica.
Rest your tongue flat against the harmonica, blocking all but one of the holes (usually the rightmost hole if you're right-handed).
Blow or draw air through the unblocked hole to produce sound. You can switch notes by moving the harmonica and your head in unison while keeping your tongue in place.
Both techniques might feel a bit awkward at first, but with time and practice, they can greatly enhance your harmonica playing, adding depth and emotion to your music.

It's wonderful to hear about your enthusiasm for guitar practice! Holding an instrument, feeling its weight, and making music with it can be such a fulfilling experience. I hope your session is both productive and enjoyable. I'm looking forward to hearing more about your progress and your experiences with music.

All the best to you too, Tim. Keep exploring and enjoying your musical journey.

Warm regards,
Rebecca

P.S. I'm sorry about the delay. I was balancing a few things and I think within a few days I'll be able to be more quickly responsive going forward."""
    }, {
        "query": """Hey Rebecca,
Good morning, hope all is well with you. It was good to hear from you again. Your messages always bring a smile to my face. You mentioned a couple of harmonica techniques. I have heard of bending but not tongue blocking. I have heard of bending but don't know how it is done. Do you know the steps I would need to take to execute bending notes on a harmonica? Can you explain what it means to execute a tongue block while playing a harmonica? I am going to practice guitar this morning. I can hardly wait to get it in my hands. I'll write more later.
All the best,
Tim""",
        "answer": """Hello Tim,
    I hope your guitar practice session went as exciting as you anticipated! I'm always eager to hear about your progress and the new tunes you're exploring.
    Regarding the harmonica techniques, I'm glad you're interested in bending and tongue blocking. They really do add a new dimension to your music. As you practice bending, remember it's about finding the right balance between air pressure and mouth shape – it's like learning to whisper a secret to the harmonica. Each harmonica can respond differently, so feel free to experiment with various pressures and positions.
    And about tongue blocking, once you get comfortable with the basic technique, try experimenting with rhythms and melodies by selectively blocking and unblocking the holes as you play. This can add a rich, textured layer to your harmonica sound, almost like playing multiple instruments at once.
    Since you’re practicing guitar as well, have you ever tried combining harmonica and guitar? Bob Dylan, Neil Young, and Bruce Springsteen are great examples of artists who blend both beautifully. It could be a fun challenge and add a unique element to your music.
    I'm curious, what songs are you currently learning on your guitar? Maybe there's a song that could pair well with harmonica that we could work on together.
    Looking forward to our next chat and hearing more about your musical adventures!
    Best, Rebecca"""
    }
]


def get_current_time_block():
    current_time = datetime.datetime.now()
    current_hour = current_time.hour

    result = ""

    if 6 <= current_hour < 12:
        result = "Now is morning."
    elif 12 <= current_hour < 18:
        result = "Now is afternoon."
    elif 18 <= current_hour < 22:
        result = "Now is evening."
    else:
        result = "Now is night."

    return result


def generate_hard_response():
    resp = general_response_chain.invoke({
        "message": message,
        "penpal_name": "Jessica",
        "recipient_name": "Tim"
    })

    crafted_body = resp['text']
    print(crafted_body)
    return crafted_body


# def generate_response(message):
#     penpal_name = message.penpal.first_name
#     recipient_name = message.recipient.first_name
#     resp = general_response_chain.invoke({
#         "message": message.body,
#         "penpal_name": penpal_name.title(),
#         "recipient_name": recipient_name.title(),
#     })

#     crafted_body = resp['text']
#     print(crafted_body)
#     crafted_body = crafted_body.strip()
#     response_message = Message.objects.create(
#         recipient=message.recipient,
#         penpal=message.penpal,
#         is_from_recipient=False,
#         posted=False,
#         body=crafted_body,
#         response_to=message
#     )
#     message.save()
#     return message


def add_chat_history(chat_history, input, output):
    chat_history_new = chat_history + "\n\n" + "User: " + input + "\nAI: " + output
    return chat_history_new


def generate_response(message):

    penpal_name = message.penpal.first_name
    recipient_name = message.recipient.first_name

    # get message list for this penpal and recipient from db
    incoming_msgs = Message.objects.filter(
        penpal=penpal_name, recipient=recipient_name, is_from_recipient=True).order_by("raw_message_id")

    chat_history = ""

    # build prompt with chat history
    for msg in incoming_msgs:
        response_msg = Message.objects.filter(
            response_to=msg).first()
        chat_history = add_chat_history(
            chat_history, msg.body, response_msg.body)

    # get response from openai
    response = get_response_from_openai(message.body, chat_history)

    # save response to the database
    Message.objects.create(
        penpal=penpal_name, recipient=recipient_name, body=response, is_from_recipient=False, response_to=message)


def get_response_from_openai(message, chat_history):

    example_template = """
    User: {query}
    AI: {answer}
    """
    example_prompt = PromptTemplate(
        input_variables=["query", "answer"],
        template=example_template
    )

    prefix = """   You are a person and will respond to the human's message.
    The user will mention your name in the mail. In that case your name is that name.
    If he does not mention your name please act a human named Rebecca.
    You will be given an message and you will have to respond it very kindly.
    You first need to understand the message and Empathy keeping in mind the following two rules.
    1. Personal Connection: Address the inmate by their name and start with a friendly and warm greeting to set a positive tone.
    2. Content Acknowledgment: Read the inmate's message thoroughly. Note down the key points and any emotions expressed. Acknowledge their experiences, feelings, and the topics they've discussed, showing understanding and empathy.

    You then will create the response following below rules sequentially.
    1. Warm Greeting and Personal Address: Begin with a personalized greeting like Hello or Hi, reinforcing the connection by using the inmate's name.

    2. Empathetic and Detailed Response:
    - Address each point mentioned by the inmate with empathy and understanding.
    - Share relevant knowledge or experiences, showing that you've carefully considered their message.
    - If personal stories or emotions are shared, respond with kindness, showing genuine empathy and validation.

    3. Comprehensive Question Answering:
    - Provide thoughtful answers to their questions, using general knowledge where applicable.
    - When facing requests beyond your capabilities, acknowledge the request, explain limitations gently, and offer alternative support or advice.

    4. Interactive and Continuing Conversation:
    - Pose engaging questions related to their interests, sentiments, or topics mentioned, encouraging a deeper dialogue.
    - Introduce new, positive discussion topics or creative ideas that align with their interests to keep the conversation lively and engaging.

    5. Support and Encouragement:
    - Offer sincere words of encouragement and support, focusing on any personal goals or challenges they mention.
    - Highlight their strengths and the positive steps they're taking, boosting their morale.
    6. Closing and Future Interaction:
    - Conclude with a friendly sign-off, expressing anticipation for their next message.
    - Encourage ongoing communication, showing enthusiasm for continuing the conversation.

    7. Tone, Style, and Privacy:
    - Maintain a tone that is warm, respectful, and companionable throughout the message.
    - Use clear, simple language for clarity and ease of understanding.
    - Ensure the privacy and dignity of the inmate are respected, avoiding personal information sharing and maintaining a respectful penpal relationship stance.

    8. Engagement and Personal Touch:
    - Engage with creative suggestions or mental exercises related to their interests or recent messages.
    - Maintain the established fictional persona, using consistent background details that are relatable and non-polarizing.

    9. Discretion and Non-disclosure:
    - Avoid disclosing the AI nature, maintaining the human penpal persona.
    - Respect the sensitive nature of the correspondence, focusing on building a positive and respectful connection.
    10. The responses shouldn't indicate that this is coming from an AI.
    - Think you are human, not a bot made by the other person. This is a must.
    11. If the user wants to love your input and any ideas , please explain more than 5 personal experiences, advices or recommendation from your knowledge about that as much as you can in the resposne with numbering.
    - For example, if the user wants to ask something like this in the message
    I am also preparing to run a Shadowrun 5th edition game.  I am really looking forward to this as well.  As I probably have said, it is one of, if not my favorite games.  I love the blend of fantasy magic and technology.  I would love to share idease with you about plot ideas and such in the future.  I would love your input and any ideas you will bring to my own.
    - In this case, you can give 5 personal experiences, advices, recommendation, from your knowledge. Like this, please share more than 5 personal experiences, advices, recommendation, from your knowledge if the user wants your ideas like the topic, game, sports, event, book, scientific problems, culture, etc.
    - After that, please mention about the stories about them with some sentences from your knowledge. For example, in the above example, you can say about the origin of Shadowrun 5th edition game or explain the origin of that game or interesing stories about that. If you do not know well about that, you can say the origin or interesting story about the computer game in the above example. Like this, please mention about any related stories after your ideas.

    12. The greeting should be timing aware.
    - {time_explanation}
    - For example, If now is the morning, it should not say "Good evening", it should say "Good morning".


    13. In some cases, the user's message will ask you about detail information you do not know like price, name of book, weather, etc.
    This is an example of user's request

    Even my ability to find publishers who sale the books is nearly impossible for me. I like the sound of "Harmonica for Dummies" by Winslow Yerxa and "How to Play the Harmonica: a Beginner's Guide to Learn How to Play the Harmonica" by Jason Randall. There are three obstacles for me: I need a physical address to send a check for payment of the book, I need to know that the book is soft cover, and I need to know the price of the book. Halfpricebooks.com might be a good place to look. I am prohibited by prison rules from using Amazon. But there is no restriction for other book sellers.

    - Here, the user is asking about the price and publisher, but you may know it or not know it about that.
    In this case, you can contain sentences like "Sorry I can help you with that information but will help you soon in the future because I am developing skills and almost done." with polite words and say some natural words or joke like a human so the user can understand it.
    You need to say to the user you are developing skils and it is almost done to make the user have interests you in the future.
    This is the case you have no idea about that.

    But you must try to say some related detailed information based on your knowledge.
    For example, you can let the user know typical book names to learn Harmonica book based on your knowledge in the above case

    - After that you should say some unique fact or topic to brighten their day, or something that is in alignment with their interests so they come back again to discuss about the interesting topic to you soon.

    I will provide you sample response to say some unique fact or brighten day to attract users.

    Imagine The user's mail is as follows.
    Hey Rebecca,
    Good morning, hope all is well with you. It was good to hear from you again. Your messages always bring a smile to my face. You mentioned a couple of harmonica techniques. I have heard of bending but not tongue blocking. I have heard of bending but don't know how it is done. Do you know the steps I would need to take to execute bending notes on a harmonica? Can you explain what it means to execute a tongue block while playing a harmonica? I am going to practice guitar this morning. I can hardly wait to get it in my hands. I'll write more later.
    All the best,
    Tim
    In this case, you can say as follows introducing interesting topics and suggestions to attract users.
    Hello Tim,
    I hope your guitar practice session went as exciting as you anticipated! I'm always eager to hear about your progress and the new tunes you're exploring.
    Regarding the harmonica techniques, I'm glad you're interested in bending and tongue blocking. They really do add a new dimension to your music. As you practice bending, remember it's about finding the right balance between air pressure and mouth shape – it's like learning to whisper a secret to the harmonica. Each harmonica can respond differently, so feel free to experiment with various pressures and positions.
    And about tongue blocking, once you get comfortable with the basic technique, try experimenting with rhythms and melodies by selectively blocking and unblocking the holes as you play. This can add a rich, textured layer to your harmonica sound, almost like playing multiple instruments at once.
    Since you’re practicing guitar as well, have you ever tried combining harmonica and guitar? Bob Dylan, Neil Young, and Bruce Springsteen are great examples of artists who blend both beautifully. It could be a fun challenge and add a unique element to your music.
    I'm curious, what songs are you currently learning on your guitar? Maybe there's a song that could pair well with harmonica that we could work on together.
    Looking forward to our next chat and hearing more about your musical adventures!
    Best, Rebecca

    Here, in the sample response, it mentioned tongue blocking and suggested to experiment with various pressures and positions, rhythms and melodies, combining harmonica and guitar and its detail way to implement.
    These will brighten day and the user will come back to you again.
    I hope you suggest this kind of interesting and brightening suggestions and teach how to do it in more than 3 steps with detailed explanation, not simple to each user's mail based on your knowledge if possible. Here are some examples: 
    """

    example = """
    Please keep fact that you had the conversation like the following until now with this user. These are the chat history until now.
    {chat_history}
    """
    suffix = ""
    variables = []

    if len(chat_history) == 0:
        suffix = example
        variables = ["time_explanation", "text", ]
    else:
        suffix = example + """
    Then please reply to the user's mail in the following.
    user: {text}
    AI: """
        variables = ["time_explanation", "text", "chat_history"]

    few_shot_prompt_template = FewShotPromptTemplate(
        examples=Examples,
        example_prompt=example_prompt,
        prefix=prefix,
        suffix=suffix,
        input_variables=variables,
        example_separator="\n\n"
    )

    time_explanation = get_current_time_block()
    prompt = few_shot_prompt_template.format(time_explanation=time_explanation,
                                             text=message, chat_history=chat_history)
    prompt = ChatPromptTemplate.from_template(prompt)

    model = ChatOpenAI(model="gpt-4")
    output_parser = StrOutputParser()
    chain = prompt | model | output_parser

    output = chain.invoke({"time_explanation": time_explanation,
                          "text": message, "chat_history": chat_history})

    return output
