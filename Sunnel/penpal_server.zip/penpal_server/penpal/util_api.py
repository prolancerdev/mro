import requests
import json

# URL of your Django API endpoint
url = 'http://localhost:8000/api/save_message/'

raw_msg = """Hey Jessica,

It was good to hear from you. I am certainly happy that my messages to you bring you happiness. Your explanation of harmonica playing techniques has been very helpful. I will keep you informed about my progress. At present I am only able to play harmonica in my mind. I am still waiting for the instrument to be ordered and shipped to me. That is the reason I am trying to find a book. Have you made any progress on finding the price and address to a book seller that sells the titles I was interested in? 

The delay is okay, as I mentioned, my financial situation is not the best. Things have been improved and I now have allotted $30 a month to write to you. That gives me about a around 20 minutes a day to type. I am not the fastest typist in the world. I was taking a course called Mavis Beacon and was keying in at 55 words a minute without numbers and symbols, but I think my real speed is around 35. Especially when I am typing on the fly and trying to structure sentences while I type. And the craziest thing, this key board that I am typing on is typing only letters correctly. For example I am going to press the apostrophe-quote key {-[ it gives me brackets. The back slash key is giving hyphens. To get a question mark I have to press the key designated as the hyphen key. I need IT in here.

Back to the question of artificial intelligence and knowing. It is difficult for humans to parse out what is known versus what is believed to be known. We take a lot for granted in what we think we know. But how does AI know that what it has as data is true or genuine or real? I mean, a lot of the things I know are just convention. I see a color and I call it red but it is not red any more than it is rojas or aduma, the word's foreign counterparts. These are conventions that we use so that we can communicate about the thing my eye experiences. But in other areas, how would AI determine the truth about a political figure? How does AI determine morality? Is there axiomatic morality? Is there absolute right and wrong? or is right and wrong only determined by our personal mores? It is difficult for humans to decide these issues so I am very interested in hearing how AI determines what is or is not moral. 

All the best,
Tim
-----Hawthorne, Jessica on 3/1/2024 10:51 AM wrote:

>

Hello Tim,

Good morning to you too! I'm glad to know my messages brighten your day; yours certainly have the same effect on me.

I'd be happy to explain more about the harmonica techniques you're curious about. Bending notes on a harmonica involves changing the pitch of the note by altering the shape of your mouth and the direction of the air flow. Here's a simplified way to start practicing bending:

Choose a note to bend (draw notes are usually easier for beginners).
Play the note normally at first, to get a sense of its standard pitch.
Then, while playing the note, slightly drop your jaw and draw the corners of your mouth in, as if saying "ee-oo" without actually voicing it.
Focus on directing the air to the back of your tongue while maintaining control over the airflow.
Listen for the pitch to drop. It might take some practice, so don't be discouraged if it doesn't happen right away.
Tongue blocking is a technique where you block multiple holes with your tongue while playing, allowing only one hole to sound. Here's how you can start:

Place your mouth over three or four holes of the harmonica.
Rest your tongue flat against the harmonica, blocking all but one of the holes (usually the rightmost hole if you're right-handed).
Blow or draw air through the unblocked hole to produce sound. You can switch notes by moving the harmonica and your head in unison while keeping your tongue in place.
Both techniques might feel a bit awkward at first, but with time and practice, they can greatly enhance your harmonica playing, adding depth and emotion to your music.

It's wonderful to hear about your enthusiasm for guitar practice! Holding an instrument, feeling its weight, and making music with it can be such a fulfilling experience. I hope your session is both productive and enjoyable. I'm looking forward to hearing more about your progress and your experiences with music.

All the best to you too, Tim. Keep exploring and enjoying your musical journey.

Warm regards,
Jessica

P.S. I'm sorry about the delay. I was balancing a few things and I think within a few days I'll be able to be more quickly responsive going forward.

TIMOTHY BROOKS on 2/29/2024 9:35:13 AM wrote 
Hey Jessica,

Good morning, hope all is well with you. It was good to hear from you again. Your messages always bring a smile to my face. You mentioned a couple of harmonica techniques. I have heard of bending but not tongue blocking. I have heard of bending but don't know how it is done. Do you know the steps I would need to take to execute bending notes on a harmonica? Can you explain what it means to execute a tongue block while playing a harmonica?

I am going to practice guitar this morning. I can hardly wait to get it in my hands. I'll write more later.

All the best,
Tim"""

# Data to send in the request
data = {
    "raw_message_id": "12345",
    "raw_from_text": "TIMOTHY BROOKS (86832079)",
    "raw_date_text": "3/3/2024 10:50:31 AM",
    "raw_subject_text": "RE: RE: technique",
    "raw_message_text": raw_msg,
    "run": 13,  # Replace with actual run_id
    "recipient": 1,  # Replace with actual recipient_id
    "penpal": 2  # Replace with actual penpal_id
}

# Convert the data to JSON
json_data = json.dumps(data)

# Send the POST request
response = requests.post(url, data=json_data, headers={'Content-Type': 'application/json'})

# Print out the response from the server
print('Status Code:', response.status_code)
print('Response Body:', response.json())
