from django.test import TestCase
from django.urls import reverse
from .models import PenPal, Recipient, Message, Thread

from rest_framework import status
from rest_framework.test import APITestCase
from .models import PenPal, Message, Recipient
from audit.models import Run


class MessageResponseTest(APITestCase):
    def setUp(self):
        # Set up the data needed for the tests
        self.penpal = PenPal.objects.create(first_name="Test Penpal")
        self.recipient = Recipient.objects.create(first_name="Test Recipient")
        self.original_message = Message.objects.create(
            penpal=self.penpal,
            recipient=self.recipient,
            raw_message_id="12345",
            body="Original message body",
            subject_line="Original",
            answered=True
        )
        self.response_message = Message.objects.create(
            penpal=self.penpal,
            recipient=self.recipient,
            response_to=self.original_message,
            body="Response message body",
            subject_line="Response",
            posted=False,
        )

    def test_get_message_response(self):
        # Formulate the URL with the correct raw_message_id and penpal_id
        url = reverse('get_message_response') + f'?raw_message_id={self.original_message.raw_message_id}&penpal_id={self.penpal.id}'
        response = self.client.get(url)

        # Check that the response status code is 200 (OK)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Check the response content
        self.assertEqual(response.json()['message_id'], self.original_message.id)
        self.assertEqual(response.json()['raw_message_id'], "12345")
        self.assertTrue(response.json()['answered'])
        self.assertIsNotNone(response.json().get('response'))
        self.assertEqual(response.json()['response']['message_id'], self.response_message.id)
        self.assertEqual(response.json()['response']['body'], "Response message body")
        self.assertFalse(response.json()['response']['posted'])


class MessageAPITests(TestCase):
    def setUp(self):
        # Set up test data
        self.recipient = Recipient.objects.create()
        self.penpal = PenPal.objects.create()
        self.message1 = Message.objects.create(
            recipient=self.recipient,
            penpal=self.penpal,
            is_from_recipient=True,
            raw_message_id='msg1',
            answered=True,
        )
        self.message2 = Message.objects.create(
            recipient=self.recipient,
            penpal=self.penpal,
            is_from_recipient=True,
            raw_message_id='msg2',
            answered=False,
        )

    def test_get_answered_messages(self):
        # Make a GET request to the endpoint
        url = reverse('get_answered_messages')
        response = self.client.get(url, {'penpal_id': self.penpal.id})
        
        # Check the response
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()['raw_message_ids'], ['msg1'])


class MessageUpdateTest(APITestCase):
    def setUp(self):
        self.penpal = PenPal.objects.create(first_name="Test Penpal")
        self.recipient = Recipient.objects.create(first_name="Test Recipient")
        self.message = Message.objects.create(
            penpal=self.penpal,
            recipient=self.recipient,
            body="Test message body",
            subject_line="Test",
            answered=False,
            posted=False
        )

    def test_update_message_status_answered(self):
        # Define the URL for updating the message
        url = reverse('update_message_status', args=[self.penpal.id, self.message.id])
        
        # Define the data to update
        data = {'answered': True}
        
        # Make the PUT request
        response = self.client.put(url, data, format='json')
        
        # Check that the response status code is 200 (OK)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        # Check the response content
        response_data = response.json()
        self.assertEqual(response_data['message_id'], self.message.id)
        self.assertTrue(response_data['answered'])
        self.assertFalse(response_data['posted'])

        # Optionally, reload the message from the database and check the fields have been updated
        self.message.refresh_from_db()
        self.assertTrue(self.message.answered)
        self.assertFalse(self.message.posted)

    def test_update_message_status_posted(self):
        # Define the URL for updating the message
        url = reverse('update_message_status', args=[self.penpal.id, self.message.id])
        
        # Define the data to update
        data = {'posted': True}
        
        # Make the PUT request
        response = self.client.put(url, data, format='json')
        
        # Check that the response status code is 200 (OK)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        # Check the response content
        response_data = response.json()
        self.assertEqual(response_data['message_id'], self.message.id)
        self.assertFalse(response_data['answered'])
        self.assertTrue(response_data['posted'])

        # Optionally, reload the message from the database and check the fields have been updated
        self.message.refresh_from_db()
        self.assertFalse(self.message.answered)
        self.assertTrue(self.message.posted)



class MessageSaveTestCase(APITestCase):

    def setUp(self):
        # Create test instances for PenPal and Recipient
        self.recipient = Recipient.objects.create(first_name='Jim')
        self.penpal = PenPal.objects.create(first_name='Jessica', recipient=self.recipient)
        self.run = Run.objects.create(penpal=self.penpal)

    def test_save_new_message(self):
        # Define the URL
        url = reverse('save_message')  # Replace 'save_message' with the actual name of the view in your urls.py

        self.assertEqual(Message.objects.count(), 0)

        # Define the payload
        payload = {
            'run': self.run.id,
            # 'recipient': str(self.recipient.id),
            'penpal': str(self.penpal.id),
            'raw_message_id': '3651998142',
            'raw_date_text': '2/29/2024 9:35:13 AM',
            'raw_from_text': 'JIM ROBINSON (1020324)',
            'raw_subject_text': 'technique',
            'raw_message_text': """Hey Jessica,

Good morning, hope all is well with you. It was good to hear from you again. Your messages always bring a smile to my face. You mentioned a couple of harmonica techniques. I have heard of bending but not tongue blocking. I have heard of bending but don't know how it is done. Do you know the steps I would need to take to execute bending notes on a harmonica? Can you explain what it means to execute a tongue block while playing a harmonica?

I am going to practice guitar this morning. I can hardly wait to get it in my hands. I'll write more later.

All the best,
Jim"""
        }

        # Send POST request
        response = self.client.post(url, payload, format='json')

        # Check that the response status code is 201 (Created)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        # Check that the Message has been saved to the database
        self.assertEqual(Message.objects.count(), 1)
        # Additional checks can include:
        # Verifying the content of the response
        # Ensuring that the `post_process` method was called on the saved Message object

    def test_save_existing_message(self):
        # Define the URL
        Message.objects.create(penpal=self.penpal, recipient=self.recipient, raw_message_id='3651998143')
        self.assertEqual(Message.objects.count(), 1)

        url = reverse('save_message')  # Replace 'save_message' with the actual name of the view in your urls.py

        # Define the payload
        payload = {
            'run': self.run.id,
            'recipient': str(self.recipient.id),
            'penpal': str(self.penpal.id),
            'raw_message_id': '3651998143',
            'raw_date_text': '2/29/2024 9:35:13 AM',
            'raw_from_text': 'JIM ROBINSON (1020324)',
            'raw_subject_text': 'technique',
            'raw_message_text': """Hey Jessica,

Good morning, hope all is well with you. It was good to hear from you again. Your messages always bring a smile to my face. You mentioned a couple of harmonica techniques. I have heard of bending but not tongue blocking. I have heard of bending but don't know how it is done. Do you know the steps I would need to take to execute bending notes on a harmonica? Can you explain what it means to execute a tongue block while playing a harmonica?

I am going to practice guitar this morning. I can hardly wait to get it in my hands. I'll write more later.

All the best,
Jim"""
        }

        # Send POST request
        response = self.client.post(url, payload, format='json')

        # Check that the response status code is 201 (Created)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        # Check that the Message has been saved to the database
        self.assertEqual(Message.objects.count(), 1)

        # Additional checks can include:
        # Verifying the content of the response
        # Ensuring that the `post_process` method was called on the saved Message object

