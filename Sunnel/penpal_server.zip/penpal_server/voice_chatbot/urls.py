"""
URL configuration for voice_chatbot project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from audit.api import (
    save_browse_step, 
    create_run, 
    update_task_status,
    get_task)
from penpal.api import (
    save_message, get_answered_messages, 
    get_message_response, update_message_status)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('bot/', include('bot.urls')),
    path('api/create_run/', create_run, name='create_run'),
    path('api/save_browse_step/', save_browse_step, name='save_browse_step'),
    path('api/get_answered_messages/', get_answered_messages, name='get_answered_messages'),
    path('api/save_message/', save_message, name='save_message'),
    path('api/message-response/', get_message_response, name='get_message_response'),
    path('api/messages/<int:penpal_id>/<int:message_id>/', update_message_status, name='update_message_status'),
    path('api/tasks/<int:penpal_id>/<int:task_id>/', update_task_status, name='update_task_status'),
    path('api/get_task/', get_task, name='get_task'),
] 

if settings.LOCAL_SERVE_STATIC_FILES:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

if settings.LOCAL_SERVE_MEDIA_FILES:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)