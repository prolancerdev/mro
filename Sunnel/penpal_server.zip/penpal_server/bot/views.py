from django.shortcuts import render

from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from twilio.twiml.voice_response import VoiceResponse

@csrf_exempt
def voice(request):
    # This is where you'll process incoming voice data, interact with WhisperLive, ChatGPT, and ElevenLabs
    # Placeholder response to test incoming calls
    response = VoiceResponse()
    response.say("Hello, this is your Django voice chatbot speaking.", voice='alice')
    return HttpResponse(str(response), content_type='text/xml')


# import openai
# from django.conf import settings

# # Assuming you have added OPENAI_API_KEY in your settings.py
# openai.api_key = settings.OPENAI_API_KEY

# def get_chatgpt_response(message):
#     response = openai.ChatCompletion.create(
#         model="gpt-3.5-turbo",
#         messages=[
#             {"role": "system", "content": "You are a helpful assistant."},
#             {"role": "user", "content": message},
#         ]
#     )
#     return response.choices[0].message['content']

