import { ReactNode } from 'react';

import { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { cookies } from 'next/headers';

import { Toaster } from '@/components/ui/sonner';
import { GlobalState } from '@/components/utility/global-state';
import { Providers } from '@/components/utility/providers';
import TranslationsProvider from '@/components/utility/translations-provider';

import loginSyles from '../../styles/OnBoardingStyles/LoginPage.module.css';
import './globals.css';

import initTranslations from '@/lib/i18n';
import { Database } from '@/supabase/types';
import { createServerClient } from '@supabase/ssr';

const inter = Inter({ subsets: ['latin'] });

interface RootLayoutProps {
  children: ReactNode;
  params: {
    locale: string;
  };
}

export const metadata: Metadata = {
  title: {
    template: '%s - ChatNI',
    default: 'ChatNI',
  },
};

const i18nNamespaces = ['translation'];

export default async function RootLayout({
  children,
  params: { locale },
}: RootLayoutProps) {
  const cookieStore = cookies();
  const supabase = createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
      },
    },
  );
  const session = (await supabase.auth.getSession()).data.session;

  const { t, resources } = await initTranslations(locale, i18nNamespaces);

  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <Providers attribute="class" defaultTheme="dark">
          <TranslationsProvider
            namespaces={i18nNamespaces}
            locale={locale}
            resources={resources}
          >
            <Toaster richColors position="top-center" duration={2000} />
            <div
              className={`text-foreground flex h-screen flex-col items-center ${loginSyles.loginbackground}`}
            >
              {session ? <GlobalState>{children}</GlobalState> : children}
            </div>
          </TranslationsProvider>
        </Providers>
      </body>
    </html>
  );
}
