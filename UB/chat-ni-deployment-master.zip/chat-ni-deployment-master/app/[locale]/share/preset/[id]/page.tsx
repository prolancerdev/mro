'use client';

import SharePage from '@/components/sharing/SharePage';
import { SharePreset } from '@/components/sharing/SharePreset';

import { getPresetById } from '@/db/presets';

interface SharePresetPageProps {
  params: {
    id: string;
  };
}

export default function SharePresetPage({ params }: SharePresetPageProps) {
  return (
    <SharePage
      contentType="presets"
      id={params.id}
      fetchById={getPresetById}
      ViewComponent={SharePreset}
    />
  );
}
