'use client';

import SharePage from '@/components/sharing/SharePage';
import { SharePrompt } from '@/components/sharing/SharePrompt';

import { getPromptById } from '@/db/prompts';

interface SharePromptPageProps {
  params: {
    id: string;
  };
}

export default function SharePromptPage({ params }: SharePromptPageProps) {
  return (
    <SharePage
      contentType="prompts"
      id={params.id}
      fetchById={getPromptById}
      ViewComponent={SharePrompt}
    />
  );
}
