'use client';

import { ChatUI } from '@/components/Chat/ChatUi';

export default function ChatIDPage() {
  return <ChatUI />;
}
