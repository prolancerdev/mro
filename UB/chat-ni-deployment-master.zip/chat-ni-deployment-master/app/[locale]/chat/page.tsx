'use client';

import { useContext, useEffect } from 'react';

import { useTheme } from 'next-themes';
import { useRouter } from 'next/navigation';

import useHotkey from '@/lib/hooks/use-hotkey';

import { ChatHelp } from '@/components/Chat/ChatHelp';
import { ChatInput } from '@/components/Chat/ChatInput2';
import { ChatSettings } from '@/components/Chat/ChatSettings';
import { ChatUI } from '@/components/Chat/ChatUi';
import { QuickSettings } from '@/components/Chat/QuickSettings';
import { useChatHandler } from '@/components/Chat/chat-hooks/UseChatHandler';
import { Brand } from '@/components/ui/brand';

import styles from '../../../styles/componentStyles/secondary.module.css';

import { ChatbotUIContext } from '@/context/context';

export default function ChatPage() {
  useHotkey('o', () => handleNewChat());

  const { chatMessages } = useContext(ChatbotUIContext);
  const router = useRouter();
  const { handleNewChat } = useChatHandler();

  const { theme } = useTheme();

  // useEffect(() => {
  //   if (localStorage.getItem('status') === '1') {
  //     localStorage.setItem('status', '0');
  //     location.reload();
  //   }
  // }, [router]);

  return (
    <>
      {chatMessages.length === 0 ? (
        <div
          className={`relative flex h-full flex-col items-center justify-center ${styles.dashboardContentBackground}`}
        >
          <div className="top-50% left-50% -translate-x-50% -translate-y-50% absolute mb-20">
            <Brand theme={theme === 'dark' ? 'dark' : 'light'} />
          </div>

          <div className="absolute left-2 top-2">
            <QuickSettings />
          </div>

          <div className="absolute right-2 top-2">
            <ChatSettings />
          </div>

          <div className="flex grow flex-col items-center justify-center" />

          <div className="w-[300px] pb-8 sm:w-[400px] md:w-[500px] lg:w-[660px] xl:w-[800px]">
            <ChatInput />
          </div>

          {/* <div className="absolute bottom-2 right-2 hidden md:block lg:bottom-4 lg:right-4">
            <ChatHelp />
          </div> */}
        </div>
      ) : (
        <ChatUI />
      )}
    </>
  );
}
