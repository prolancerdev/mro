import { useAuth0 } from '@auth0/auth0-react';
import {
  IconArrowBack,
  IconCopy,
  IconEdit,
  IconExternalLink,
  IconPlus,
  IconTrash,
} from '@tabler/icons-react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';

import Head from 'next/head';
import Image from 'next/image';
import { useRouter } from 'next/router';

import { useAPIFetch } from '../hooks/useAPIFetch';

import { title } from '@/utils/app/const';

import { APIKeyOperations } from '@/components/APIKeyOperations';
import Button from '@/components/Button';
import { ApiKeyModal } from '@/components/Profile/ApiKeyModal';
import Spinner from '@/components/Spinner';

import { DateTime } from 'luxon';

const requestDocsUrl =
  'https://github.com/fabhed/validator-endpoint/blob/main/docs/requests.md';

const Profile = () => {
  const [showModal, setShowModal] = useState<boolean>(false);
  const [modalType, setModalType] = useState<'edit' | 'new'>('edit');
  const [apiKey, setApiKey] = useState(null);

  const router = useRouter();
  const { user, isAuthenticated, isLoading } = useAuth0();

  const apiFetch = useAPIFetch();

  const {
    isLoading: apiKeysIsLoading,
    error: apiKeyError,
    data: apiKeys,
    refetch: refetchApiKeys,
  } = useQuery({
    queryKey: ['repoData'],
    queryFn: () => apiFetch('/api-keys/'),
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/');
    }
  }, [isLoading, isAuthenticated, router]);

  const updateMutation = useMutation({
    mutationFn: (apiKey: any) =>
      apiFetch('/api-keys/' + apiKey.id, {
        method: 'PATCH',
        body: JSON.stringify(apiKey),
      }),
    onSuccess: (data) => {
      refetchApiKeys();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (apiKey: any) =>
      apiFetch('/api-keys/' + apiKey.id, {
        method: 'DELETE',
      }),
    onSuccess: (data) => {
      refetchApiKeys();
    },
  });

  const createMutation = useMutation({
    mutationFn: (apiKey: any) =>
      apiFetch('/api-keys/', {
        method: 'POST',
        body: JSON.stringify(apiKey),
      }),
    onSuccess: (data) => {
      refetchApiKeys();
    },
  });

  const handleApiKeyUpdate = async (apiKey: any) => {
    await updateMutation.mutate(apiKey);
  };

  const editApiKey = (apiKey: any) => {
    setApiKey(apiKey);
    setModalType('edit');
    setShowModal(true);
  };

  const createApiKey = () => {
    createMutation.mutate({});
  };

  const deleteApiKey = (apiKey: any) => {
    deleteMutation.mutate(apiKey);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard
      .writeText(text)
      .then(() => console.log('API Key copied to clipboard'))
      .catch((err) =>
        console.error('Could not copy API Key to clipboard', err),
      );
    toast.success('API Key copied to clipboard!');
  };

  return (
    <>
      {showModal &&
        (modalType === 'new' || (modalType === 'edit' && apiKey)) && (
          <ApiKeyModal
            apiKey={apiKey}
            onClose={() => setShowModal(false)}
            onUpdate={handleApiKeyUpdate}
            type={modalType}
          />
        )}
      <Head>
        <title>{title}</title>
        <meta name="description" content="Manage Usage & API Keys" />
        <meta
          name="viewport"
          content="height=device-height ,width=device-width, initial-scale=1, user-scalable=no"
        />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main
        className={`size-screen flex flex-col bg-[#1B1B24] p-6 text-sm text-white dark:text-white`}
      >
        <div className="mx-auto max-w-[1200px] rounded-md bg-[#1B1B24] p-4 text-white">
          {/* Back arrow and profile title */}
          <div className="mb-4 flex items-center text-4xl">
            <button
              onClick={() => {
                router.push('/');
              }}
              className="mr-4"
            >
              <IconArrowBack size="1em" />
            </button>
            <h1>My profile</h1>
          </div>

          {/* User details */}
          <div className="mb-6 flex flex-col items-center justify-center ">
            <div></div>
            {isLoading ? (
              <div className="size-[100px] rounded-full bg-slate-500"></div>
            ) : (
              <Image
                className="rounded-full"
                src={user?.picture!}
                alt={user?.name || 'Profile Picture'}
                width={100}
                height={100}
              />
            )}
            <div className="mt-4 text-xl">
              {isLoading ? (
                <Spinner className="size-7 border-t-white" />
              ) : (
                <p>{user?.name}</p>
              )}
            </div>
          </div>

          {/* Lifetime Usage and API keys */}
          <section className="mb-6">
            {/* <h2>Lifetime-Usage</h2> */}
            {/* Content related to Lifetime-Usage */}
          </section>

          <section className="space-y-4">
            <h2 className="text-lg">Gateways</h2>
            <table className="w-full table-auto text-left text-sm">
              <thead className="text-xs uppercase ">
                <tr>
                  <th className="px-4 py-1">Name</th>
                  <th className="px-4 py-1">Gateway</th>
                  <th className="px-4 py-1">Created</th>
                  <th className="px-4 py-1">Credits</th>
                  <th className="px-4 py-1">Requests</th>
                  <th className="px-4 py-1">Default Query Strategy</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {apiKeys &&
                  apiKeys.map((apiKey: any) => (
                    <tr key={apiKey.id}>
                      <td className="px-4 py-1">{apiKey.name}</td>
                      <td className="flex items-center gap-1 px-4 py-1">
                        {apiKey.api_key_hint}{' '}
                        <button
                          title="Copy"
                          onClick={() => handleCopy(apiKey.api_key)}
                        >
                          <IconCopy size="1em"></IconCopy>
                        </button>
                      </td>
                      <td className="px-4 py-1">
                        {DateTime.fromSeconds(
                          Number(apiKey.created_at),
                        ).toFormat('MMM dd, yyyy')}
                      </td>
                      <td className="px-4 py-1">{apiKey.credits}</td>
                      <td className="px-4 py-1">{apiKey.request_count}</td>
                      <td className="px-4 py-1">
                        {apiKey.default_query_strategy || 'Unspecified'}
                      </td>
                      <td className="flex px-4 py-1">
                        <button
                          className="rounded-md p-1 hover:bg-slate-600"
                          onClick={() => editApiKey(apiKey)}
                        >
                          <IconEdit size="1em"></IconEdit>
                        </button>
                        <button
                          className="ml-2 rounded-md p-1 hover:bg-slate-600"
                          onClick={() => deleteApiKey(apiKey)}
                        >
                          <IconTrash size="1em"></IconTrash>
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
            <div className="flex justify-between">
              <Button onClick={createApiKey}>
                {' '}
                <IconPlus size={'1em'} />
                Create Gateway
              </Button>
              <a
                href={requestDocsUrl}
                target="_blank"
                className="flex items-center gap-1 text-lg font-medium text-blue-600 hover:underline dark:text-blue-500"
              >
                Request guide
                <IconExternalLink size="1em" />
              </a>
            </div>
            <APIKeyOperations
              prompt={'Tell a joke'}
              url={process.env.NEXT_PUBLIC_VALIDATOR_ENDPOINT_BASE_URL!}
              apiKeys={apiKeys || []}
            />
          </section>
        </div>
      </main>
    </>
  );
};

export default Profile;
