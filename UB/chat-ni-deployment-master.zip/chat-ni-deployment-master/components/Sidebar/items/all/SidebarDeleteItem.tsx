import { FC, useContext, useRef, useState } from 'react';

import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

import styles from '../../../../styles/componentStyles/secondary.module.css';

import { ChatbotUIContext } from '@/context/context';
import { deleteAssistant } from '@/db/assistants';
import { deleteChat } from '@/db/chats';
import { deleteCollection } from '@/db/collections';
import { deleteFile } from '@/db/files';
import { deletePreset } from '@/db/presets';
import { deletePrompt } from '@/db/prompts';
import { deleteFileFromStorage } from '@/db/storage/files';
import { deleteTool } from '@/db/tools';
import { Tables } from '@/supabase/types';
import { ContentType, DataItemType } from '@/types';

interface SidebarDeleteItemProps {
  item: DataItemType;
  contentType: ContentType;
}

export const SidebarDeleteItem: FC<SidebarDeleteItemProps> = ({
  item,
  contentType,
}) => {
  const {
    setChats,
    setPresets,
    setPrompts,
    setFiles,
    setCollections,
    setAssistants,
    setTools,
  } = useContext(ChatbotUIContext);

  const buttonRef = useRef<HTMLButtonElement>(null);

  const [showDialog, setShowDialog] = useState(false);

  const deleteFunctions = {
    chats: async (chat: Tables<'chats'>) => {
      await deleteChat(chat.id);
    },
    presets: async (preset: Tables<'presets'>) => {
      await deletePreset(preset.id);
    },
    prompts: async (prompt: Tables<'prompts'>) => {
      await deletePrompt(prompt.id);
    },
    files: async (file: Tables<'files'>) => {
      await deleteFileFromStorage(file.file_path);
      await deleteFile(file.id);
    },
    collections: async (collection: Tables<'collections'>) => {
      await deleteCollection(collection.id);
    },
    assistants: async (assistant: Tables<'assistants'>) => {
      await deleteAssistant(assistant.id);
      setChats((prevState) =>
        prevState.filter((chat) => chat.assistant_id !== assistant.id),
      );
    }, //@ts-ignore
    tools: async (tool: Tables<'tools'>) => {
      //@ts-ignore
      await deleteTool(tool.id);
    },
  };

  const stateUpdateFunctions = {
    chats: setChats,
    presets: setPresets,
    prompts: setPrompts,
    files: setFiles,
    collections: setCollections,
    assistants: setAssistants,
    tools: setTools,
  };

  const handleDelete = async () => {
    const deleteFunction = deleteFunctions[contentType];
    const setStateFunction = stateUpdateFunctions[contentType];

    if (!deleteFunction || !setStateFunction) return;
    //@ts-ignore
    await deleteFunction(item as any);

    setStateFunction((prevItems: any) =>
      prevItems.filter((prevItem: any) => prevItem.id !== item.id),
    );

    setShowDialog(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter') {
      e.stopPropagation();
      buttonRef.current?.click();
    }
  };

  return (
    <Dialog open={showDialog} onOpenChange={setShowDialog}>
      <DialogTrigger asChild>
        <Button className="text-red-500" styleName={'deleteButton'}>
          Delete
        </Button>
      </DialogTrigger>

      <DialogContent onKeyDown={handleKeyDown} className={styles.popUpModals}>
        <DialogHeader>
          <DialogTitle>Delete {contentType.slice(0, -1)}</DialogTitle>

          <DialogDescription>
            Are you sure you want to delete {item.name}?
          </DialogDescription>
        </DialogHeader>

        <DialogFooter className={styles.popUpFooter}>
          <Button
            variant="ghost"
            onClick={() => setShowDialog(false)}
            styleName={'secondaryButton'}
          >
            Cancel
          </Button>

          <Button
            ref={buttonRef}
            variant="destructive"
            onClick={handleDelete}
            styleName={'deleteButton'}
          >
            Delete
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
