import { FC, useState } from 'react';

import { ModelIcon } from '@/components/models/ModelIcon';
import { ChatSettingsForm } from '@/components/ui/ChatSettingsForm';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

import { SidebarItem } from '../all/SidebarDisplayItem';

import { PRESET_NAME_MAX } from '@/db/limits';
import { Tables } from '@/supabase/types';

interface PresetItemProps {
  preset: Tables<'presets'>;
}

export const PresetItem: FC<PresetItemProps> = ({ preset }) => {
  const [name, setName] = useState(preset.name);
  const [isTyping, setIsTyping] = useState(false);
  const [description, setDescription] = useState(preset.description);
  const [presetChatSettings, setPresetChatSettings] = useState({
    model: preset.model,
    prompt: preset.prompt,
    temperature: preset.temperature,
    contextLength: preset.context_length,
    includeProfileContext: preset.include_profile_context,
    includeWorkspaceInstructions: preset.include_workspace_instructions,
  });

  return (
    <SidebarItem
      item={preset}
      isTyping={isTyping}
      contentType="presets"
      icon={
        <ModelIcon modelId={presetChatSettings.model} height={30} width={30} />
      }
      updateState={{
        name,
        description,
        include_profile_context: presetChatSettings.includeProfileContext,
        include_workspace_instructions:
          presetChatSettings.includeWorkspaceInstructions,
        context_length: presetChatSettings.contextLength,
        model: presetChatSettings.model,
        prompt: presetChatSettings.prompt,
        temperature: presetChatSettings.temperature,
      }}
      renderInputs={() => (
        <>
          <div className="space-y-1">
            <Label>Name</Label>

            <Input
              placeholder="Preset name..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={PRESET_NAME_MAX}
            />
          </div>

          <ChatSettingsForm
            chatSettings={presetChatSettings as any}
            onChangeChatSettings={setPresetChatSettings}
            useAdvancedDropdown={true}
          />
        </>
      )}
    />
  );
};
