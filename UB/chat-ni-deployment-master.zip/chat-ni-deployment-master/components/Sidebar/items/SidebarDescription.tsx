import { FC, useEffect, useState } from 'react';

import { ContentType } from '@/types';

interface SidebarDescriptionProps {
  contentType: ContentType;
  searchTerm: string;
  setSearchTerm: Function;
}

export const SidebarDescription: FC<SidebarDescriptionProps> = ({
  contentType,
  searchTerm,
  setSearchTerm,
}) => {
  const [description, setDescription] = useState('');
  useEffect(() => {
    if (contentType === 'prompts') {
      setDescription(
        'Prompts allow you to save and quickly access custom prompts for conversing with a selected model, simply by typing "/" in the chat bar.',
      );
    } else if (contentType === 'files') {
      setDescription(
        'Files support the upload of documents such as PDFs and DOCs, enabling the AI to analyze and integrate their content within the chat session. Please note that the file size must be less than 5MB to ensure a smooth upload process.',
      );
    }
  }, [contentType]);

  if (contentType === 'prompts' || contentType === 'files') {
    return (
      <div
        style={{
          paddingTop: '16px',
          borderRadius: '8px',
        }}
      >
        <h2
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: '24px',
            fontWeight: '400',
            lineHeight: '29.05px',
            margin: '0 0 8px 0',
            color: 'fff',
          }}
        >
          {contentType.charAt(0).toUpperCase() +
            contentType.slice(1, contentType.length - 1)}
        </h2>
        <div
          style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: '14px',
            fontWeight: '400',
            lineHeight: '16.8px',
            marginTop: '0',
            marginBottom: '0',
            color: 'var(--Dark-Theme-Storm, #A5A5B3)',
          }}
        >
          {description}
        </div>
      </div>
    );
  }
  return '';
};
