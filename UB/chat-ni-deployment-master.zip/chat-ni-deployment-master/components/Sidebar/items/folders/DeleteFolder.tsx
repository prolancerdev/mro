import { IconTrash } from '@tabler/icons-react';
import { FC, useContext, useRef, useState } from 'react';

import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

import styles from '../../../../styles/componentStyles/secondary.module.css';

import { ChatbotUIContext } from '@/context/context';
import { deleteFolder } from '@/db/folders';
import { Tables } from '@/supabase/types';

interface DeleteFolderProps {
  folder: Tables<'folders'>;
}

export const DeleteFolder: FC<DeleteFolderProps> = ({ folder }) => {
  const { setFolders, setChats } = useContext(ChatbotUIContext);

  const buttonRef = useRef<HTMLButtonElement>(null);

  const [showFolderDialog, setShowFolderDialog] = useState(false);

  const handleDeleteFolder = async () => {
    await deleteFolder(folder.id);

    setFolders((prevState) => prevState.filter((c) => c.id !== folder.id));

    setShowFolderDialog(false);

    setChats((prevState) =>
      prevState.map((c) =>
        c.folder_id === folder.id ? { ...c, folder_id: null } : c,
      ),
    );
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter') {
      buttonRef.current?.click();
    }
  };

  return (
    <Dialog open={showFolderDialog} onOpenChange={setShowFolderDialog}>
      <DialogTrigger asChild>
        <IconTrash className="hover:opacity-50" size={18} />
      </DialogTrigger>

      <DialogContent onKeyDown={handleKeyDown} className={styles.popUpModals}>
        <DialogHeader>
          <DialogTitle>Delete {folder.name}</DialogTitle>

          <DialogDescription>
            Are you sure you want to delete this folder?
          </DialogDescription>
        </DialogHeader>

        <DialogFooter className={styles.popUpFooter}>
          <Button
            variant="ghost"
            onClick={() => setShowFolderDialog(false)}
            styleName={'secondaryButton'}
          >
            Cancel
          </Button>

          <Button
            ref={buttonRef}
            variant="destructive"
            onClick={handleDeleteFolder}
            styleName={'deleteButton'}
          >
            Delete
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
