import { IconEdit } from '@tabler/icons-react';
import { FC, useContext, useRef, useState } from 'react';

import Image from 'next/image';

import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

import edit from '../../../../assets/layoutIcons/edit.png';
import styles from '../../../../styles/componentStyles/secondary.module.css';

import { ChatbotUIContext } from '@/context/context';
import { updateChat } from '@/db/chats';
import { Tables } from '@/supabase/types';

interface UpdateChatProps {
  chat: Tables<'chats'>;
}

export const UpdateChat: FC<UpdateChatProps> = ({ chat }) => {
  const { setChats } = useContext(ChatbotUIContext);

  const buttonRef = useRef<HTMLButtonElement>(null);

  const [showChatDialog, setShowChatDialog] = useState(false);
  const [name, setName] = useState(chat.name);

  const handleUpdateChat = async (e: React.MouseEvent<HTMLButtonElement>) => {
    const updatedChat = await updateChat(chat.id, {
      name,
    });
    setChats((prevState) =>
      prevState.map((c) => (c.id === chat.id ? updatedChat : c)),
    );

    setShowChatDialog(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter') {
      buttonRef.current?.click();
    }
  };

  return (
    <Dialog open={showChatDialog} onOpenChange={setShowChatDialog}>
      <DialogTrigger asChild>
        {/* <IconEdit className="hover:opacity-50" size={18} /> */}
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
        >
          <mask
            id="mask0_228_140"
            style={{ maskType: 'alpha' }}
            maskUnits="userSpaceOnUse"
            x="0"
            y="0"
            width="24"
            height="24"
          >
            <rect width="24" height="24" fill="#D9D9D9" />
          </mask>
          <g mask="url(#mask0_228_140)">
            <path
              d="M5 19H6.4L15.025 10.375L13.625 8.975L5 17.6V19ZM19.3 8.925L15.05 4.725L16.45 3.325C16.8333 2.94167 17.3042 2.75 17.8625 2.75C18.4208 2.75 18.8917 2.94167 19.275 3.325L20.675 4.725C21.0583 5.10833 21.2583 5.57083 21.275 6.1125C21.2917 6.65417 21.1083 7.11667 20.725 7.5L19.3 8.925ZM17.85 10.4L7.25 21H3V16.75L13.6 6.15L17.85 10.4Z"
              fill="#F5FAFF"
            />
          </g>
        </svg>
      </DialogTrigger>

      <DialogContent onKeyDown={handleKeyDown} className={styles.popUpModals}>
        <div
          style={{
            textAlign: 'center',
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <div>
            <DialogHeader>
              <DialogTitle>Edit Chat</DialogTitle>
            </DialogHeader>
          </div>
        </div>

        <div className="space-y-1">
          <Label>Name</Label>

          <Input
            styleName={'modalInput'}
            // style={{ backgroundColor: '#2A2A32', borderRadius: '10px' }}
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        <DialogFooter className={styles.popUpFooter}>
          <Button
            styleName={'secondaryButton'}
            onClick={() => setShowChatDialog(false)}
          >
            Cancel
          </Button>

          <Button
            styleName={'primaryButton'}
            ref={buttonRef}
            onClick={handleUpdateChat}
          >
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
