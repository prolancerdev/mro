import { IconTrash } from '@tabler/icons-react';
import { FC, useContext, useRef, useState } from 'react';

import Image from 'next/image';

import useHotkey from '@/lib/hooks/use-hotkey';

import { useChatHandler } from '@/components/Chat/chat-hooks/UseChatHandler';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

import deleteIcon from '../../../../assets/layoutIcons/delete.png';
import styles from '../../../../styles/componentStyles/secondary.module.css';

import { ChatbotUIContext } from '@/context/context';
import { deleteChat } from '@/db/chats';
import { Tables } from '@/supabase/types';

interface DeleteChatProps {
  chat: Tables<'chats'>;
}

export const DeleteChat: FC<DeleteChatProps> = ({ chat }) => {
  useHotkey('Backspace', () => setShowChatDialog(true));

  const { setChats } = useContext(ChatbotUIContext);
  const { handleNewChat } = useChatHandler();

  const buttonRef = useRef<HTMLButtonElement>(null);

  const [showChatDialog, setShowChatDialog] = useState(false);

  const handleDeleteChat = async () => {
    await deleteChat(chat.id);

    setChats((prevState) => prevState.filter((c) => c.id !== chat.id));

    setShowChatDialog(false);

    handleNewChat();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter') {
      buttonRef.current?.click();
    }
  };

  return (
    <Dialog open={showChatDialog} onOpenChange={setShowChatDialog}>
      <DialogTrigger asChild>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
        >
          <path
            d="M15.5 3.11111L14.5 2H9.5L8.5 3.11111H5V5.33333H19V3.11111H15.5ZM6 19.7778C6 21 6.9 22 8 22H16C17.1 22 18 21 18 19.7778V6.44444H6V19.7778ZM8 8.66667H16V19.7778H8V8.66667Z"
            fill="#E7EFF8"
          />
        </svg>
        {/* <IconTrash className="hover:opacity-50" size={18} /> */}
      </DialogTrigger>

      <DialogContent onKeyDown={handleKeyDown} className={styles.popUpModals}>
        <DialogHeader>
          <DialogTitle>Delete {chat.name}</DialogTitle>

          <DialogDescription>
            Are you sure you want to delete this chat?
          </DialogDescription>
        </DialogHeader>

        <DialogFooter className={styles.popUpFooter}>
          <Button
            styleName={'secondaryButton'}
            onClick={() => setShowChatDialog(false)}
          >
            Cancel
          </Button>

          <Button
            styleName={'deleteButton'}
            ref={buttonRef}
            onClick={handleDeleteChat}
          >
            Delete
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
