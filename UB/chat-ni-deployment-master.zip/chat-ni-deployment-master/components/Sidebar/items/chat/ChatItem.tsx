// import { IconRobotFace } from '@tabler/icons-react';
// import { FC, useContext, useRef } from 'react';
// import Image from 'next/image';
// import { useParams, useRouter } from 'next/navigation';
// import { ModelIcon } from '@/components/models/ModelIcon';
// import { WithTooltip } from '@/components/ui/WithTooltip';
// import chatImage from "../../../../assets/layoutIcons/chat.png"
// import { DeleteChat } from './DeleteChat';
// import { UpdateChat } from './UpdateChat';
// import { ChatbotUIContext } from '@/context/context';
// import { LLM_LIST } from '@/lib/models/llm/llm-list';
// import { cn } from '@/lib/utils';
// import { Tables } from '@/supabase/types';
// import { LLM } from '@/types';
// interface ChatItemProps {
//   chat: Tables<'chats'>;
// }
// export const ChatItem: FC<ChatItemProps> = ({ chat }) => {
//   const {
//     selectedChat,
//     availableLocalModels,
//     assistantImages,
//     availableOpenRouterModels,
//   } = useContext(ChatbotUIContext);
//   const router = useRouter();
//   const params = useParams(); //@ts-ignore
//   const isActive = params.chatid === chat.id || selectedChat?.id === chat.id;
//   const itemRef = useRef<HTMLDivElement>(null);
//   const handleClick = () => {
//     router.push(`/chat/${chat.id}`);
//   };
//   const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
//     if (e.key === 'Enter') {
//       e.stopPropagation();
//       itemRef.current?.click();
//     }
//   };
//   const MODEL_DATA = [
//     ...LLM_LIST,
//     ...availableLocalModels,
//     ...availableOpenRouterModels,
//   ].find((llm) => llm.modelId === chat.model) as LLM;
//   const assistantImage = assistantImages.find(
//     (image) => image.assistantId === chat.assistant_id,
//   )?.base64;
//   return (
//     <div
//       ref={itemRef}
//       className={cn(
//         'hover:bg-accent focus:bg-accent flex w-full cursor-pointer items-center rounded p-2 hover:opacity-50 focus:outline-none',
//         isActive && 'bg-accent',
//       )}
//       tabIndex={0}
//       onKeyDown={handleKeyDown}
//       onClick={handleClick}
//     >
//       {/* {chat.assistant_id ? (
//         assistantImage ? (
//           <Image
//             className="rounded"
//             src={assistantImage}
//             alt="Assistant image"
//             width={30}
//             height={30}
//           />
//         ) : (
//           <IconRobotFace
//             className="bg-primary text-secondary border-primary rounded border-[1px] p-1"
//             size={30}
//           />
//         )
//       ) : (
//         <WithTooltip
//           delayDuration={200}
//           display={<div>{MODEL_DATA?.modelName}</div>}
//           trigger={
//             <ModelIcon modelId={MODEL_DATA?.modelId} height={30} width={30} />
//           }
//         />
//       )} */}
//       <div>
//         <Image src={chatImage} alt="chat" style={{width: "1.5rem", height: "1.5rem"}}/>
//       </div>
//       <div className="ml-3 flex-1 truncate text-sm font-semibold">
//         {chat.name}
//       </div>
//       {isActive && (
//         <div
//           onClick={(e) => {
//             e.stopPropagation();
//             e.preventDefault();
//           }}
//           className="ml-2 flex space-x-2"
//         >
//           <UpdateChat chat={chat} />
//           <DeleteChat chat={chat} />
//         </div>
//       )}
//     </div>
//   );
// };
import { IconRobotFace } from '@tabler/icons-react';
import { FC, useContext, useRef } from 'react';

import Image from 'next/image';
import { useParams, useRouter } from 'next/navigation';

import { ModelIcon } from '@/components/models/ModelIcon';
import { WithTooltip } from '@/components/ui/WithTooltip';

import chatImage from '../../../../assets/layoutIcons/chat.png';
import styles from '../../../../styles/componentStyles/secondary.module.css';
import style from '../../../../styles/componentStyles/secondary.module.css';
import { DeleteChat } from './DeleteChat';
import { UpdateChat } from './UpdateChat';

import { ChatbotUIContext } from '@/context/context';
import { LLM_LIST } from '@/lib/models/llm/llm-list';
import { cn } from '@/lib/utils';
import { Tables } from '@/supabase/types';
import { LLM } from '@/types';

interface ChatItemProps {
  chat: Tables<'chats'>;
}

export const ChatItem: FC<ChatItemProps> = ({ chat }) => {
  const {
    selectedChat,
    availableLocalModels,
    assistantImages,
    availableOpenRouterModels,
  } = useContext(ChatbotUIContext);

  const router = useRouter();
  const params = useParams(); //@ts-ignore
  const isActive = params.chatid === chat.id || selectedChat?.id === chat.id;

  const itemRef = useRef<HTMLDivElement>(null);

  const handleClick = () => {
    router.push(`/chat/${chat.id}`);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter') {
      e.stopPropagation();
      itemRef.current?.click();
    }
  };

  const MODEL_DATA = [
    ...LLM_LIST,
    ...availableLocalModels,
    ...availableOpenRouterModels,
  ].find((llm) => llm.modelId === chat.model) as LLM;

  const assistantImage = assistantImages.find(
    (image) => image.assistantId === chat.assistant_id,
  )?.base64;

  return (
    <div
      ref={itemRef}
      className={`${cn(
        'flex w-full cursor-pointer items-center rounded p-2  focus:outline-none',
        isActive && 'bg-pink-100',
      )} ${styles.selectHover}`}
      style={{
        backgroundColor: isActive ? '#323243' : '',
        // borderRadius: isActive ? '8px' : undefined,
      }}
      tabIndex={0}
      onKeyDown={handleKeyDown}
      onClick={handleClick}
    >
      <div>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
        >
          <mask
            id="mask0_228_566"
            style={{ maskType: 'alpha' }}
            maskUnits="userSpaceOnUse"
            x="0"
            y="0"
            width="24"
            height="24"
          >
            <rect width="24" height="24" fill="#D9D9D9" />
          </mask>
          <g mask="url(#mask0_228_566)">
            <path
              d="M6 14H14V12H6V14ZM6 11H18V9H6V11ZM6 8H18V6H6V8ZM2 22V4C2 3.45 2.19583 2.97917 2.5875 2.5875C2.97917 2.19583 3.45 2 4 2H20C20.55 2 21.0208 2.19583 21.4125 2.5875C21.8042 2.97917 22 3.45 22 4V16C22 16.55 21.8042 17.0208 21.4125 17.4125C21.0208 17.8042 20.55 18 20 18H6L2 22ZM5.15 16H20V4H4V17.125L5.15 16Z"
              fill="#F5FAFF"
            />
          </g>
        </svg>
      </div>

      <div
        className={`ml-3 flex-1 truncate text-sm ${style.sidebarCategoryItem}`}
      >
        {chat.name}
      </div>

      {isActive && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            e.preventDefault();
          }}
          className="ml-2 flex space-x-2"
        >
          <UpdateChat chat={chat} />
          <DeleteChat chat={chat} />
        </div>
      )}
    </div>
  );
};
