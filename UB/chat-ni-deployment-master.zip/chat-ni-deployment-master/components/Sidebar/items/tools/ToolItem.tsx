import { IconBolt } from '@tabler/icons-react';
import { FC, useState } from 'react';

import { TextareaAutosize } from '@/components/ui/TextareaAutosize';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

import { SidebarItem } from '../all/SidebarDisplayItem';

import { TOOL_DESCRIPTION_MAX, TOOL_NAME_MAX } from '@/db/limits';
import { Tables } from '@/supabase/types';

interface ToolItemProps {
  //@ts-ignore
  tool: Tables<'tools'>;
}

export const ToolItem: FC<ToolItemProps> = ({ tool }) => {
  //@ts-ignore
  const [name, setName] = useState(tool.name);
  const [isTyping, setIsTyping] = useState(false); //@ts-ignore
  const [description, setDescription] = useState(tool.description); //@ts-ignore
  const [url, setUrl] = useState(tool.url); //@ts-ignore
  const [schema, setSchema] = useState(tool.schema as string);

  return (
    <SidebarItem
      item={tool}
      isTyping={isTyping}
      contentType="tools"
      icon={<IconBolt size={30} />}
      updateState={{ name, description, url, schema }}
      renderInputs={() => (
        <>
          <div className="space-y-1">
            <Label>Name</Label>

            <Input
              placeholder="Tool name..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={TOOL_NAME_MAX}
            />
          </div>

          <div className="space-y-1">
            <Label>Description</Label>

            <Input
              placeholder="Tool description..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={TOOL_DESCRIPTION_MAX}
            />
          </div>

          {/* <div className="space-y-1">
            <Label>URL</Label>

            <Input
              placeholder="Tool url..."
              value={url}
              onChange={e => setUrl(e.target.value)}
            />
          </div> */}

          {/* <div className="space-y-3 pt-4 pb-3">
            <div className="space-x-2 flex items-center">
              <Checkbox />

              <Label>Web Browsing</Label>
            </div>

            <div className="space-x-2 flex items-center">
              <Checkbox />

              <Label>Image Generation</Label>
            </div>

            <div className="space-x-2 flex items-center">
              <Checkbox />

              <Label>Code Interpreter</Label>
            </div>
          </div> */}

          <div className="space-y-1">
            <Label>Schema</Label>

            <TextareaAutosize
              placeholder={`{
                "openapi": "3.1.0",
                "info": {
                  "title": "Get weather data",
                  "description": "Retrieves current weather data for a location.",
                  "version": "v1.0.0"
                },
                "servers": [
                  {
                    "url": "https://weather.example.com"
                  }
                ],
                "paths": {
                  "/location": {
                    "get": {
                      "description": "Get temperature for a specific location",
                      "operationId": "GetCurrentWeather",
                      "parameters": [
                        {
                          "name": "location",
                          "in": "query",
                          "description": "The city and state to retrieve the weather for",
                          "required": true,
                          "schema": {
                            "type": "string"
                          }
                        }
                      ],
                      "deprecated": false
                    }
                  }
                },
                "components": {
                  "schemas": {}
                }
              }`}
              value={schema}
              onValueChange={setSchema}
              minRows={20}
            />
          </div>
        </>
      )}
    />
  );
};
