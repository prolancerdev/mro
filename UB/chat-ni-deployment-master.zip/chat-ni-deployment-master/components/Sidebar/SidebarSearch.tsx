import { FC } from 'react';

import { Input } from '../ui/input';

import { ContentType } from '@/types';

interface SidebarSearchProps {
  contentType: ContentType;
  searchTerm: string;
  setSearchTerm: Function;
}

export const SidebarSearch: FC<SidebarSearchProps> = ({
  contentType,
  searchTerm,
  setSearchTerm,
}) => {
  return (
    <Input
      styleName={'searchInputStyle'}
      placeholder={`Search ${contentType}...`}
      value={searchTerm}
      onChange={(e) => setSearchTerm(e.target.value)}
    />
  );
};
