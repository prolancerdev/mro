import { FC } from 'react';

interface Props {
  text: string;
  icon: JSX.Element;
  iconRight?: JSX.Element;
  onClick: () => void;
  textClassName?: string;
}

export const SidebarButton: FC<Props> = ({
  text,
  icon,
  iconRight,
  onClick,
  textClassName,
}) => {
  return (
    <button
      className="flex w-full cursor-pointer select-none items-center gap-2 rounded-md p-3 text-[14px] leading-3 text-[#F5FAFF] transition-colors duration-300 hover:bg-[#323243]"
      onClick={onClick}
    >
      {icon}
      <span className={'overflow-clip text-ellipsis ' + textClassName}>
        {text}
      </span>
      <div className="shrink">{iconRight}</div>
    </button>
  );
};
