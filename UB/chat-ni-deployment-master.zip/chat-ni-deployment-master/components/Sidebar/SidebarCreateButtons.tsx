import { IconFolderPlus, IconPlus } from '@tabler/icons-react';
import { FC, useContext, useState } from 'react';

import { useChatHandler } from '@/components/Chat/chat-hooks/UseChatHandler';

import styles from '../../styles/componentStyles/secondary.module.css';
import { Button } from '../ui/button';
import { CreateAssistant } from './items/assistants/CreateAssistant';
import { CreateCollection } from './items/collections/CreateCollection';
import { CreateFile } from './items/files/CreateFile';
import { CreatePreset } from './items/presets/CreatePreset';
import { CreatePrompt } from './items/prompts/CreatePrompt';
import { CreateTool } from './items/tools/CreateTool';

import { ChatbotUIContext } from '@/context/context';
import { createFolder } from '@/db/folders';
import { ContentType } from '@/types';

interface SidebarCreateButtonsProps {
  contentType: ContentType;
  hasData: boolean;
}

export const SidebarCreateButtons: FC<SidebarCreateButtonsProps> = ({
  contentType,
  hasData,
}) => {
  const { profile, selectedWorkspace, folders, setFolders } =
    useContext(ChatbotUIContext);
  const { handleNewChat } = useChatHandler();

  const [isCreatingPrompt, setIsCreatingPrompt] = useState(false);
  const [isCreatingPreset, setIsCreatingPreset] = useState(false);
  const [isCreatingFile, setIsCreatingFile] = useState(false);
  const [isCreatingCollection, setIsCreatingCollection] = useState(false);
  const [isCreatingAssistant, setIsCreatingAssistant] = useState(false);
  const [isCreatingTool, setIsCreatingTool] = useState(false);

  const handleCreateFolder = async () => {
    if (!profile) return;
    if (!selectedWorkspace) return;

    const createdFolder = await createFolder({
      user_id: profile.user_id,
      workspace_id: selectedWorkspace.id,
      name: 'New Folder',
      description: '',
      type: contentType,
    });
    setFolders([...folders, createdFolder]);
  };

  const getCreateFunction = () => {
    switch (contentType) {
      case 'chats':
        return async () => {
          handleNewChat();
        };

      case 'presets':
        return async () => {
          setIsCreatingPreset(true);
        };

      case 'prompts':
        return async () => {
          setIsCreatingPrompt(true);
        };

      case 'files':
        return async () => {
          setIsCreatingFile(true);
        };

      case 'collections':
        return async () => {
          setIsCreatingCollection(true);
        };

      case 'assistants':
        return async () => {
          setIsCreatingAssistant(true);
        };

      case 'tools':
        return async () => {
          setIsCreatingTool(true);
        };

      default:
        break;
    }
  };

  return (
    <div className={`flex w-full space-x-2 ${styles.createButtonsContainer}`}>
      <Button
        className={`flex h-[36px] grow ${styles.primaryButton}`}
        onClick={getCreateFunction()}
      >
        <IconPlus className="mr-1" size={20} />
        New{' '}
        {contentType.charAt(0).toUpperCase() +
          contentType.slice(1, contentType.length - 1)}
      </Button>

      {hasData && (
        <Button className="size-[36px] p-1" onClick={handleCreateFolder}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="16"
            viewBox="0 0 20 16"
            fill="none"
          >
            <path
              d="M12 12H14V10H16V8H14V6H12V8H10V10H12V12ZM2 16C1.45 16 0.979167 15.8042 0.5875 15.4125C0.195833 15.0208 0 14.55 0 14V2C0 1.45 0.195833 0.979167 0.5875 0.5875C0.979167 0.195833 1.45 0 2 0H8L10 2H18C18.55 2 19.0208 2.19583 19.4125 2.5875C19.8042 2.97917 20 3.45 20 4V14C20 14.55 19.8042 15.0208 19.4125 15.4125C19.0208 15.8042 18.55 16 18 16H2ZM2 14H18V4H9.175L7.175 2H2V14Z"
              fill="#E7EFF8"
            />
          </svg>
          {/* <IconFolderPlus size={20} /> */}
        </Button>
      )}

      {isCreatingPrompt && (
        <CreatePrompt
          isOpen={isCreatingPrompt}
          onOpenChange={setIsCreatingPrompt}
        />
      )}

      {isCreatingPreset && (
        <CreatePreset
          isOpen={isCreatingPreset}
          onOpenChange={setIsCreatingPreset}
        />
      )}

      {isCreatingFile && (
        <CreateFile isOpen={isCreatingFile} onOpenChange={setIsCreatingFile} />
      )}

      {isCreatingCollection && (
        <CreateCollection
          isOpen={isCreatingCollection}
          onOpenChange={setIsCreatingCollection}
        />
      )}

      {isCreatingAssistant && (
        <CreateAssistant
          isOpen={isCreatingAssistant}
          onOpenChange={setIsCreatingAssistant}
        />
      )}

      {isCreatingTool && (
        <CreateTool isOpen={isCreatingTool} onOpenChange={setIsCreatingTool} />
      )}
    </div>
  );
};
