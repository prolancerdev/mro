import { FC, useContext } from 'react';

import { SIDEBAR_WIDTH } from '../ui/dashboard';
import { TabsContent } from '../ui/tabs';
import { WorkspaceSwitcher } from '../utility/workspace-switcher';
import { WorkspaceSettings } from '../workspace/workspace-settings';
//@ts-ignore
import SidebarContent from './SidebarContent';

import { ChatbotUIContext } from '@/context/context';
import { Tables } from '@/supabase/types';
import { ContentType } from '@/types';

interface SidebarProps {
  contentType: ContentType;
  showSidebar: boolean;
}

const Sidebar: FC<SidebarProps> = ({ contentType, showSidebar }) => {
  const {
    folders,
    chats,
    presets,
    prompts,
    files,
    collections,
    assistants,
    tools,
  } = useContext(ChatbotUIContext);

  const chatFolders = folders.filter((folder) => folder.type === 'chats');
  const presetFolders = folders.filter((folder) => folder.type === 'presets');
  const promptFolders = folders.filter((folder) => folder.type === 'prompts');
  const filesFolders = folders.filter((folder) => folder.type === 'files');
  const collectionFolders = folders.filter(
    (folder) => folder.type === 'collections',
  );
  const assistantFolders = folders.filter(
    (folder) => folder.type === 'assistants',
  );
  const toolFolders = folders.filter((folder) => folder.type === 'tools');

  const renderSidebarContent = (
    contentType: ContentType,
    data: any[],
    folders: Tables<'folders'>[],
  ) => {
    return (
      <SidebarContent contentType={contentType} data={data} folders={folders} />
    );
  };

  return (
    <TabsContent
      className="m-0 w-full space-y-2"
      style={{
        // Sidebar - SidebarSwitcher
        minWidth: showSidebar ? `calc(${SIDEBAR_WIDTH}px - 60px)` : '0px',
        maxWidth: showSidebar ? `calc(${SIDEBAR_WIDTH}px - 60px)` : '0px',
        width: showSidebar ? `calc(${SIDEBAR_WIDTH}px - 60px)` : '0px',
      }}
      value={contentType}
    >
      <div className="flex h-full flex-col p-3">
        {/* <div
          className="flex items-center border-b-2 pb-2"
          style={{
            border: 'none',
            justifyContent: 'space-between',
            display: 'flex',
            flexDirection: 'row',
            backgroundColor: "pink"
          }}
        >
          <div>
            <WorkspaceSwitcher />
          </div>

          <div>
            <WorkspaceSettings />
          </div>
        </div> */}
        <div
          className="flex items-center border-b-2 pb-2"
          style={{
            border: 'none',
            justifyContent: 'space-between',
            display: 'flex',
            flexDirection: 'row',
            // backgroundColor: "pink"
          }}
        >
          <div style={{ flex: 1 }}>
            <WorkspaceSwitcher />
          </div>

          <div style={{ flex: 0, marginRight: '4px' }}>
            <WorkspaceSettings />
          </div>
        </div>

        {(() => {
          switch (contentType) {
            case 'chats':
              return renderSidebarContent('chats', chats, chatFolders);

            case 'presets':
              return renderSidebarContent('presets', presets, presetFolders);

            case 'prompts':
              return renderSidebarContent('prompts', prompts, promptFolders);

            case 'files':
              return renderSidebarContent('files', files, filesFolders);

            case 'collections':
              return renderSidebarContent(
                'collections',
                collections,
                collectionFolders,
              );

            case 'assistants':
              return renderSidebarContent(
                'assistants',
                assistants,
                assistantFolders,
              );

            case 'tools':
              return renderSidebarContent('tools', tools, toolFolders);

            default:
              return null;
          }
        })()}
      </div>
    </TabsContent>
  );
};
export default Sidebar;
