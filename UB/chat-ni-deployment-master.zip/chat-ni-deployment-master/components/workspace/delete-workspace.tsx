import { FC, useContext, useRef, useState } from 'react';

import { useChatHandler } from '@/components/Chat/chat-hooks/UseChatHandler';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

import styles from '../../styles/componentStyles/secondary.module.css';
import { Input } from '../ui/input';

import { ChatbotUIContext } from '@/context/context';
import { deleteWorkspace } from '@/db/workspaces';
import { Tables } from '@/supabase/types';

interface DeleteWorkspaceProps {
  workspace: Tables<'workspaces'>;
  onDelete: () => void;
}

export const DeleteWorkspace: FC<DeleteWorkspaceProps> = ({
  workspace,
  onDelete,
}) => {
  const { setWorkspaces, setSelectedWorkspace } = useContext(ChatbotUIContext);
  const { handleNewChat } = useChatHandler();

  const buttonRef = useRef<HTMLButtonElement>(null);

  const [showWorkspaceDialog, setShowWorkspaceDialog] = useState(false);

  const [name, setName] = useState('');

  const handleDeleteWorkspace = async () => {
    await deleteWorkspace(workspace.id);

    setWorkspaces((prevWorkspaces) => {
      const filteredWorkspaces = prevWorkspaces.filter(
        (w) => w.id !== workspace.id,
      );

      setSelectedWorkspace(filteredWorkspaces[0]);

      return filteredWorkspaces;
    });

    setShowWorkspaceDialog(false);
    onDelete();

    handleNewChat();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter') {
      buttonRef.current?.click();
    }
  };

  return (
    <Dialog open={showWorkspaceDialog} onOpenChange={setShowWorkspaceDialog}>
      <DialogTrigger asChild>
        <Button styleName={'deleteButton'}>Delete</Button>
      </DialogTrigger>

      <DialogContent onKeyDown={handleKeyDown} className={styles.popUpModals}>
        <DialogHeader>
          <DialogTitle>Delete {workspace.name}</DialogTitle>

          <DialogDescription className="space-y-1">
            WARNING: Deleting a workspace will delete all of its data.
          </DialogDescription>
        </DialogHeader>

        <Input
          className="mt-4"
          placeholder="Type the name of this workspace to confirm"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <DialogFooter className={styles.popUpFooter}>
          <Button
            variant="ghost"
            onClick={() => setShowWorkspaceDialog(false)}
            styleName={'secondaryButton'}
          >
            Cancel
          </Button>

          <Button
            styleName={'deleteButton'}
            ref={buttonRef}
            variant="destructive"
            onClick={handleDeleteWorkspace}
            disabled={name !== workspace.name}
          >
            Delete
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
