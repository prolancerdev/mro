interface Props {
  onClick?: () => void;
  children: React.ReactNode;
}

const DropdownButton = ({ onClick, children }: Props) => {
  return (
    <button
      className="flex grow cursor-pointer items-center gap-3 rounded px-3 py-4 text-sm text-white transition-colors duration-200 hover:bg-[#323243]"
      onClick={onClick}
    >
      {children}
    </button>
  );
};

export default DropdownButton;
