// import React, { useState, useEffect } from 'react';
// import loginStyles from '../../styles/OnBoardingStyles/LoginPage.module.css';
// import { supabase } from '@/lib/supabase/browser-client';
// import { toast } from 'sonner';
// interface MailSuccessProps {
//   title: string;
//   email: string;
//   mailSuccessType: string;
//   onChangeEmail: () => void;
//   setEmail: (email: string) => void;
//   resetPassword: (event: React.MouseEvent<HTMLButtonElement>) => Promise<void>;
// }
// const MailSuccess: React.FC<MailSuccessProps> = ({
//   title,
//   setEmail,
//   onChangeEmail,
//   email,
//   mailSuccessType,
//   resetPassword,
// }) => {
//   const [clickCount, setClickCount] = useState(() => Number(localStorage.getItem('clickCount')) || 0);
//   const [isCooldown, setIsCooldown] = useState(() => Date.now() < Number(localStorage.getItem('cooldownExpire')));
//   useEffect(() => {
//     const cooldownExpire = Number(localStorage.getItem('cooldownExpire'));
//     if (isCooldown && cooldownExpire) {
//       const timeout = setTimeout(() => {
//         setIsCooldown(false);
//         localStorage.removeItem('clickCount');
//         localStorage.removeItem('cooldownExpire');
//         setClickCount(0);
//       }, cooldownExpire - Date.now());
//       return () => clearTimeout(timeout);
//     }
//   }, [isCooldown]);
//   const executeWithLimit = async (callback: () => Promise<void>) => {
//     if (isCooldown) {
//       toast.info('Please try again after 30 minutes.', {
//         position: 'top-right',
//         duration: 5000,
//       });
//       return;
//     }
//     if (clickCount >= 2) {
//       const newExpireTime = Date.now() + 1800000; // 30 minutes from now
//       localStorage.setItem('cooldownExpire', newExpireTime.toString());
//       localStorage.setItem('clickCount', '2');
//       setIsCooldown(true);
//       toast.info('You have reached the limit for actions. Please try again in 30 minutes.', {
//         position: 'top-right',
//         duration: 5000,
//       });
//       return;
//     }
//     await callback();
//     setClickCount(prev => prev + 1);
//     localStorage.setItem('clickCount', (clickCount + 1).toString());
//   };
//   const handleResendConfirmation = async () => {
//     const { data, error } = await supabase.auth.resend({
//       type: 'signup',
//       email: email,
//     });
//     if (data) {
//       toast.success('Confirmation email resent successfully', {
//         position: 'top-right',
//         duration: 5000,
//       });
//     } else if (error) {
//       toast.error(`Error resending confirmation email: ${error?.message}`, {
//         position: 'top-right',
//         duration: 5000,
//       });
//     }
//   };
//   const handleMailSuccess = (e: React.MouseEvent<HTMLButtonElement>) => {
//     e.preventDefault(); // Prevent default button click behavior
//     if (mailSuccessType === 'reset') {
//       executeWithLimit(() => resetPassword(e)); // Use executeWithLimit for resetPassword
//     } else if (mailSuccessType === 'signup') {
//       executeWithLimit(handleResendConfirmation); // Use executeWithLimit for handleResendConfirmation
//     }
//   };
//   return (
//     <>
//       <div className={loginStyles.MailSuccessHeading}>{title}</div>
//       <p className={loginStyles.MailSuccessText}>
//         We have sent an email to{' '}
//         <span className={loginStyles.MailSuccessLinks}>
//           {email ? email : 'your email'}
//         </span>{' '}
//         with a verification link. The link will expire in 24 hours.
//       </p>
//       <br />
//       <p className={loginStyles.MailSuccessText} onClick={onChangeEmail}>
//         Entered the wrong email?{' '}
//         <span className={loginStyles.MailSuccessLinks}>
//           Click here to update.
//         </span>
//       </p>
//       <br />
//       <button
//         onClick={handleMailSuccess}
//         className={loginStyles.MailSuccessText}
//       >
//         Did not receive an email?{' '}
//         <span className={loginStyles.MailSuccessLinks}>
//           Click here to resend.
//         </span>
//       </button>
//     </>
//   );
// };
// export default MailSuccess;
import React from 'react';

import { executeWithLimit } from '../../utils/generic/rateLimitUtils';

import loginStyles from '../../styles/OnBoardingStyles/LoginPage.module.css';

import { supabase } from '@/lib/supabase/browser-client';
import { toast } from 'sonner';

interface MailSuccessProps {
  title: string;
  email: string;
  mailSuccessType: string;
  onChangeEmail: () => void;
  setEmail: (email: string) => void;
  resetPassword: (event: React.MouseEvent<HTMLButtonElement>) => Promise<void>;
}

const MailSuccess: React.FC<MailSuccessProps> = ({
  title,
  setEmail,
  onChangeEmail,
  email,
  mailSuccessType,
  resetPassword,
}) => {
  const handleResendConfirmation = async () => {
    const { data, error } = await supabase.auth.resend({
      type: 'signup',
      email: email,
    });

    if (data) {
      toast.success('Confirmation email resent successfully', {
        position: 'top-right',
        duration: 5000,
      });
    } else if (error) {
      toast.error(`Error resending confirmation email: ${error?.message}`, {
        position: 'top-right',
        duration: 5000,
      });
    }
  };

  const handleMailSuccess = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault(); // Prevent default button click behavior
    const key = mailSuccessType === 'reset' ? 'resetPassword' : 'resendEmail';
    executeWithLimit(
      {
        key: key,
        cooldownPeriod: 1800000, // 30 minutes
      },
      mailSuccessType === 'reset'
        ? () => resetPassword(e)
        : handleResendConfirmation,
    );
  };

  return (
    <>
      <div className={loginStyles.MailSuccessHeading}>{title}</div>
      <p className={loginStyles.MailSuccessText}>
        We have sent an email to{' '}
        <span className={loginStyles.MailSuccessLinks}>
          {email ? email : 'your email'}
        </span>{' '}
        with a verification link. The link will expire in 24 hours.
      </p>
      <br />
      <p className={loginStyles.MailSuccessText} onClick={onChangeEmail}>
        Entered the wrong email?{' '}
        <span className={loginStyles.MailSuccessLinks}>
          Click here to update.
        </span>
      </p>
      <br />
      <button
        onClick={handleMailSuccess}
        className={loginStyles.MailSuccessText}
      >
        Did not receive an email?{' '}
        <span className={loginStyles.MailSuccessLinks}>
          Click here to resend.
        </span>
      </button>
    </>
  );
};

export default MailSuccess;
