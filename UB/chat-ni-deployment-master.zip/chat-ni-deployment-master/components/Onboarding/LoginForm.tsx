'use client';

import React, { useEffect, useState } from 'react';

import Link from 'next/link';
import { redirect, useRouter } from 'next/navigation';

import { Brand } from '@/components/ui/brand';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import GoogleSignInButton from '@/components/utility/google-signin';

import loginStyles from '../../styles/OnBoardingStyles/LoginPage.module.css';
import LegalFooter from '../LegalFooter/LegalFooter';
import ResetForm from './ResetForm';
import SignupForm from './SignupForm';

import { supabase } from '@/lib/supabase/browser-client';
import { toast } from 'sonner';

// eslint-disable-next-line @next/next/no-async-client-component
export default function LoginForm() {
  const [isReset, setIsReset] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [isSignup, setIsSignup] = useState(
    localStorage.getItem('signup') === 'true' ? true : false,
  );
  const [generalError, setGeneralError] = useState('');
  const router = useRouter();
  useEffect(() => {
    async function fetchData() {
      const session = (await supabase.auth.getSession()).data.session;
      if (session) {
        // window.location.href = '/chat';
        router.push('/chat');
        // window.history.pushState({}, '', '/chat');
      }
    }
    fetchData();
  }, []);

  const handleEmailChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(event.target.value);
    if (emailError) setEmailError(''); // Reset email error if user starts typing
  };

  const handlePasswordChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(event.target.value);
    if (passwordError) setPasswordError(''); // Reset password error if user starts typing
  };

  const validateEmail = () => {
    if (!email) {
      setEmailError('Email is required.');
      return false;
    }
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setEmailError('Please enter a valid email address.');
      return false;
    }
    return true;
  };

  const validatePassword = () => {
    if (!password) {
      setPasswordError('Password is required.');
      return false;
    }
    // Example validation: Password length
    if (password.length < 8) {
      setPasswordError('Password must be at least 8 characters long.');
      return false;
    }
    // Add more password validations here as needed
    return true;
  };

  const validateForm = () => {
    // Reset all error states before validation
    setEmailError('');
    setPasswordError('');

    const isEmailValid = validateEmail();
    const isPasswordValid = validatePassword();

    return isEmailValid && isPasswordValid;
  };

  const signIn = async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    if (validateForm()) {
      //   'use server';

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        // toast.info(
        //   `${error?.message}`,

        //   {
        //     position: 'top-right',
        //     duration: 5000,
        //   },
        // );
        setGeneralError(`${error?.message}`);
        return;
        //   return redirect(`/login?message=${error.message}`);
      }
      window.location.href = '/chat';
      // window.history.pushState({}, '', '/chat');
      // Proceed with the sign-in logic
    } else {
      console.log('Form validation failed.');
    }
  };

  return (
    <div
      className={`flex w-full flex-1 flex-col items-center justify-center gap-2 px-8 sm:max-w-md ${isSignup ? loginStyles.conditionalMargin : ''}`}
    >
      <Brand />
      <div className={loginStyles.loginContent}>
        {!isReset && !isSignup ? (
          <>
            <div className={loginStyles.loginText}>Log in</div>
            <Input
              className="mb-3 rounded-md border bg-inherit px-4 py-2"
              name="email"
              placeholder="you@example.com"
              required
              value={email}
              onChange={handleEmailChange}
            />
            {emailError && (
              <div className={loginStyles.errorValidationStyle}>
                {emailError}
              </div>
            )}

            <Input
              className="mb-3 rounded-md border bg-inherit px-4 py-2"
              type="password"
              name="password"
              placeholder="Password"
              required
              value={password}
              onChange={handlePasswordChange}
            />
            {passwordError && (
              <div className={loginStyles.errorValidationStyle}>
                {passwordError}
              </div>
            )}
            {generalError && (
              <div className={loginStyles.errorValidationStyle}>
                {generalError}
              </div>
            )}

            <div
              className={`text-muted-foreground mt-1 flex justify-center text-sm ${loginStyles.forgotPasswordBox}`}
            >
              <button
                className={loginStyles.forgotPassword}
                onClick={() => {
                  setIsReset(true);
                }}
              >
                Forgot password
              </button>
            </div>
            <Button className={`${loginStyles.loginButton}`} onClick={signIn}>
              Log in
            </Button>

            <div style={{ width: '100%' }}>
              <GoogleSignInButton />
            </div>
            <Button
              className={loginStyles.outlinedButton}
              onClick={() => setIsSignup(true)}
            >
              <span className={loginStyles.outlinedButton11}>
                Create account
              </span>
            </Button>
          </>
        ) : isReset ? (
          <ResetForm setIsSignup={setIsSignup} setIsReset={setIsReset} />
        ) : (
          <SignupForm setIsSignup={setIsSignup} />
        )}
      </div>
      {/* <LegalFooter/> */}
    </div>
  );
}
