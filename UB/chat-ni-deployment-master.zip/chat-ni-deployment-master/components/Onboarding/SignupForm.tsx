'use client';

import React, { useEffect, useState } from 'react';

import Link from 'next/link';

import { Brand } from '@/components/ui/brand';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import GoogleSignInButton from '@/components/utility/google-signin';

import loginStyles from '../../styles/OnBoardingStyles/LoginPage.module.css';
import MailSuccess from './MailSuccess';

import { supabase } from '@/lib/supabase/browser-client';
import { toast } from 'sonner';

interface SignupFormProps {
  setIsSignup: (isSignup: boolean) => void;
}
const SignupForm: React.FC<SignupFormProps> = ({ setIsSignup }) => {
  const [isMarketing, setIsMarketing] = useState(true);
  const [loading, setLoading] = useState(false);
  const [mailSuccess, setMailSuccess] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [confirmPasswordError, setConfirmPasswordError] = useState('');
  useEffect(() => {
    async function fetchData() {
      const session = (await supabase.auth.getSession()).data.session;
      if (session) {
        // window.location.href = '/chat';
        // window.history.pushState({}, '', '/chat');
      }
    }
    fetchData();
  }, []);
  const handleEmailChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(event.target.value);
    if (emailError) setEmailError(''); // Reset email error if user starts typing
  };

  const handlePasswordChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(event.target.value);
    if (passwordError) setPasswordError(''); // Reset password error if user starts typing
  };

  const handleConfirmPasswordChange = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    setConfirmPassword(event.target.value);
    if (confirmPasswordError) setConfirmPasswordError(''); // Reset confirm password error if user starts typing
  };

  const validateEmail = () => {
    if (!email) {
      setEmailError('Email is required.');
      return false;
    }
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setEmailError('Please enter a valid email address.');
      return false;
    }
    return true;
  };

  const validatePassword = () => {
    if (!password) {
      setPasswordError('Password is required.');
      return false;
    }
    // Example validation: Password length
    if (password.length < 8) {
      setPasswordError('Password must be at least 8 characters long.');
      return false;
    }
    // Add more password validations here as needed
    return true;
  };

  const validateConfirmPassword = () => {
    if (password !== confirmPassword) {
      setConfirmPasswordError('Passwords do not match.');
      return false;
    }
    return true;
  };

  const validateForm = () => {
    // Reset all error states before validation
    setEmailError('');
    setPasswordError('');
    setConfirmPasswordError('');

    const isEmailValid = validateEmail();
    const isPasswordValid = validatePassword();
    const isConfirmPasswordValid = validateConfirmPassword();

    return isEmailValid && isPasswordValid && isConfirmPasswordValid;
  };

  const signUp = async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    if (validateForm()) {
      setLoading(true);
      if (process.env.EMAIL_DOMAIN_WHITELIST) {
        const emailDomainWhitelist =
          process.env.EMAIL_DOMAIN_WHITELIST?.split(',') ?? [];
        if (
          emailDomainWhitelist.length > 0 &&
          !emailDomainWhitelist.includes(email.split('@')[1])
        ) {
          setEmailError(`Email ${email} is not allowed to sign up.`);
        }
      }

      if (process.env.EMAIL_WHITELIST) {
        const emailWhitelist = process.env.EMAIL_WHITELIST?.split(',') ?? [];
        if (emailWhitelist.length > 0 && !emailWhitelist.includes(email)) {
          setEmailError(`Email ${email} is not allowed to sign up.`);
        }
      }
      const { error, data } = await supabase.auth.signUp({
        email,
        password,
        options: {},
      });
      const session = data;
      const user = session?.user;
      if (user) {
        const { data, error } = await supabase
          .from('user_details')
          .insert([{ user_id: user.id, is_marketing: isMarketing }])
          .select();
        if (error) {
          console.error('Error inserting user details:', error);
        } else {
          console.log('User details inserted:', data);
        }
      }
      if (error) {
        if (error.status === 429) {
          // alert(JSON.stringify(error.message))
          setEmailError(
            `Your account is already created; kindly verify via the sent email verification link`,
          );
          toast.info(
            `Your account is already created; kindly verify via the sent email verification link`,

            {
              position: 'top-right',
              duration: 5000,
            },
          );
          // window.location.href = '/login';
          // setEmail("")
          // setPassword("")
          // setConfirmPassword("")
          setLoading(false);
          return;
        }
        // console.error(error);
        // alert("Error: "+JSON.stringify(error))
        // setEmailError(`${error.message}`)
      }
      setLoading(false);
      setMailSuccess(true);
      // console.log("data: "+JSON.stringify(data))
      // alert("Data: "+JSON.stringify(data))
      // localStorage.setItem('signup', 'false')
      // window.location.href = '/login';
    } else {
      console.log('Form validation failed.');
    }
  };
  <style jsx global>{`
    .custom-checkbox {
      appearance: none;
      -webkit-appearance: none;
      -moz-appearance: none;
      outline: none;
      cursor: pointer;
      background-color: transparent;
      border: 2px solid #ccc;
      border-radius: 4px;
      width: 16px;
      height: 16px;
    }

    .custom-checkbox:checked {
      background-color: pink !important;
      border-color: pink;
    }
  `}</style>;

  const handleChangeEmail = () => {
    setMailSuccess(false); // Hide mail success message
    setLoading(false); // Ensure loading state is reset
  };

  return (
    <>
      {!loading && !mailSuccess ? (
        <>
          <div className={loginStyles.loginText}>Sign Up</div>
          <Input
            className="mb-3 rounded-md border bg-inherit px-4 py-2"
            name="email"
            placeholder="you@example.com"
            required
            value={email}
            onChange={handleEmailChange}
          />
          {emailError && (
            <div className={loginStyles.errorValidationStyle}>{emailError}</div>
          )}

          <Input
            className="mb-3 rounded-md border bg-inherit px-4 py-2"
            type="password"
            name="password"
            placeholder="Password"
            required
            value={password}
            onChange={handlePasswordChange}
          />
          {passwordError && (
            <div className={loginStyles.errorValidationStyle}>
              {passwordError}
            </div>
          )}

          <Input
            className="mb-6 rounded-md border bg-inherit px-4 py-2"
            type="password"
            name="confirmPassword"
            placeholder="Confirm Password"
            required
            value={confirmPassword}
            onChange={handleConfirmPasswordChange}
          />
          {confirmPasswordError && (
            <div className={loginStyles.errorValidationStyle}>
              {confirmPasswordError}
            </div>
          )}
          <div className={loginStyles.checkboxContent}>
            <div className={loginStyles.signupCheckbox}>
              <input
                type="checkbox"
                checked={isMarketing}
                className={`${loginStyles.signupCheckboxInput} custom-checkbox`}
                onChange={(e) => setIsMarketing(e.target.checked)}
              />
            </div>
            <p className={loginStyles.sendMeTheMarketingEmailChatni}>
              <span className={loginStyles.sendMeTheMarketingEmailSub4}>
                Send me the marketing emails from ChatNI.
              </span>
            </p>
          </div>
          <Button className={`${loginStyles.loginButton}`} onClick={signUp}>
            Proceed to verify
          </Button>

          <div style={{ width: '100%' }}>
            <GoogleSignInButton />
          </div>
          <Button
            className={loginStyles.outlinedButton}
            onClick={() => {
              setIsSignup(false);
              localStorage.setItem('signup', 'false');
            }}
          >
            <span className={loginStyles.outlinedButton11}>
              Already have an account
            </span>
          </Button>
          {/* For easy access to edit the success screen */}
          {/* <Button onClick={() => {
            setLoading(false);
            setMailSuccess(true);
          }}>go to success screen</Button> */}
          <div className={loginStyles.privacyPolicyContent}>
            <span>
              By creating an account you agree to our{' '}
              <Link href={'#'} style={{ textDecoration: 'underline' }}>
                Terms and Conditions
              </Link>{' '}
              and{' '}
              <Link href="#" style={{ textDecoration: 'underline' }}>
                our Privacy Policy
              </Link>
            </span>
          </div>
        </>
      ) : !mailSuccess ? (
        <>
          {/* <div className="size-12 animate-spin rounded-full border-y-2 border-gray-900"></div> */}
          <div
            className="inline-block size-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"
            role="status"
          >
            <span className="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">
              Loading...
            </span>
          </div>
        </>
      ) : (
        <MailSuccess
          mailSuccessType="signup"
          title="Activation Email Sent"
          //description={`We've sent an activation email to ${email} with a verification link. The link will expire in 24 hours.`}
          email={email}
          setEmail={setEmail}
          resetPassword={signUp}
          onChangeEmail={handleChangeEmail}
        />
      )}
    </>
  );
};

export default SignupForm;
