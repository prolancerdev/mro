'use client';

import React, { useState } from 'react';

import { tree } from 'next/dist/build/templates/app-page';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import GoogleSignInButton from '@/components/utility/google-signin';

import loginStyles from '../../styles/OnBoardingStyles/LoginPage.module.css';
import MailSuccess from './MailSuccess';

import { supabase } from '@/lib/supabase/browser-client';
import { toast } from 'sonner';

interface ResetFormProps {
  setIsSignup: (isSignup: boolean) => void;
  setIsReset: (isSignup: boolean) => void;
}
const ResetForm: React.FC<ResetFormProps> = ({ setIsSignup, setIsReset }) => {
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [loading, setLoading] = useState(false);
  const [mailSuccess, setMailSuccess] = useState(false);

  const handleEmailChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(event.target.value);
    if (emailError) setEmailError(''); // Reset email error if user starts typing
  };

  const validateEmail = () => {
    if (!email) {
      setEmailError('Email is required.');
      return false;
    }
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setEmailError('Please enter a valid email address.');
      return false;
    }
    return true;
  };

  const validateForm = () => {
    setEmailError('');
    const isEmailValid = validateEmail();

    return isEmailValid;
  };

  const reset = async (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    if (validateForm()) {
      setLoading(true);
      const { error, data } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${origin}/login/password`,
      });
      if (error) {
        setLoading(false);
        setMailSuccess(false);
        if (error.status === 429)
          setEmailError(
            "You've reached your email limit for now. Please try again in 10 minutes.",
          );
        else setEmailError(error.message + ' please try after 10min');
        return;
      }

      setMailSuccess(true);
      setLoading(false);
      toast.success(`Confirmation email sent successfully`, {
        position: 'top-right',
        duration: 5000,
      });
    } else {
      console.log('Form validation failed.');
    }
  };

  const handleChangeEmail = () => {
    setMailSuccess(false);
    setLoading(false);
  };

  const handleResendEmail = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/login/password`,
      });
      if (error) {
        setEmailError(error.message);
      } else {
        setMailSuccess(true);
      }
    } catch (error) {
      console.error('Failed to resend verification email:', error);
      setEmailError('Failed to resend email. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {!loading && !mailSuccess ? (
        <>
          <div className={loginStyles.loginText}>Forgot Password</div>
          <Input
            className="mb-3 rounded-md border bg-inherit px-4 py-2"
            name="email"
            placeholder="you@example.com"
            required
            value={email}
            onChange={handleEmailChange}
          />
          {emailError && (
            <div className={loginStyles.errorValidationStyle}>{emailError}</div>
          )}
          <Button className={`${loginStyles.loginButton}`} onClick={reset}>
            Submit
          </Button>
          <Button
            className={loginStyles.outlinedButton}
            onClick={() => {
              setIsReset(false);
              setIsSignup(true);
            }}
          >
            <span className={loginStyles.outlinedButton11}>Create Account</span>
          </Button>
          {/* For easy access to edit the success screen */}
          {/* <Button onClick={() => {
            setLoading(false);
            setMailSuccess(true);
          }}>go to success screen</Button> */}
        </>
      ) : !mailSuccess ? (
        <>
          {/* <div className="size-12 animate-spin rounded-full border-y-2 border-gray-900"></div> */}
          <div
            className="inline-block size-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"
            role="status"
          >
            <span className="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">
              Loading...
            </span>
          </div>
        </>
      ) : (
        <MailSuccess
          title="Check Your Inbox"
          mailSuccessType="reset"
          //description={`We've sent an email to ${email} with a verification link. The link will expire in 24 hours.`}
          email={email}
          setEmail={setEmail}
          resetPassword={reset}
          onChangeEmail={handleChangeEmail}
        />
      )}
    </>
  );
};

export default ResetForm;
