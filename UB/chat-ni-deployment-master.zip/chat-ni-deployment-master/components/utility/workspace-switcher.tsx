'use client';

import { IconHome, IconPlus } from '@tabler/icons-react';
import { ChevronDown } from 'lucide-react';
import { FC, MouseEvent, useContext, useEffect, useState } from 'react';

import useHotkey from '@/lib/hooks/use-hotkey';

import { useChatHandler } from '@/components/Chat/chat-hooks/UseChatHandler';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';

import style from '../../styles/componentStyles/dropdownStyle.module.css';
import styles from '../../styles/componentStyles/secondary.module.css';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { WorkspaceSettings } from '../workspace/workspace-settings';

import { ChatbotUIContext } from '@/context/context';
import { createWorkspace } from '@/db/workspaces';

interface WorkspaceSwitcherProps {}

export const WorkspaceSwitcher: FC<WorkspaceSwitcherProps> = ({}) => {
  useHotkey(';', () => setOpen((prevState) => !prevState));

  const { workspaces, selectedWorkspace, setSelectedWorkspace, setWorkspaces } =
    useContext(ChatbotUIContext);
  const { handleNewChat } = useChatHandler();

  const [open, setOpen] = useState(false);
  const [value, setValue] = useState('');
  const [search, setSearch] = useState('');

  const handleCreateWorkspace = async () => {
    if (!selectedWorkspace) return;

    const createdWorkspace = await createWorkspace({
      user_id: selectedWorkspace.user_id,
      default_context_length: selectedWorkspace.default_context_length,
      default_model: selectedWorkspace.default_model,
      default_prompt: selectedWorkspace.default_prompt,
      default_temperature: selectedWorkspace.default_temperature,
      description: '',
      embeddings_provider: 'openai',
      include_profile_context: selectedWorkspace.include_profile_context,
      include_workspace_instructions:
        selectedWorkspace.include_workspace_instructions,
      instructions: selectedWorkspace.instructions,
      is_home: false,
      name: 'Workspace' + ' ' + (workspaces.length + 1),
    });

    setWorkspaces([...workspaces, createdWorkspace]);
    setSelectedWorkspace(createdWorkspace);
    localStorage.setItem('showSidebar', String('true'));
    setOpen(false);

    handleNewChat();
  };

  const getWorkspaceName = (workspaceId: string) => {
    const workspace = workspaces.find(
      (workspace) => workspace.id === workspaceId,
    );

    if (!workspace) return;

    return `${workspace.name.substring(0, 15)}${workspace.name.length > 15 ? '...' : ''}`;
  };

  const handleSelect = (
    workspaceId: string,
    e: React.MouseEvent<HTMLButtonElement>,
  ) => {
    e.preventDefault();
    const workspace = workspaces.find(
      (workspace) => workspace.id === workspaceId,
    );

    if (!workspace) return;

    setSelectedWorkspace({ ...workspace });
    localStorage.setItem('workspaceSelectedId', String(workspaceId));
    localStorage.setItem('showSidebar', String('true'));
    setOpen(false);
  };

  useEffect(() => {
    if (!selectedWorkspace) return;

    setValue(selectedWorkspace.id);
  }, [selectedWorkspace]);

  const getButtonStyle = (
    workspace: { id: string; is_home: any },
    isLastItem: boolean,
  ) => {
    const workspaceSelectedId =
      localStorage.getItem('workspaceSelectedId') || 'null';

    if (workspace.id === selectedWorkspace?.id && isLastItem) {
      return {
        borderLeft: '5px solid #7A94F1',
        fontFamily: 'Inter, sans-serif',
        fontWeight: 700,
        fontSize: '16px',
        lineHeight: '35px',
        margin: '0px 0px -5px -10px',
        paddingLeft: '6px',
        borderRadius: '0px 0px 0px 7px',
      };
    } else if (workspace.id === selectedWorkspace?.id) {
      return {
        borderLeft: '5px solid #7A94F1',
        borderRadius: '0.1px',
        fontFamily: 'Inter, sans-serif',
        fontWeight: 700,
        fontSize: '16px',
        lineHeight: '35px',
        margin: '0px 0px 0px -10px',
        paddingLeft: '6px',
      };
    }
    // else if (workspace.is_home && workspaceSelectedId === 'null') {
    //   return {
    //     backgroundColor: '#323243',
    //     borderLeft: '2px solid #7A94F1',
    //     fontWeight: 'normal',
    //   };
    // }
    return {
      border: 'none',
      fontFamily: 'Inter, sans-serif',
      fontWeight: 400,
      fontSize: '16px',
      lineHeight: '35px',
      margin: '0px 0px',
    }; // Default style
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger
        className={`border-input flex h-[36px] w-full cursor-pointer items-center justify-between  
        ${open ? `rounded-t-md ${styles.openState}` : `rounded-md ${styles.dropdownStyles}`}`}
      >
        <div
          style={{ padding: '3px' }}
          className={`flex w-full items-center justify-between ${styles.workspaceDropdownContainer}`}
        >
          <div className={`grow ${styles.workspaceDropdownText}`}>
            {getWorkspaceName(value) || 'Select workspace...'}
            {/* {`${getWorkspaceName(value).substring(0, 10)} ${getWorkspaceName(value).length > 10 ? '...' : ''}` || 'Select workspace...'} */}
          </div>
          {/* <div
            className={`${style.editButton}`}
            onClick={(e) => {
              e.stopPropagation();
            }}
          >
            <WorkspaceSettings />
          </div> */}
          <ChevronDown
            className={`ml-2 size-5 shrink-0 opacity-100 
            ${open ? 'rotate-180' : 'rotate-0'} 
            ${style.dropdownArrow}`}
          />
          {/* <div className={`flex-initial ${styles.workspaceDropdownIcon}`}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 16 16"
              fill="none"
            >
              <mask
                id="mask0_494_60"
                style={{ maskType: 'alpha' }}
                maskUnits="userSpaceOnUse"
                x="0"
                y="0"
                width="16"
                height="16"
              >
                <rect
                  x="16"
                  width="16"
                  height="16"
                  transform="rotate(90 16 0)"
                  fill="#D9D9D9"
                />
              </mask>
              <g mask="url(#mask0_494_60)">
                <path
                  d="M1.92499 5.94166C1.59822 5.61489 1.59822 5.0851 1.92499 4.75833C2.25176 4.43156 2.78156 4.43156 3.10832 4.75833L7.99999 9.65L12.8917 4.75833C13.2184 4.43156 13.7482 4.43156 14.075 4.75833C14.4018 5.0851 14.4018 5.6149 14.075 5.94166L8.91923 11.0974C8.41155 11.6051 7.58843 11.6051 7.08075 11.0974L1.92499 5.94166Z"
                  fill="#F5FAFF"
                />
              </g>
            </svg>
          </div> */}
        </div>

        {/* <div
          className="flex items-center truncate"
          style={{ marginRight: '3rem' }}
        >
          {' '}
          {getWorkspaceName(value) || 'Select workspace...'}
        </div>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="16"
          height="16"
          viewBox="0 0 16 16"
          fill="none"
        >
          <mask
            id="mask0_272_423"
            style={{ maskType: 'alpha' }}
            maskUnits="userSpaceOnUse"
            x="0"
            y="0"
            width="16"
            height="16"
          >
            <rect
              x="16"
              width="16"
              height="16"
              transform="rotate(90 16 0)"
              fill="#D9D9D9"
            />
          </mask>
          <g mask="url(#mask0_272_423)">
            <path
              d="M1.92499 5.94166C1.59822 5.61489 1.59822 5.0851 1.92499 4.75833C2.25176 4.43156 2.78156 4.43156 3.10832 4.75833L7.99999 9.65L12.8917 4.75833C13.2184 4.43156 13.7482 4.43156 14.075 4.75833C14.4018 5.0851 14.4018 5.6149 14.075 5.94166L8.91923 11.0974C8.41155 11.6051 7.58843 11.6051 7.08075 11.0974L1.92499 5.94166Z"
              fill="#F5FAFF"
            />
          </g>
        </svg> */}
      </PopoverTrigger>

      <PopoverContent className={style.popoverClass}>
        <div className="space-y-2">
          <div style={{ padding: '0.5rem' }}>
            <div style={{ marginBottom: '0.5rem' }}>
              <Button
                styleName={'primaryButton'}
                className="flex w-full items-center space-x-2"
                size="sm"
                onClick={handleCreateWorkspace}
              >
                <IconPlus />
                <div className="ml-2">Workspace</div>
              </Button>
            </div>

            {/* <Input
              styleName={'searchInputStyle'}
              placeholder="Search workspaces..."
              autoFocus
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            /> */}
          </div>
          <div
            className="flex flex-col space-y-1"
            style={{ overflowY: 'hidden' }}
          >
            {workspaces
              // .filter(
              //   (workspace) =>
              //     !workspace.is_home &&
              //     workspace.name.toLowerCase().includes(search.toLowerCase()),
              // )
              .sort((a, b) => a.name.localeCompare(b.name))
              .map((workspace, index, array) => (
                <Button
                  style={{ padding: '0px 10px' }}
                  key={workspace.id}
                  className={`flex justify-start ${styles.workspaceButtonHover}`}
                  onClick={(e) => handleSelect(workspace.id, e)}
                >
                  {/* <div className="text-lg">{workspace.name.substring(0,15)}</div> */}
                  <div
                    className="text-sm"
                    style={getButtonStyle(
                      workspace,
                      index === array.length - 1,
                    )}
                  >{`${workspace.name.substring(0, 20)}${workspace.name.length > 20 ? '...' : ''}`}</div>
                </Button>
              ))}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
};
