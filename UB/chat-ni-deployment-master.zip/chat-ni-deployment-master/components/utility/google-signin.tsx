'use client';

import React from 'react';

import { redirect } from 'next/navigation';
import { useRouter } from 'next/navigation';
import { type NextRequest, NextResponse } from 'next/server';

import loginStyles from '../../styles/OnBoardingStyles/LoginPage.module.css';

import { supabase } from '@/lib/supabase/browser-client';
import { createClient } from '@supabase/supabase-js';

function GoogleSignInButton() {
  const router = useRouter();
  // Function to handle Google Sign-In
  const handleGoogleLogin = async () => {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
    });

    if (error) {
      //   alert("Error: "+JSON.stringify(error))
      return redirect(`/login?message=${error.message}`);
    }
    //    alert("Data: "+JSON.stringify(data))
    router.push('/chat');
    // return redirect('/chat');
    // window.history.pushState({}, '', '/chat');
  };

  return (
    // <div className="flex justify-center gap-2 px-8 sm:max-w-md">
    //   {/* Button to trigger Google Sign-In */}
    //   <button onClick={handleGoogleLogin} className={`${styles.googleButton}`}>
    //     <span style={{ display: 'flex', alignItems: 'center' }}>
    //       <svg className={styles.googleButtonSvg} />
    //       Continue with Google
    //     </span>
    //   </button>
    // </div>
    <>
      <button
        className={loginStyles.socialAutomaticLoginFunction}
        onClick={handleGoogleLogin}
      >
        {/* <img className="google-logo-color" /> */}
        <svg
          className={`${loginStyles.googleButtonSvg} ${loginStyles.googleLogoColor}`}
        />
        <div className={loginStyles.continueWithGoogle}>
          Continue with Google
        </div>
      </button>
    </>
  );
}

export default GoogleSignInButton;
