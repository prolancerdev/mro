import {
  IconCircleCheckFilled,
  IconCircleXFilled,
  IconFileDownload,
  IconLoader2,
  IconLogout,
  IconUser,
} from '@tabler/icons-react';
import {
  FC,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import style from 'react-syntax-highlighter/dist/esm/styles/hljs/a11y-dark';

import { useRouter } from 'next/navigation';

import { VALID_KEYS } from '@/types/valid-keys';

import { SIDEBAR_ICON_SIZE } from '@/components/Sidebar/SidebarSwitcher';

import loginStyles from '../../styles/OnBoardingStyles/LoginPage.module.css';
import styles from '../../styles/componentStyles/secondary.module.css';
import ImagePicker from '../ui/ImagePicker';
import { LimitDisplay } from '../ui/LimitDisplay';
import { TextareaAutosize } from '../ui/TextareaAutosize';
import { WithTooltip } from '../ui/WithTooltip';
import { Avatar, AvatarImage } from '../ui/avatar';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '../ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { ThemeSwitcher } from './theme-switcher';

import { ChatbotUIContext } from '@/context/context';
import {
  PROFILE_CONTEXT_MAX,
  PROFILE_DISPLAY_NAME_MAX,
  PROFILE_USERNAME_MAX,
  PROFILE_USERNAME_MIN,
} from '@/db/limits';
import { updateProfile } from '@/db/profile';
import { uploadImage } from '@/db/storage/profile-images';
import { exportLocalStorageAsJSON } from '@/lib/export-old-data';
import { supabase } from '@/lib/supabase/browser-client';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface ProfileSettingsProps {}

export const ProfileSettings: FC<ProfileSettingsProps> = ({}) => {
  const { profile, setProfile } = useContext(ChatbotUIContext);
  const [isMarketing, setIsMarketing] = useState(false);
  const router = useRouter();

  const buttonRef = useRef<HTMLButtonElement>(null);

  const [isOpen, setIsOpen] = useState(false);

  const [displayName, setDisplayName] = useState(profile?.display_name || '');
  const [username, setUsername] = useState(profile?.username || '');
  const [usernameAvailable, setUsernameAvailable] = useState(true);
  const [loadingUsername, setLoadingUsername] = useState(false);
  const [profileImageSrc, setProfileImageSrc] = useState(
    profile?.image_url || '',
  );
  const [profileImageFile, setProfileImageFile] = useState<File | null>(null);
  const [profileInstructions, setProfileInstructions] = useState(
    profile?.profile_context || '',
  );

  const [useAzureOpenai, setUseAzureOpenai] = useState(
    profile?.use_azure_openai,
  );
  const [openaiAPIKey, setOpenaiAPIKey] = useState(
    profile?.openai_api_key || '',
  );
  const [openaiOrgID, setOpenaiOrgID] = useState(
    profile?.openai_organization_id || '',
  );
  const [azureOpenaiAPIKey, setAzureOpenaiAPIKey] = useState(
    profile?.azure_openai_api_key || '',
  );
  const [azureOpenaiEndpoint, setAzureOpenaiEndpoint] = useState(
    profile?.azure_openai_endpoint || '',
  );
  const [azureOpenai35TurboID, setAzureOpenai35TurboID] = useState(
    profile?.azure_openai_35_turbo_id || '',
  );
  const [azureOpenai45TurboID, setAzureOpenai45TurboID] = useState(
    profile?.azure_openai_45_turbo_id || '',
  );
  const [azureOpenai45VisionID, setAzureOpenai45VisionID] = useState(
    profile?.azure_openai_45_vision_id || '',
  );
  const [azureEmbeddingsID, setAzureEmbeddingsID] = useState(
    //@ts-ignore
    profile?.azure_openai_embeddings_id || '',
  );
  const [anthropicAPIKey, setAnthropicAPIKey] = useState(
    profile?.anthropic_api_key || '',
  );
  const [googleGeminiAPIKey, setGoogleGeminiAPIKey] = useState(
    profile?.google_gemini_api_key || '',
  );
  const [mistralAPIKey, setMistralAPIKey] = useState(
    profile?.mistral_api_key || '',
  );
  const [perplexityAPIKey, setPerplexityAPIKey] = useState(
    profile?.perplexity_api_key || '',
  );

  const [openrouterAPIKey, setOpenrouterAPIKey] = useState(
    //@ts-ignore
    profile?.openrouter_api_key || '',
  );

  const [isEnvOpenai, setIsEnvOpenai] = useState(false);
  const [isEnvAnthropic, setIsEnvAnthropic] = useState(false);
  const [isEnvGoogleGemini, setIsEnvGoogleGemini] = useState(false);
  const [isEnvMistral, setIsEnvMistral] = useState(false);
  const [isEnvPerplexity, setIsEnvPerplexity] = useState(false);
  const [isEnvAzureOpenai, setIsEnvAzureOpenai] = useState(false);
  const [isEnvOpenrouter, setIsEnvOpenrouter] = useState(false);
  useEffect(() => {
    const fetchIsMarketingStatus = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser();
        if (user) {
          const { data, error } = await supabase
            .from('user_details')
            .select('is_marketing')
            .eq('user_id', user.id)
            .single();
          if (
            data &&
            data.is_marketing !== null &&
            data.is_marketing !== undefined
          ) {
            setIsMarketing(data.is_marketing);
          } else {
            const { error: insertError } = await supabase
              .from('user_details')
              .insert({ user_id: user.id, is_marketing: isMarketing });

            if (insertError) {
              console.error('Error inserting isMarketing status:', insertError);
            } else {
              console.log('isMarketing status inserted successfully');
            }
          }
        } else {
          console.error('User not authenticated');
        }
      } catch (error) {
        console.error('Error fetching isMarketing status:', error);
      }
    };

    fetchIsMarketingStatus();
  }, []);

  useEffect(() => {
    async function fetchKeys() {
      const keys = Object.values(VALID_KEYS);

      keys.forEach(async (key) => {
        const response = await fetch('/api/retrieval/keys', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ key }),
        });

        if (response.ok) {
          const { isUsing } = (await response.json()) as {
            isUsing: boolean;
          };

          switch (key) {
            case 'OPENAI_API_KEY':
              setIsEnvOpenai(isUsing);
              break;
            case 'ANTHROPIC_API_KEY':
              setIsEnvAnthropic(isUsing);
              break;
            case 'GOOGLE_GEMINI_API_KEY':
              setIsEnvGoogleGemini(isUsing);
              break;
            case 'MISTRAL_API_KEY':
              setIsEnvMistral(isUsing);
              break;
            case 'PERPLEXITY_API_KEY':
              setIsEnvPerplexity(isUsing);
              break;
            case 'AZURE_OPENAI_API_KEY':
              setIsEnvAzureOpenai(isUsing);
              break;
            case 'OPENROUTER_API_KEY':
              setIsEnvOpenrouter(isUsing);
              break;
            default:
              console.warn('Unhandled key type:', key);
              break;
          }
        } else {
          console.error('Failed to fetch key status:', key);
        }
      });
    }

    fetchKeys();
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    router.push('/login');
    router.refresh();
    return;
  };

  const handleSave = async () => {
    if (!profile) return;
    let profileImageUrl = profile.image_url;
    let profileImagePath = '';
    // Email Marketing
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (user) {
        const { error } = await supabase
          .from('user_details')
          .update({ is_marketing: isMarketing })
          .eq('user_id', user.id);
        if (error) {
          console.log('Error updating isMarketing status:' + error);
        } else {
          setIsMarketing(isMarketing);
        }
      } else {
        console.error('User not authenticated');
      }
    } catch (error) {
      console.error('Error updating isMarketing status:', error);
    }
    // Email marketing End
    if (profileImageFile) {
      const { path, url } = await uploadImage(profile, profileImageFile);
      profileImageUrl = url ?? profileImageUrl;
      profileImagePath = path;
    }

    const updatedProfile = await updateProfile(profile.id, {
      ...profile,
      display_name: displayName,
      username,
      profile_context: profileInstructions,
      image_url: profileImageUrl,
      image_path: profileImagePath,
      openai_api_key: openaiAPIKey,
      openai_organization_id: openaiOrgID,
      anthropic_api_key: anthropicAPIKey,
      google_gemini_api_key: googleGeminiAPIKey,
      mistral_api_key: mistralAPIKey,
      perplexity_api_key: perplexityAPIKey,
      use_azure_openai: useAzureOpenai,
      azure_openai_api_key: azureOpenaiAPIKey,
      azure_openai_endpoint: azureOpenaiEndpoint,
      azure_openai_35_turbo_id: azureOpenai35TurboID,
      azure_openai_45_turbo_id: azureOpenai45TurboID,
      azure_openai_45_vision_id: azureOpenai45VisionID, //@ts-ignore
      azure_openai_embeddings_id: azureEmbeddingsID,
      openrouter_api_key: openrouterAPIKey,
    });
    setProfile(updatedProfile);

    toast.success('Profile updated!');

    setIsOpen(false);
  };

  const debounce = (func: (...args: any[]) => void, wait: number) => {
    let timeout: NodeJS.Timeout | null;

    return (...args: any[]) => {
      const later = () => {
        if (timeout) clearTimeout(timeout);
        func(...args);
      };

      if (timeout) clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  };

  const checkUsernameAvailability = useCallback(
    debounce(async (username: string) => {
      if (!username) return;

      if (username.length < PROFILE_USERNAME_MIN) {
        setUsernameAvailable(false);
        return;
      }

      if (username.length > PROFILE_USERNAME_MAX) {
        setUsernameAvailable(false);
        return;
      }

      const usernameRegex = /^[a-zA-Z0-9_]+$/;
      if (!usernameRegex.test(username)) {
        setUsernameAvailable(false);
        alert(
          'Username must be letters, numbers, or underscores only - no other characters or spacing allowed.',
        );
        return;
      }

      setLoadingUsername(true);

      const response = await fetch(`/api/username/available`, {
        method: 'POST',
        body: JSON.stringify({ username }),
      });

      const data = await response.json();
      const isAvailable = data.isAvailable;

      setUsernameAvailable(isAvailable);

      if (username === profile?.username) {
        setUsernameAvailable(true);
      }

      setLoadingUsername(false);
    }, 500),
    [],
  );

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter') {
      buttonRef.current?.click();
    }
  };

  if (!profile) return null;

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        {profile.image_url ? (
          <Avatar className="mt-2 size-[34px] cursor-pointer hover:opacity-50">
            <AvatarImage src={profile.image_url} />
          </Avatar>
        ) : (
          <Button size="icon" variant="ghost" style={{ border: 'none' }}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
            >
              <mask
                id="mask0_379_365"
                style={{ maskType: 'alpha' }}
                maskUnits="userSpaceOnUse"
                x="0"
                y="0"
                width="24"
                height="24"
              >
                <rect width="24" height="24" fill="#D9D9D9" />
              </mask>
              <g mask="url(#mask0_379_365)">
                <path
                  d="M5.85 17.1C6.7 16.45 7.65 15.9375 8.7 15.5625C9.75 15.1875 10.85 15 12 15C13.15 15 14.25 15.1875 15.3 15.5625C16.35 15.9375 17.3 16.45 18.15 17.1C18.7333 16.4167 19.1875 15.6417 19.5125 14.775C19.8375 13.9083 20 12.9833 20 12C20 9.78333 19.2208 7.89583 17.6625 6.3375C16.1042 4.77917 14.2167 4 12 4C9.78333 4 7.89583 4.77917 6.3375 6.3375C4.77917 7.89583 4 9.78333 4 12C4 12.9833 4.1625 13.9083 4.4875 14.775C4.8125 15.6417 5.26667 16.4167 5.85 17.1ZM12 13C11.0167 13 10.1875 12.6625 9.5125 11.9875C8.8375 11.3125 8.5 10.4833 8.5 9.5C8.5 8.51667 8.8375 7.6875 9.5125 7.0125C10.1875 6.3375 11.0167 6 12 6C12.9833 6 13.8125 6.3375 14.4875 7.0125C15.1625 7.6875 15.5 8.51667 15.5 9.5C15.5 10.4833 15.1625 11.3125 14.4875 11.9875C13.8125 12.6625 12.9833 13 12 13ZM12 22C10.6167 22 9.31667 21.7375 8.1 21.2125C6.88333 20.6875 5.825 19.975 4.925 19.075C4.025 18.175 3.3125 17.1167 2.7875 15.9C2.2625 14.6833 2 13.3833 2 12C2 10.6167 2.2625 9.31667 2.7875 8.1C3.3125 6.88333 4.025 5.825 4.925 4.925C5.825 4.025 6.88333 3.3125 8.1 2.7875C9.31667 2.2625 10.6167 2 12 2C13.3833 2 14.6833 2.2625 15.9 2.7875C17.1167 3.3125 18.175 4.025 19.075 4.925C19.975 5.825 20.6875 6.88333 21.2125 8.1C21.7375 9.31667 22 10.6167 22 12C22 13.3833 21.7375 14.6833 21.2125 15.9C20.6875 17.1167 19.975 18.175 19.075 19.075C18.175 19.975 17.1167 20.6875 15.9 21.2125C14.6833 21.7375 13.3833 22 12 22ZM12 20C12.8833 20 13.7167 19.8708 14.5 19.6125C15.2833 19.3542 16 18.9833 16.65 18.5C16 18.0167 15.2833 17.6458 14.5 17.3875C13.7167 17.1292 12.8833 17 12 17C11.1167 17 10.2833 17.1292 9.5 17.3875C8.71667 17.6458 8 18.0167 7.35 18.5C8 18.9833 8.71667 19.3542 9.5 19.6125C10.2833 19.8708 11.1167 20 12 20ZM12 11C12.4333 11 12.7917 10.8583 13.075 10.575C13.3583 10.2917 13.5 9.93333 13.5 9.5C13.5 9.06667 13.3583 8.70833 13.075 8.425C12.7917 8.14167 12.4333 8 12 8C11.5667 8 11.2083 8.14167 10.925 8.425C10.6417 8.70833 10.5 9.06667 10.5 9.5C10.5 9.93333 10.6417 10.2917 10.925 10.575C11.2083 10.8583 11.5667 11 12 11Z"
                  fill="#F5FAFF"
                />
              </g>
            </svg>
          </Button>
        )}
      </SheetTrigger>

      <SheetContent
        className={`flex flex-col justify-between ${styles.leftModal}`}
        side="left"
        onKeyDown={handleKeyDown}
      >
        <SheetHeader>
          <SheetTitle className="flex items-center justify-between space-x-2">
            <div>User Profile</div>

            <Button
              tabIndex={-1}
              className={`text-xs ${styles.logoutButton}`}
              size="sm"
              onClick={handleSignOut}
            >
              <IconLogout className="mr-1" size={20} />
              Logout
            </Button>
          </SheetTitle>
        </SheetHeader>
        <div className={`grow ${styles.leftModalScrollhandler}`}>
          <Tabs defaultValue="profile" className={styles.innerLeftModal}>
            {/* <TabsList className="mt-4 grid w-full grid-cols-2">
              <TabsTrigger
                value="profile"
                style={{ backgroundColor: '#54545D', marginRight: '1rem' }}
              >
                Profile
              </TabsTrigger>
               <TabsTrigger
                value="keys"
                style={{ backgroundColor: '#54545D', margin: '0rem' }}
              >
                API Keys
              </TabsTrigger> 
            </TabsList> */}

            <TabsContent className={`mt-4 space-y-4`} value="profile">
              {/* <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <Label>Username</Label>

                  <div className="text-xs">
                    {username !== profile.username ? (
                      usernameAvailable ? (
                        <div className="text-green-500">AVAILABLE</div>
                      ) : (
                        <div className="text-red-500">UNAVAILABLE</div>
                      )
                    ) : null}
                  </div>
                </div>

                <div className="relative">
                  <Input
                    styleName={'modalInputStyle'}
                    // style={{ backgroundColor: '#2A2A32', borderRadius: '0px' }}
                    className={`pr-10`}
                    placeholder="Username..."
                    value={username}
                    onChange={(e) => {
                      setUsername(e.target.value);
                      checkUsernameAvailability(e.target.value);
                    }}
                    minLength={PROFILE_USERNAME_MIN}
                    maxLength={PROFILE_USERNAME_MAX}
                  />

                  {username !== profile.username ? (
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                      {loadingUsername ? (
                        <IconLoader2 className="animate-spin" />
                      ) : usernameAvailable ? (
                        <IconCircleCheckFilled className="text-green-500" />
                      ) : (
                        <IconCircleXFilled className="text-red-500" />
                      )}
                    </div>
                  ) : null}
                </div>

                <LimitDisplay
                  used={username.length}
                  limit={PROFILE_USERNAME_MAX}
                />
              </div> */}

              <div className="space-y-1">
                <Label>Chat Display Name</Label>

                <Input
                  styleName={'modalInputStyle'}
                  placeholder="Chat display name..."
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  maxLength={PROFILE_DISPLAY_NAME_MAX}
                />
              </div>

              <div className="space-y-1">
                <Label className="text-sm">
                  What would you like the AI to know about you to provide better
                  responses?
                </Label>

                <TextareaAutosize
                  value={profileInstructions}
                  onValueChange={setProfileInstructions}
                  placeholder="Profile context... (optional)"
                  minRows={6}
                  maxRows={10}
                />

                <LimitDisplay
                  used={profileInstructions.length}
                  limit={PROFILE_CONTEXT_MAX}
                />
              </div>

              <div className="space-y-1">
                <Label>Profile Image</Label>

                <ImagePicker
                  src={profileImageSrc}
                  image={profileImageFile}
                  height={300}
                  width={300}
                  onSrcChange={setProfileImageSrc}
                  onImageChange={setProfileImageFile}
                />
                <div
                  className={loginStyles.checkboxContent}
                  style={{ marginTop: '1rem' }}
                >
                  <div className={loginStyles.signupCheckbox}>
                    <input
                      type="checkbox"
                      checked={isMarketing}
                      className={loginStyles.signupCheckboxInput}
                      onChange={(e) => setIsMarketing(e.target.checked)}
                    />
                  </div>
                  <p className={loginStyles.sendMeTheMarketingEmailChatni}>
                    <span className={loginStyles.sendMeTheMarketingEmailSub4}>
                      Send me the marketing emails
                    </span>
                  </p>
                </div>
              </div>
            </TabsContent>

            <TabsContent className="mt-4 space-y-4" value="keys">
              <div className="mt-5 space-y-2">
                <Label className="flex items-center">
                  {useAzureOpenai
                    ? isEnvAzureOpenai
                      ? ''
                      : 'Azure OpenAI API Key'
                    : isEnvOpenai
                      ? ''
                      : 'OpenAI API Key'}

                  <Button
                    className={cn(
                      'h-[18px] w-[130px] text-[11px]',
                      (useAzureOpenai && !isEnvAzureOpenai) ||
                        (!useAzureOpenai && !isEnvOpenai)
                        ? 'ml-3'
                        : 'mb-3',
                    )}
                    onClick={() => setUseAzureOpenai(!useAzureOpenai)}
                  >
                    {useAzureOpenai
                      ? 'Use Standard OpenAI'
                      : 'Use Azure OpenAI'}
                  </Button>
                </Label>

                {useAzureOpenai ? (
                  <>
                    {isEnvAzureOpenai ? (
                      <Label>Azure OpenAI API key set by admin.</Label>
                    ) : (
                      <Input
                        placeholder="Azure OpenAI API Key"
                        type="password"
                        value={azureOpenaiAPIKey}
                        onChange={(e) => setAzureOpenaiAPIKey(e.target.value)}
                      />
                    )}
                  </>
                ) : (
                  <>
                    {isEnvOpenai ? (
                      <Label>OpenAI API key set by admin.</Label>
                    ) : (
                      <Input
                        placeholder="OpenAI API Key"
                        type="password"
                        value={openaiAPIKey}
                        onChange={(e) => setOpenaiAPIKey(e.target.value)}
                      />
                    )}
                  </>
                )}
              </div>

              <div className="ml-8 space-y-3">
                {useAzureOpenai ? (
                  <>
                    {
                      <div className="space-y-1">
                        {!!process.env.NEXT_PUBLIC_AZURE_OPENAI_ENDPOINT ? (
                          <Label className="text-xs">
                            Azure endpoint set by admin.
                          </Label>
                        ) : (
                          <>
                            <Label>Azure Endpoint</Label>

                            <Input
                              placeholder="https://your-endpoint.openai.azure.com"
                              type="password"
                              value={azureOpenaiEndpoint}
                              onChange={(e) =>
                                setAzureOpenaiEndpoint(e.target.value)
                              }
                            />
                          </>
                        )}
                      </div>
                    }

                    {
                      <div className="space-y-1">
                        {!!process.env.NEXT_PUBLIC_AZURE_GPT_35_TURBO_ID ? (
                          <Label className="text-xs">
                            Azure GPT-3.5 Turbo deployment name set by admin.
                          </Label>
                        ) : (
                          <>
                            <Label>Azure GPT-3.5 Turbo Deployment Name</Label>

                            <Input
                              placeholder="Azure OpenAI GPT-3.5 Turbo Deployment Name"
                              type="password"
                              value={azureOpenai35TurboID}
                              onChange={(e) =>
                                setAzureOpenai35TurboID(e.target.value)
                              }
                            />
                          </>
                        )}
                      </div>
                    }

                    {
                      <div className="space-y-1">
                        {!!process.env.NEXT_PUBLIC_AZURE_GPT_45_TURBO_ID ? (
                          <Label className="text-xs">
                            Azure GPT-4.5 Turbo deployment name set by admin.
                          </Label>
                        ) : (
                          <>
                            <Label>Azure GPT-4.5 Turbo Deployment Name</Label>

                            <Input
                              placeholder="Azure OpenAI GPT-4.5 Turbo Deployment Name"
                              type="password"
                              value={azureOpenai45TurboID}
                              onChange={(e) =>
                                setAzureOpenai45TurboID(e.target.value)
                              }
                            />
                          </>
                        )}
                      </div>
                    }

                    {
                      <div className="space-y-1">
                        {!!process.env.NEXT_PUBLIC_AZURE_GPT_45_VISION_ID ? (
                          <Label className="text-xs">
                            Azure GPT-4.5 Vision deployment name set by admin.
                          </Label>
                        ) : (
                          <>
                            <Label>Azure GPT-4.5 Vision Deployment Name</Label>

                            <Input
                              placeholder="Azure OpenAI GPT-4.5 Vision Deployment Name"
                              type="password"
                              value={azureOpenai45VisionID}
                              onChange={(e) =>
                                setAzureOpenai45VisionID(e.target.value)
                              }
                            />
                          </>
                        )}
                      </div>
                    }

                    {
                      <div className="space-y-1">
                        {!!process.env.NEXT_PUBLIC_AZURE_EMBEDDINGS_ID ? (
                          <Label className="text-xs">
                            Azure Embeddings deployment name set by admin.
                          </Label>
                        ) : (
                          <>
                            <Label>Azure Embeddings Deployment Name</Label>

                            <Input
                              placeholder="Azure OpenAI Embeddings Deployment Name"
                              type="password"
                              value={azureEmbeddingsID}
                              onChange={(e) =>
                                setAzureEmbeddingsID(e.target.value)
                              }
                            />
                          </>
                        )}
                      </div>
                    }
                  </>
                ) : (
                  <>
                    <div className="space-y-1">
                      {!!process.env.NEXT_PUBLIC_OPENAI_ORGANIZATION_ID ? (
                        <Label className="text-xs">
                          OpenAI Organization ID set by admin.
                        </Label>
                      ) : (
                        <>
                          <Label>OpenAI Organization ID</Label>

                          <Input
                            placeholder="OpenAI Organization ID (optional)"
                            disabled={
                              !!process.env.NEXT_PUBLIC_OPENAI_ORGANIZATION_ID
                            }
                            type="password"
                            value={openaiOrgID}
                            onChange={(e) => setOpenaiOrgID(e.target.value)}
                          />
                        </>
                      )}
                    </div>
                  </>
                )}
              </div>

              <div className="space-y-1">
                {isEnvAnthropic ? (
                  <Label>Anthropic API key set by admin.</Label>
                ) : (
                  <>
                    <Label>Anthropic API Key</Label>
                    <Input
                      placeholder="Anthropic API Key"
                      type="password"
                      value={anthropicAPIKey}
                      onChange={(e) => setAnthropicAPIKey(e.target.value)}
                    />
                  </>
                )}
              </div>

              <div className="space-y-1">
                {isEnvGoogleGemini ? (
                  <Label>Google Gemini API key set by admin.</Label>
                ) : (
                  <>
                    <Label>Google Gemini API Key</Label>
                    <Input
                      placeholder="Google Gemini API Key"
                      type="password"
                      value={googleGeminiAPIKey}
                      onChange={(e) => setGoogleGeminiAPIKey(e.target.value)}
                    />
                  </>
                )}
              </div>

              <div className="space-y-1">
                {isEnvMistral ? (
                  <Label>Mistral API key set by admin.</Label>
                ) : (
                  <>
                    <Label>Mistral API Key</Label>
                    <Input
                      placeholder="Mistral API Key"
                      type="password"
                      value={mistralAPIKey}
                      onChange={(e) => setMistralAPIKey(e.target.value)}
                    />
                  </>
                )}
              </div>

              <div className="space-y-1">
                {isEnvPerplexity ? (
                  <Label>Perplexity API key set by admin.</Label>
                ) : (
                  <>
                    <Label>Perplexity API Key</Label>
                    <Input
                      placeholder="Perplexity API Key"
                      type="password"
                      value={perplexityAPIKey}
                      onChange={(e) => setPerplexityAPIKey(e.target.value)}
                    />
                  </>
                )}
              </div>

              <div className="space-y-1">
                {isEnvOpenrouter ? (
                  <Label>OpenRouter API key set by admin.</Label>
                ) : (
                  <>
                    <Label>OpenRouter API Key</Label>
                    <Input
                      placeholder="OpenRouter API Key"
                      type="password"
                      value={openrouterAPIKey}
                      onChange={(e) => setOpenrouterAPIKey(e.target.value)}
                    />
                  </>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className={`mt-6 flex items-center ${styles.modalButtons}`}>
          <div className="flex items-center space-x-1">
            {/* <ThemeSwitcher />

            <WithTooltip
              display={
                <div>Download ChatNI 1.0 data as JSON. Import coming soon!</div>
              }
              trigger={
                <IconFileDownload
                  className="cursor-pointer hover:opacity-50"
                  size={32}
                  onClick={exportLocalStorageAsJSON}
                />
              }
            /> */}
          </div>

          <div className={`ml-auto space-x-2 `}>
            <Button
              styleName={'secondaryButton'}
              onClick={() => setIsOpen(false)}
            >
              Cancel
            </Button>

            <Button
              styleName={'primaryButton'}
              ref={buttonRef}
              onClick={handleSave}
            >
              Save
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};
