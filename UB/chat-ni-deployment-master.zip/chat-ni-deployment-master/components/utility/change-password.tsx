'use client';

import { FC, useState } from 'react';

import { useRouter } from 'next/navigation';

import loginStyles from '../../styles/OnBoardingStyles/LoginPage.module.css';
import { Brand } from '../ui/brand';
import { Button } from '../ui/button';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';
import { Input } from '../ui/input';

import { supabase } from '@/lib/supabase/browser-client';

interface ChangePasswordProps {}

export const ChangePassword: FC<ChangePasswordProps> = () => {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [confirmPassword, setConfirmPassword] = useState('');

  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [confirmPasswordError, setConfirmPasswordError] = useState('');

  const handlePasswordChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(event.target.value);
    if (passwordError) setPasswordError('');
  };

  const handleConfirmPasswordChange = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    setConfirmPassword(event.target.value);
    if (confirmPasswordError) setConfirmPasswordError('');
  };

  const validatePassword = () => {
    if (!password) {
      setPasswordError('Password is required.');
      return false;
    }
    // Example validation: Password length
    if (password.length < 8) {
      setPasswordError('Password must be at least 8 characters long.');
      return false;
    }
    return true;
  };

  const validateConfirmPassword = () => {
    if (password !== confirmPassword) {
      setConfirmPasswordError('Passwords do not match.');
      return false;
    }
    return true;
  };

  const validateForm = () => {
    setPasswordError('');
    setConfirmPasswordError('');

    const isPasswordValid = validatePassword();
    const isConfirmPasswordValid = validateConfirmPassword();

    return isPasswordValid && isConfirmPasswordValid;
  };
  // const handleResetPassword = async () => {
  //   if (!newPassword) return alert('Please enter your new password.');

  //   await supabase.auth.updateUser({ password: newPassword });
  //   localStorage.setItem('status', '1');
  //   router.push('/login');
  // };

  const handleResetPassword = async (
    event: React.MouseEvent<HTMLButtonElement>,
  ) => {
    event.preventDefault();
    setLoading(true);
    if (validateForm()) {
      await supabase.auth.updateUser({ password: password });
      // localStorage.setItem('status', '1');
      setLoading(false);
      router.push('/login');
    } else {
      console.log('Form validation failed.');
    }
  };
  return (
    <div
      className={`flex w-full flex-1 flex-col justify-center gap-2 px-8 sm:max-w-md`}
    >
      <Brand />

      {loading ? (
        <div className="size-12 animate-spin rounded-full border-y-2 border-gray-900"></div>
      ) : (
        <>
          <div className={loginStyles.loginContent}>
            <div
              className={loginStyles.loginText}
              style={{ textAlign: 'center' }}
            >
              Sign Up
            </div>

            <Input
              className="mb-3 rounded-md border bg-inherit px-4 py-2"
              type="password"
              name="password"
              placeholder="Password"
              required
              value={password}
              onChange={handlePasswordChange}
            />
            {passwordError && (
              <div className={loginStyles.errorValidationStyle}>
                {passwordError}
              </div>
            )}

            <Input
              className="mb-6 rounded-md border bg-inherit px-4 py-2"
              type="password"
              name="confirmPassword"
              placeholder="Confirm Password"
              required
              value={confirmPassword}
              onChange={handleConfirmPasswordChange}
            />
            {confirmPasswordError && (
              <div className={loginStyles.errorValidationStyle}>
                {confirmPasswordError}
              </div>
            )}
            <Button
              className={`${loginStyles.loginButton}`}
              onClick={handleResetPassword}
            >
              Update Password
            </Button>
          </div>
        </>
      )}
    </div>
  );
};
