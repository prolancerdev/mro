import { FC } from 'react';

import { ShareItem } from './ShareItem';

import { Tables } from '@/supabase/types';
import { User } from '@supabase/supabase-js';

interface ShareAssistantProps {
  user: User | null;
  assistant: Tables<'assistants'>;
}

export const ShareAssistant: FC<ShareAssistantProps> = ({
  user,
  assistant,
}) => {
  return (
    <ShareItem
      user={user}
      item={assistant}
      contentType="assistants"
      renderContent={() => <div>{assistant.name}</div>}
    />
  );
};
