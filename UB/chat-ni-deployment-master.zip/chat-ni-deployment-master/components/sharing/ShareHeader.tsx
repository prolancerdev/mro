import { FC } from 'react';

import Link from 'next/link';

import { Button } from '../ui/button';

import { Session } from '@supabase/supabase-js';

interface ShareHeaderProps {
  session: Session;
}

export const ShareHeader: FC<ShareHeaderProps> = ({ session }) => {
  return (
    <div className="flex justify-between">
      <Link
        href="https://www.chatbotui.com"
        className="text-2xl font-bold hover:opacity-50"
      >
        ChatNI
      </Link>

      <Link href={session ? '/chat' : '/login'}>
        <Button size="sm">{session ? 'App' : 'Sign Up'}</Button>
      </Link>
    </div>
  );
};
