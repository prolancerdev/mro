import { useAuth0 } from '@auth0/auth0-react';

const LoginButton = () => {
  const { loginWithRedirect } = useAuth0();

  return (
    <button
      className="sm:w-sm mt-8 cursor-pointer select-none items-center gap-2 rounded-full bg-[#4556ff] px-3 py-5 text-center text-lg font-semibold leading-3 text-[#F5FAFF] transition-colors duration-300 hover:bg-[#2C3FFF] lg:min-w-[500px]"
      onClick={() => loginWithRedirect()}
    >
      Log In
    </button>
  );
};

export default LoginButton;
