import { IconAdjustmentsHorizontal } from '@tabler/icons-react';
import { FC, useContext, useEffect, useRef } from 'react';

import useHotkey from '@/lib/hooks/use-hotkey';

import styles from '../../styles/componentStyles/secondary.module.css';
import { ChatSettingsForm } from '../ui/ChatSettingsForm';
import { Button } from '../ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';

import { ChatbotUIContext } from '@/context/context';
import { CHAT_SETTING_LIMITS } from '@/lib/chat-setting-limits';
import { LLM_LIST } from '@/lib/models/llm/llm-list';

interface ChatSettingsProps {}

export const ChatSettings: FC<ChatSettingsProps> = ({}) => {
  useHotkey('i', () => handleClick());

  const { chatSettings, setChatSettings } = useContext(ChatbotUIContext);

  const buttonRef = useRef<HTMLButtonElement>(null);

  const handleClick = () => {
    if (buttonRef.current) {
      buttonRef.current.click();
    }
  };

  useEffect(() => {
    if (!chatSettings) return;

    setChatSettings({
      ...chatSettings,
      temperature: Math.min(
        chatSettings.temperature,
        CHAT_SETTING_LIMITS[chatSettings.model]?.MAX_TEMPERATURE || 1,
      ),
      contextLength: Math.min(
        chatSettings.contextLength,
        CHAT_SETTING_LIMITS[chatSettings.model]?.MAX_CONTEXT_LENGTH || 4096,
      ),
    });
  }, [chatSettings?.model]);

  if (!chatSettings) return null;

  const fullModel = LLM_LIST.find((llm) => llm.modelId === chatSettings.model);
  // temmprory comment out
  return (
    <></>
    // <div>
    //   <Popover>
    //     <PopoverTrigger>
    //       <Button
    //         ref={buttonRef}
    //         className="flex items-center space-x-2"
    //         styleName={'mainContentModelSettings'}
    //       >
    //         <div className={`text-lg `}>
    //           {fullModel?.modelName || chatSettings.model}
    //         </div>
    //         <svg
    //           xmlns="http://www.w3.org/2000/svg"
    //           width="16"
    //           height="16"
    //           viewBox="0 0 16 17"
    //           fill="none"
    //         >
    //           <mask
    //             id="mask0_228_269"
    //             mask-type="alpha"
    //             maskUnits="userSpaceOnUse"
    //             x="0"
    //             y="0"
    //             width="16"
    //             height="17"
    //           >
    //             <rect
    //               x="16"
    //               y="0.5"
    //               width="16"
    //               height="16"
    //               transform="rotate(90 16 0.5)"
    //               fill="#D9D9D9"
    //             />
    //           </mask>
    //           <g mask="url(#mask0_228_269)">
    //             <path
    //               d="M1.92496 6.44166C1.59819 6.11489 1.59819 5.5851 1.92496 5.25833C2.25173 4.93156 2.78152 4.93156 3.10829 5.25833L7.99996 10.15L12.8916 5.25833C13.2184 4.93156 13.7482 4.93156 14.075 5.25833C14.4017 5.5851 14.4017 6.1149 14.075 6.44166L8.9192 11.5974C8.41152 12.1051 7.5884 12.1051 7.08072 11.5974L1.92496 6.44166Z"
    //               fill="#F5FAFF"
    //             />
    //           </g>
    //         </svg>
    //       </Button>
    //     </PopoverTrigger>

    //     <PopoverContent
    //       className="bg-background border-input relative flex max-h-[calc(100vh-60px)] w-[300px] flex-col space-y-4 overflow-auto rounded-lg border-2 p-6 dark:border-none sm:w-[350px] md:w-[400px] lg:w-[500px]"
    //       align="end"
    //     >
    //       <ChatSettingsForm
    //         chatSettings={chatSettings}
    //         onChangeChatSettings={setChatSettings}
    //       />
    //     </PopoverContent>
    //   </Popover>
    // </div>
  );
};
