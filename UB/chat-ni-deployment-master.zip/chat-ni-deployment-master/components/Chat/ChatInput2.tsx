import {
  IconBolt,
  IconCirclePlus,
  IconPlayerStopFilled,
  IconSend,
} from '@tabler/icons-react';
import { FC, useContext, useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';

import Image from 'next/image';

import useHotkey from '@/lib/hooks/use-hotkey';

import attach_fileIcon from '../../assets/layoutIcons/attach_file.png';
import sendIcon from '../../assets/layoutIcons/send.png';
import styles from '../../styles/componentStyles/secondary.module.css';
import { TextareaAutosize } from '../ui/TextareaAutosize';
import { Input } from '../ui/input';
import { ChatCommandInput } from './ChatCommandInput';
import { ChatFilesDisplay } from './ChatFilesDisplay';
import { useChatHandler } from './chat-hooks/UseChatHandler';
import { usePromptAndCommand } from './chat-hooks/UsePromptAndCommand';
import { useSelectFileHandler } from './chat-hooks/UseSelectFileHandler';

import { ChatbotUIContext } from '@/context/context';
import { LLM_LIST } from '@/lib/models/llm/llm-list';
import { cn } from '@/lib/utils';

export const SIDEBAR_ICON_SIZE = 24;

interface ChatInputProps {}

export const ChatInput: FC<ChatInputProps> = ({}) => {
  const { t } = useTranslation();

  useHotkey('l', () => {
    handleFocusChatInput();
  });

  const [isTyping, setIsTyping] = useState<boolean>(false);

  const {
    userInput,
    chatMessages,
    isGenerating,
    selectedPreset,
    selectedAssistant,
    focusPrompt,
    setFocusPrompt,
    focusFile,
    focusTool,
    setFocusTool,
    isToolPickerOpen,
    isPromptPickerOpen,
    setIsPromptPickerOpen,
    isAtPickerOpen,
    setFocusFile,
    chatSettings,
    selectedTools,
    setSelectedTools,
  } = useContext(ChatbotUIContext);

  const {
    chatInputRef,
    handleSendMessage,
    handleStopMessage,
    handleFocusChatInput,
  } = useChatHandler();

  const { handleInputChange } = usePromptAndCommand();

  const { filesToAccept, handleSelectDeviceFile } = useSelectFileHandler();

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setTimeout(() => {
      handleFocusChatInput();
    }, 200); // FIX: hacky
  }, [selectedPreset, selectedAssistant]);

  const handleKeyDown = (event: React.KeyboardEvent) => {
    if (!isTyping && event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      setIsPromptPickerOpen(false);
      handleSendMessage(userInput, chatMessages, false);
    }

    if (
      isPromptPickerOpen &&
      (event.key === 'Tab' ||
        event.key === 'ArrowUp' ||
        event.key === 'ArrowDown')
    ) {
      event.preventDefault();
      setFocusPrompt(!focusPrompt);
    }

    if (
      isAtPickerOpen &&
      (event.key === 'Tab' ||
        event.key === 'ArrowUp' ||
        event.key === 'ArrowDown')
    ) {
      event.preventDefault();
      setFocusFile(!focusFile);
    }

    if (
      isToolPickerOpen &&
      (event.key === 'Tab' ||
        event.key === 'ArrowUp' ||
        event.key === 'ArrowDown')
    ) {
      event.preventDefault();
      setFocusTool(!focusTool);
    }
  };

  const handlePaste = (event: React.ClipboardEvent) => {
    const imagesAllowed = LLM_LIST.find(
      (llm) => llm.modelId === chatSettings?.model,
    )?.imageInput;
    if (!imagesAllowed) return;

    const items = event.clipboardData.items;
    for (const item of items) {
      if (item.type.indexOf('image') === 0) {
        const file = item.getAsFile();
        if (!file) return;
        handleSelectDeviceFile(file);
      }
    }
  };

  // return (
  // <div
  //   className={`border-input relative mt-3 flex min-h-[60px] w-full items-center justify-center rounded-xl border-2 ${styles.searchStyles}`}
  // >

  //     <div className="absolute bottom-[76px] left-0 max-h-[300px] w-full overflow-auto rounded-xl dark:border-none">
  //       {/* ChatCommandInput assumed to be another component */}
  //     </div>

  //     <>
  //       {/* <Image
  //         style={{ marginLeft: '1rem' }}
  //         src={attach_fileIcon}
  //         alt="Attach File"
  //         width={SIDEBAR_ICON_SIZE}
  //         height={SIDEBAR_ICON_SIZE}
  //         onClick={() => fileInputRef.current?.click()}
  //       /> */}
  //       <button
  //         style={{ marginLeft: '1rem' }}
  //         onClick={() => fileInputRef.current?.click()}
  //       >
  //         <svg
  //           xmlns="http://www.w3.org/2000/svg"
  //           width="24"
  //           height="24"
  //           viewBox="0 0 24 24"
  //           fill="none"
  //         >
  //           <mask
  //             id="mask0_2_83"
  //             style={{ maskType: 'alpha' }}
  //             maskUnits="userSpaceOnUse"
  //             x="0"
  //             y="0"
  //             width="24"
  //             height="24"
  //           >
  //             <rect width="24" height="24" fill="#D9D9D9" />
  //           </mask>
  //           <g mask="url(#mask0_2_83)">
  //             <path
  //               d="M18 15.75C18 17.4833 17.3917 18.9583 16.175 20.175C14.9583 21.3917 13.4833 22 11.75 22C10.0167 22 8.54167 21.3917 7.325 20.175C6.10833 18.9583 5.5 17.4833 5.5 15.75V6.5C5.5 5.25 5.9375 4.1875 6.8125 3.3125C7.6875 2.4375 8.75 2 10 2C11.25 2 12.3125 2.4375 13.1875 3.3125C14.0625 4.1875 14.5 5.25 14.5 6.5V15.25C14.5 16.0167 14.2333 16.6667 13.7 17.2C13.1667 17.7333 12.5167 18 11.75 18C10.9833 18 10.3333 17.7333 9.8 17.2C9.26667 16.6667 9 16.0167 9 15.25V6H11V15.25C11 15.4667 11.0708 15.6458 11.2125 15.7875C11.3542 15.9292 11.5333 16 11.75 16C11.9667 16 12.1458 15.9292 12.2875 15.7875C12.4292 15.6458 12.5 15.4667 12.5 15.25V6.5C12.4833 5.8 12.2375 5.20833 11.7625 4.725C11.2875 4.24167 10.7 4 10 4C9.3 4 8.70833 4.24167 8.225 4.725C7.74167 5.20833 7.5 5.8 7.5 6.5V15.75C7.48333 16.9333 7.89167 17.9375 8.725 18.7625C9.55833 19.5875 10.5667 20 11.75 20C12.9167 20 13.9083 19.5875 14.725 18.7625C15.5417 17.9375 15.9667 16.9333 16 15.75V6H18V15.75Z"
  //               fill="#E7EFF8"
  //             />
  //           </g>
  //         </svg>
  //       </button>
  //       <input
  //         ref={fileInputRef}
  //         className="hidden"
  //         type="file"
  //         onChange={(e) => {
  //           if (!e.target.files) return;
  //           handleSelectDeviceFile(e.target.files[0]);
  //         }}
  //         accept={filesToAccept}
  //       />

  //     </>

  //     <TextareaAutosize
  //       textareaRef={chatInputRef}
  //       className="mx-2 grow resize-none bg-transparent text-white placeholder:text-white focus:outline-none"
  //       placeholder={`Ask anything. Type “/“ for prompts.`}
  //       onValueChange={handleInputChange}
  //       value={userInput}
  //       minRows={1}
  //       maxRows={18}
  //       onKeyDown={handleKeyDown}
  //       onPaste={handlePaste}
  //       onCompositionStart={() => setIsTyping(true)}
  //       onCompositionEnd={() => setIsTyping(false)}
  //     />

  //     <div className="absolute bottom-[14px] right-3 cursor-pointer hover:opacity-50">
  //       {isGenerating ? (
  //         <IconPlayerStopFilled
  //           className="hover:bg-background animate-pulse rounded bg-transparent p-1"
  //           onClick={handleStopMessage}
  //           size={30}
  //         />
  //       ) : (
  //         // <Image
  //         //   src={sendIcon}
  //         //   alt="Send"
  //         //   width={SIDEBAR_ICON_SIZE}
  //         //   height={SIDEBAR_ICON_SIZE}
  //         //   onClick={() => {
  //         //     if (!userInput) return;
  //         //     handleSendMessage(userInput, chatMessages, false);
  //         //   }}
  //         // />
  //         <button
  //           onClick={() => {
  //             if (!userInput) return;
  //             handleSendMessage(userInput, chatMessages, false);
  //           }}
  //         >
  //           <svg
  //             xmlns="http://www.w3.org/2000/svg"
  //             width="24"
  //             height="24"
  //             viewBox="0 0 24 24"
  //             fill="none"
  //           >
  //             <mask
  //               id="mask0_2_85"
  //               style={{ maskType: 'alpha' }}
  //               maskUnits="userSpaceOnUse"
  //               x="0"
  //               y="0"
  //               width="24"
  //               height="24"
  //             >
  //               <rect width="24" height="24" fill="#D9D9D9" />
  //             </mask>
  //             <g mask="url(#mask0_2_85)">
  //               <path
  //                 d="M3 20V4L22 12L3 20ZM5 17L16.85 12L5 7V10.5L11 12L5 13.5V17Z"
  //                 fill="#F5FAFF"
  //               />
  //             </g>
  //           </svg>
  //         </button>
  //       )}
  //     </div>
  //   </div>
  // );

  return (
    <div>
      <ChatFilesDisplay />

      <div
        className="flex flex-wrap justify-center gap-2"
        style={{ maxWidth: '100%', overflow: 'hidden' }}
      >
        {selectedTools &&
          selectedTools.map((tool, index) => (
            <div
              key={index}
              className="mt-2 flex justify-center"
              onClick={() =>
                setSelectedTools(
                  selectedTools.filter(
                    (selectedTool) => selectedTool.id !== tool.id,
                  ),
                )
              }
              style={{ cursor: 'pointer' }}
            >
              <div
                className="flex items-center justify-center space-x-1 rounded-lg bg-purple-600 px-3 py-1 hover:opacity-50"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '0.25rem',
                  backgroundColor: '#6b46c1',
                  padding: '0.25rem 0.75rem',
                  borderRadius: '0.5rem',
                }}
              >
                <IconBolt size={20} />

                <div>{tool.name}</div>
              </div>
            </div>
          ))}
      </div>

      <div
        className={`border-input relative flex min-h-[60px] w-full items-center justify-center rounded-xl border-2 ${styles.searchStyles} ${styles.chatbBox}`}
      >
        <div
          className="absolute bottom-[76px] left-0 max-h-[300px] w-full overflow-auto rounded-xl dark:border-none"
          style={{
            position: 'absolute',
            bottom: '76px',
            left: 0,
            maxHeight: '300px',
            width: '100%',
            overflow: 'auto',
            borderRadius: '1rem',
          }}
        >
          <ChatCommandInput />
        </div>

        <>
          {/* <Image
            style={{ marginLeft: '1rem' }}
            src={attach_fileIcon} // Ensure you have this variable defined or replace it with a string path
            alt="Attach File"
            width={SIDEBAR_ICON_SIZE} // Ensure you have this variable defined or replace it with the actual size
            height={SIDEBAR_ICON_SIZE} // Ensure you have this variable defined or replace it with the actual size
            onClick={() => fileInputRef.current?.click()}
          /> */}
          <Input
            ref={fileInputRef}
            className="hidden"
            type="file"
            onChange={(e) => {
              if (!e.target.files) return;
              handleSelectDeviceFile(e.target.files[0]);
            }}
            accept={filesToAccept}
          />
        </>

        <TextareaAutosize
          styleName={'mainChatBoxTextAreaStyle'}
          textareaRef={chatInputRef}
          className="ring-offset-background placeholder:text-muted-foreground focus-visible:ring-ring text-md flex w-full resize-none rounded-md border-none bg-transparent px-14 py-2 focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50"
          placeholder={t(`Ask anything. Type “/“ for prompts.`)}
          onValueChange={handleInputChange}
          value={userInput}
          minRows={1}
          maxRows={18}
          onKeyDown={handleKeyDown}
          onPaste={handlePaste}
          onCompositionStart={() => setIsTyping(true)}
          onCompositionEnd={() => setIsTyping(false)}
        />

        <div
          className="flex cursor-pointer items-center hover:opacity-50"
          // style={{
          //   position: 'absolute',
          //   bottom: '14px',
          //   right: '3px',
          //   cursor: 'pointer',
          // }}
        >
          {isGenerating ? (
            <IconPlayerStopFilled
              className="hover:bg-background mr-4 animate-pulse rounded bg-transparent p-1"
              onClick={handleStopMessage}
              size={30}
            />
          ) : (
            <div
              style={{ marginRight: '1rem', marginBottom: '0.25rem' }}
              onClick={() => {
                if (!userInput) return;
                handleSendMessage(userInput, chatMessages, false);
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
              >
                <mask
                  id="mask0_2_85"
                  style={{ maskType: 'alpha' }}
                  maskUnits="userSpaceOnUse"
                  x="0"
                  y="0"
                  width="24"
                  height="24"
                >
                  <rect width="24" height="24" fill="#D9D9D9" />
                </mask>
                <g mask="url(#mask0_2_85)">
                  <path
                    d="M3 20V4L22 12L3 20ZM5 17L16.85 12L5 7V10.5L11 12L5 13.5V17Z"
                    fill="#F5FAFF"
                  />
                </g>
              </svg>
            </div>
            // <Image
            //   style={{marginRight: "1rem"}}
            //   src={sendIcon} // Ensure you have this variable defined or replace it with a string path
            //   alt="Send"
            //   width={SIDEBAR_ICON_SIZE} // Ensure you have this variable defined or replace it with the actual size
            //   height={SIDEBAR_ICON_SIZE} // Ensure you have this variable defined or replace it with the actual size
            //   onClick={() => {
            //     if (!userInput) return;
            //     handleSendMessage(userInput, chatMessages, false); // Ensure you have chatMessages defined or adjusted based on your actual state
            //   }}
            // />
          )}
        </div>
      </div>
    </div>
  );

  // ============= Main working correct code ========================
  return (
    <div>
      <ChatFilesDisplay />

      <div className="flex flex-wrap justify-center gap-2">
        {selectedTools &&
          selectedTools.map((tool, index) => (
            <div
              key={index}
              className="mt-2 flex justify-center"
              onClick={() =>
                setSelectedTools(
                  selectedTools.filter(
                    (selectedTool) => selectedTool.id !== tool.id,
                  ),
                )
              }
            >
              <div className="flex cursor-pointer items-center justify-center space-x-1 rounded-lg bg-purple-600 px-3 py-1 hover:opacity-50">
                <IconBolt size={20} />

                <div>{tool.name}</div>
              </div>
            </div>
          ))}
      </div>

      <div
        className={`border-input relative mt-3 flex min-h-[60px] w-full items-center justify-center rounded-xl border-2 `}
      >
        <div
          className={`absolute bottom-[76px] left-0 max-h-[300px] w-full overflow-auto rounded-xl dark:border-none ${styles.chatbBox}`}
        >
          <ChatCommandInput />
        </div>

        <>
          <Image
            style={{ marginLeft: '1rem' }}
            src={attach_fileIcon} // Ensure you have this variable defined or replace it with a string path
            alt="Attach File"
            width={SIDEBAR_ICON_SIZE} // Ensure you have this variable defined or replace it with the actual size
            height={SIDEBAR_ICON_SIZE} // Ensure you have this variable defined or replace it with the actual size
            onClick={() => fileInputRef.current?.click()}
          />
          <Input
            ref={fileInputRef}
            className="hidden"
            type="file"
            onChange={(e) => {
              if (!e.target.files) return;
              handleSelectDeviceFile(e.target.files[0]);
            }}
            accept={filesToAccept}
          />
        </>

        <TextareaAutosize
          styleName={'mainChatBoxTextAreaStyle'}
          textareaRef={chatInputRef}
          className="ring-offset-background placeholder:text-muted-foreground focus-visible:ring-ring text-md flex w-full resize-none rounded-md border-none bg-transparent px-14 py-2 focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50"
          placeholder={t(`Ask anything. Type “/“ for prompts.`)}
          onValueChange={handleInputChange}
          value={userInput}
          minRows={1}
          maxRows={18}
          onKeyDown={handleKeyDown}
          onPaste={handlePaste}
          onCompositionStart={() => setIsTyping(true)}
          onCompositionEnd={() => setIsTyping(false)}
        />

        <div className="absolute bottom-[14px] right-3 cursor-pointer hover:opacity-50">
          {isGenerating ? (
            <IconPlayerStopFilled
              className="hover:bg-background animate-pulse rounded bg-transparent p-1"
              onClick={handleStopMessage}
              size={30}
            />
          ) : (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
            >
              <mask
                id="mask0_2_85"
                style={{ maskType: 'alpha' }}
                maskUnits="userSpaceOnUse"
                x="0"
                y="0"
                width="24"
                height="24"
              >
                <rect width="24" height="24" fill="#D9D9D9" />
              </mask>
              <g mask="url(#mask0_2_85)">
                <path
                  d="M3 20V4L22 12L3 20ZM5 17L16.85 12L5 7V10.5L11 12L5 13.5V17Z"
                  fill="#F5FAFF"
                />
              </g>
            </svg>
          )}
        </div>
      </div>
    </div>
  );
  return (
    <>
      <ChatFilesDisplay />

      <div className="flex flex-wrap justify-center gap-2">
        {selectedTools &&
          selectedTools.map((tool, index) => (
            <div
              key={index}
              className="mt-2 flex justify-center"
              onClick={() =>
                setSelectedTools(
                  selectedTools.filter(
                    //@ts-ignore
                    (selectedTool) => selectedTool.id !== tool.id,
                  ),
                )
              }
            >
              <div className="flex cursor-pointer items-center justify-center space-x-1 rounded-lg bg-purple-600 px-3 py-1 hover:opacity-50">
                <IconBolt size={20} />

                <div>
                  {
                    //@ts-ignore
                    tool.name
                  }
                </div>
              </div>
            </div>
          ))}
      </div>

      <div
        className={`border-input relative mt-3 flex min-h-[60px] w-full items-center justify-center rounded-xl border-2 ${styles.searchStyles}`}
      >
        <div className="absolute bottom-[76px] left-0 max-h-[300px] w-full overflow-auto rounded-xl dark:border-none">
          <ChatCommandInput />
        </div>

        <>
          {/* <IconCirclePlus
            className="absolute bottom-[12px] left-3 cursor-pointer p-1 hover:opacity-50"
            size={32}
            onClick={() => fileInputRef.current?.click()}
          /> */}

          {/* Hidden input to select files from device */}
          <Image
            style={{ marginLeft: '1rem' }}
            src={attach_fileIcon}
            alt="Attach File"
            width={SIDEBAR_ICON_SIZE}
            height={SIDEBAR_ICON_SIZE}
            onClick={() => fileInputRef.current?.click()}
          />
          <Input
            ref={fileInputRef}
            className="hidden"
            type="file"
            onChange={(e) => {
              if (!e.target.files) return;
              handleSelectDeviceFile(e.target.files[0]);
            }}
            accept={filesToAccept}
          />
        </>

        <TextareaAutosize
          textareaRef={chatInputRef}
          className="ring-offset-background placeholder:text-muted-foreground focus-visible:ring-ring text-md flex w-full resize-none rounded-md border-none bg-transparent px-14 py-2 focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50"
          placeholder={t(`Ask anything. Type “/“ for prompts.`)}
          onValueChange={handleInputChange}
          value={userInput}
          minRows={1}
          maxRows={18}
          onKeyDown={handleKeyDown}
          onPaste={handlePaste}
          onCompositionStart={() => setIsTyping(true)}
          onCompositionEnd={() => setIsTyping(false)}
        />

        <div className="absolute bottom-[14px] right-3 cursor-pointer hover:opacity-50">
          {isGenerating ? (
            <IconPlayerStopFilled
              className="hover:bg-background animate-pulse rounded bg-transparent p-1"
              onClick={handleStopMessage}
              size={30}
            />
          ) : (
            <Image
              src={sendIcon}
              alt="Send"
              width={SIDEBAR_ICON_SIZE}
              height={SIDEBAR_ICON_SIZE}
              onClick={() => {
                if (!userInput) return;
                handleSendMessage(userInput, chatMessages, false);
              }}
            />
            // <IconSend
            //   className={cn(
            //     'bg-primary text-secondary rounded p-1 ',
            //     !userInput && 'cursor-not-allowed opacity-50',
            //   )}
            // onClick={() => {
            //   if (!userInput) return;

            //   handleSendMessage(userInput, chatMessages, false);
            // }}
            //   size={30}
            // />
          )}
        </div>
      </div>
    </>
  );
};
