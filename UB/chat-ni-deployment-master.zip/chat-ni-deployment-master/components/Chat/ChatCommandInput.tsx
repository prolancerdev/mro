import { FC, useContext } from 'react';

import { FilePicker } from './FilePicker';
import { PromptPicker } from './PromptPicker';
import { ToolPicker } from './ToolPicker';
import { usePromptAndCommand } from './chat-hooks/UsePromptAndCommand';

import { ChatbotUIContext } from '@/context/context';

interface ChatCommandInputProps {}

export const ChatCommandInput: FC<ChatCommandInputProps> = ({}) => {
  const {
    newMessageFiles,
    chatFiles,
    slashCommand,
    isAtPickerOpen,
    setIsAtPickerOpen,
    atCommand,
    focusPrompt,
    focusFile,
  } = useContext(ChatbotUIContext);

  const { handleSelectUserFile, handleSelectUserCollection } =
    usePromptAndCommand();

  return (
    <>
      <PromptPicker />

      <FilePicker
        isOpen={isAtPickerOpen}
        searchQuery={atCommand}
        onOpenChange={setIsAtPickerOpen}
        selectedFileIds={[...newMessageFiles, ...chatFiles].map(
          (file) => file.id,
        )}
        selectedCollectionIds={[]}
        onSelectFile={handleSelectUserFile}
        onSelectCollection={handleSelectUserCollection}
        isFocused={focusFile}
      />

      <ToolPicker />
    </>
  );
};
