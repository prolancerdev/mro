import { IconInfoCircle, IconMessagePlus } from '@tabler/icons-react';
import { FC, useContext } from 'react';

import { useChatHandler } from '@/components/Chat/chat-hooks/UseChatHandler';

import { WithTooltip } from '../ui/WithTooltip';

import { ChatbotUIContext } from '@/context/context';

interface ChatSecondaryButtonsProps {}

export const ChatSecondaryButtons: FC<ChatSecondaryButtonsProps> = ({}) => {
  const { selectedChat } = useContext(ChatbotUIContext);

  const { handleNewChat } = useChatHandler();

  return (
    <>
      {selectedChat && (
        <>
          <WithTooltip
            delayDuration={200}
            display={
              <div>
                <div>Chat info</div>
                <div>Subnet 18 on Bittensor</div>
                {/* <div>{selectedChat.model}</div>
                <div>{selectedChat.prompt}</div>

                <div>{selectedChat.temperature}</div>
                <div>{selectedChat.context_length}</div>

                <div>{selectedChat.include_profile_context}</div>
                <div>{selectedChat.include_workspace_instructions}</div>

                <div>{selectedChat.embeddings_provider}</div> */}
              </div>
            }
            trigger={
              <div className="mt-1">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="25"
                  viewBox="0 0 24 25"
                  fill="none"
                >
                  <mask
                    id="mask0_286_263"
                    style={{ maskType: 'alpha' }}
                    maskUnits="userSpaceOnUse"
                    x="0"
                    y="0"
                    width="24"
                    height="25"
                  >
                    <rect y="0.5" width="24" height="24" fill="#D9D9D9" />
                  </mask>
                  <g mask="url(#mask0_286_263)">
                    <path
                      d="M11 16.5C11 17.0523 11.4477 17.5 12 17.5C12.5523 17.5 13 17.0523 13 16.5V12.5C13 11.9477 12.5523 11.5 12 11.5C11.4477 11.5 11 11.9477 11 12.5V16.5ZM12 9.5C12.2833 9.5 12.521 9.404 12.713 9.212C12.9043 9.02067 13 8.78333 13 8.5C13 8.21667 12.9043 7.979 12.713 7.787C12.521 7.59567 12.2833 7.5 12 7.5C11.7167 7.5 11.4793 7.59567 11.288 7.787C11.096 7.979 11 8.21667 11 8.5C11 8.78333 11.096 9.02067 11.288 9.212C11.4793 9.404 11.7167 9.5 12 9.5ZM12 22.5C10.6167 22.5 9.31667 22.2373 8.1 21.712C6.88333 21.1873 5.825 20.475 4.925 19.575C4.025 18.675 3.31267 17.6167 2.788 16.4C2.26267 15.1833 2 13.8833 2 12.5C2 11.1167 2.26267 9.81667 2.788 8.6C3.31267 7.38333 4.025 6.325 4.925 5.425C5.825 4.525 6.88333 3.81233 8.1 3.287C9.31667 2.76233 10.6167 2.5 12 2.5C13.3833 2.5 14.6833 2.76233 15.9 3.287C17.1167 3.81233 18.175 4.525 19.075 5.425C19.975 6.325 20.6873 7.38333 21.212 8.6C21.7373 9.81667 22 11.1167 22 12.5C22 13.8833 21.7373 15.1833 21.212 16.4C20.6873 17.6167 19.975 18.675 19.075 19.575C18.175 20.475 17.1167 21.1873 15.9 21.712C14.6833 22.2373 13.3833 22.5 12 22.5ZM12 20.5C14.2333 20.5 16.125 19.725 17.675 18.175C19.225 16.625 20 14.7333 20 12.5C20 10.2667 19.225 8.375 17.675 6.825C16.125 5.275 14.2333 4.5 12 4.5C9.76667 4.5 7.875 5.275 6.325 6.825C4.775 8.375 4 10.2667 4 12.5C4 14.7333 4.775 16.625 6.325 18.175C7.875 19.725 9.76667 20.5 12 20.5Z"
                      fill="#F5FAFF"
                    />
                  </g>
                </svg>
              </div>
            }
          />

          {/* <WithTooltip
            delayDuration={200}
            display={<div>Start a new chat</div>}
            trigger={
              <div className="mt-1">
                <IconMessagePlus
                  className="cursor-pointer hover:opacity-50"
                  size={24}
                  onClick={handleNewChat}
                />
              </div>
            }
          /> */}
        </>
      )}

      {/* TODO */}
      {/* <ShareMenu item={selectedChat} contentType="chats" /> */}
    </>
  );
};
