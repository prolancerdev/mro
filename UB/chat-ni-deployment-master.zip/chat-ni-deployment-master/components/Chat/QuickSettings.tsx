import { IconChevronDown, IconRobotFace } from '@tabler/icons-react';
import { FC, useContext, useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';

import Image from 'next/image';

import useHotkey from '@/lib/hooks/use-hotkey';

import styles from '../../styles/componentStyles/secondary.module.css';
import { ModelIcon } from '../models/ModelIcon';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from '../ui/DropdownMenu';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { QuickSettingOption } from './QuickSettingOption';

import { ChatbotUIContext } from '@/context/context';
import { getAssistantCollectionsByAssistantId } from '@/db/assistant-collections';
import { getAssistantFilesByAssistantId } from '@/db/assistant-files';
import { getAssistantToolsByAssistantId } from '@/db/assistant-tools';
import { getCollectionFilesByCollectionId } from '@/db/collection-files';
import { Tables } from '@/supabase/types';
import { LLMID } from '@/types';

interface QuickSettingsProps {}

export const QuickSettings: FC<QuickSettingsProps> = ({}) => {
  const { t } = useTranslation();

  useHotkey('p', () => setIsOpen((prevState) => !prevState));

  const {
    presets,
    assistants,
    selectedAssistant,
    selectedPreset,
    chatSettings,
    setSelectedPreset,
    setSelectedAssistant,
    setChatSettings,
    assistantImages,
    setChatFiles,
    setSelectedTools,
    setShowFilesDisplay,
  } = useContext(ChatbotUIContext);

  const inputRef = useRef<HTMLInputElement>(null);

  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100); // FIX: hacky
    }
  }, [isOpen]);

  const handleSelectQuickSetting = async (
    item: Tables<'presets'> | Tables<'assistants'>,
    contentType: 'presets' | 'assistants',
  ) => {
    if (contentType === 'assistants') {
      setSelectedAssistant(item as Tables<'assistants'>);

      setLoading(true);

      let allFiles = [];

      const assistantFiles = (await getAssistantFilesByAssistantId(item.id))
        .files;
      allFiles = [...assistantFiles];
      const assistantCollections = (
        await getAssistantCollectionsByAssistantId(item.id)
      ).collections;
      for (const collection of assistantCollections) {
        const collectionFiles = (
          await getCollectionFilesByCollectionId(collection.id)
        ).files;
        allFiles = [...allFiles, ...collectionFiles];
      }
      const assistantTools = (await getAssistantToolsByAssistantId(item.id))
        .tools;
      //@ts-ignore
      setSelectedTools(assistantTools);
      setChatFiles(
        allFiles.map((file) => ({
          id: file.id,
          name: file.name,
          type: file.type,
          file: null,
        })),
      );

      if (allFiles.length > 0) setShowFilesDisplay(true);

      setLoading(false);

      setSelectedPreset(null);
    } else if (contentType === 'presets') {
      setSelectedPreset(item as Tables<'presets'>);
      setSelectedAssistant(null);
    }

    setChatSettings({
      model: item.model as LLMID,
      prompt: item.prompt,
      temperature: item.temperature,
      contextLength: item.context_length,
      includeProfileContext: item.include_profile_context,
      includeWorkspaceInstructions: item.include_workspace_instructions,
      embeddingsProvider: item.embeddings_provider as 'openai' | 'local',
    });
  };

  const checkIfModified = () => {
    if (!chatSettings) return false;

    if (selectedPreset) {
      if (
        selectedPreset.include_profile_context !==
          chatSettings.includeProfileContext ||
        selectedPreset.include_workspace_instructions !==
          chatSettings.includeWorkspaceInstructions ||
        selectedPreset.context_length !== chatSettings.contextLength ||
        selectedPreset.model !== chatSettings.model ||
        selectedPreset.prompt !== chatSettings.prompt ||
        selectedPreset.temperature !== chatSettings.temperature
      ) {
        return true;
      }
    } else if (selectedAssistant) {
      if (
        selectedAssistant.include_profile_context !==
          chatSettings.includeProfileContext ||
        selectedAssistant.include_workspace_instructions !==
          chatSettings.includeWorkspaceInstructions ||
        selectedAssistant.context_length !== chatSettings.contextLength ||
        selectedAssistant.model !== chatSettings.model ||
        selectedAssistant.prompt !== chatSettings.prompt ||
        selectedAssistant.temperature !== chatSettings.temperature
      ) {
        return true;
      }
    }

    return false;
  };

  const isModified = checkIfModified();

  const items = [
    ...presets.map((preset) => ({ ...preset, contentType: 'presets' })),
    ...assistants.map((assistant) => ({
      ...assistant,
      contentType: 'assistants',
    })),
  ];

  const selectedAssistantImage = selectedPreset
    ? ''
    : assistantImages.find(
        (image) => image.path === selectedAssistant?.image_path,
      )?.base64 || '';
  // temprory comment out
  return (
    <></>
    // <DropdownMenu
    //   open={isOpen}
    //   onOpenChange={(isOpen) => {
    //     setIsOpen(isOpen);
    //     setSearch('');
    //   }}
    // >
    //   <DropdownMenuTrigger asChild className="max-w-[400px]" disabled={loading}>
    //     <Button
    //       variant="ghost"
    //       className="flex space-x-3 text-lg"
    //       styleName={'mainContentQuickSettings'}
    //     >
    //       {selectedPreset && (
    //         <ModelIcon modelId={selectedPreset.model} width={32} height={32} />
    //       )}

    //       {selectedAssistant &&
    //         (selectedAssistantImage ? (
    //           <Image
    //             className="rounded"
    //             src={selectedAssistantImage}
    //             alt="Assistant"
    //             width={28}
    //             height={28}
    //           />
    //         ) : (
    //           <svg
    //             xmlns="http://www.w3.org/2000/svg"
    //             width="24"
    //             height="24"
    //             viewBox="0 0 24 24"
    //             fill="none"
    //           >
    //             <mask
    //               id="mask0_204_1803"
    //               style={{ maskType: 'alpha' }}
    //               maskUnits="userSpaceOnUse"
    //               x="0"
    //               y="0"
    //               width="24"
    //               height="24"
    //             >
    //               <rect width="24" height="24" fill="#D9D9D9" />
    //             </mask>
    //             <g mask="url(#mask0_204_1803)">
    //               <path
    //                 d="M5.85 17.1C6.7 16.45 7.65 15.9375 8.7 15.5625C9.75 15.1875 10.85 15 12 15C13.15 15 14.25 15.1875 15.3 15.5625C16.35 15.9375 17.3 16.45 18.15 17.1C18.7333 16.4167 19.1875 15.6417 19.5125 14.775C19.8375 13.9083 20 12.9833 20 12C20 9.78333 19.2208 7.89583 17.6625 6.3375C16.1042 4.77917 14.2167 4 12 4C9.78333 4 7.89583 4.77917 6.3375 6.3375C4.77917 7.89583 4 9.78333 4 12C4 12.9833 4.1625 13.9083 4.4875 14.775C4.8125 15.6417 5.26667 16.4167 5.85 17.1ZM12 13C11.0167 13 10.1875 12.6625 9.5125 11.9875C8.8375 11.3125 8.5 10.4833 8.5 9.5C8.5 8.51667 8.8375 7.6875 9.5125 7.0125C10.1875 6.3375 11.0167 6 12 6C12.9833 6 13.8125 6.3375 14.4875 7.0125C15.1625 7.6875 15.5 8.51667 15.5 9.5C15.5 10.4833 15.1625 11.3125 14.4875 11.9875C13.8125 12.6625 12.9833 13 12 13ZM12 22C10.6167 22 9.31667 21.7375 8.1 21.2125C6.88333 20.6875 5.825 19.975 4.925 19.075C4.025 18.175 3.3125 17.1167 2.7875 15.9C2.2625 14.6833 2 13.3833 2 12C2 10.6167 2.2625 9.31667 2.7875 8.1C3.3125 6.88333 4.025 5.825 4.925 4.925C5.825 4.025 6.88333 3.3125 8.1 2.7875C9.31667 2.2625 10.6167 2 12 2C13.3833 2 14.6833 2.2625 15.9 2.7875C17.1167 3.3125 18.175 4.025 19.075 4.925C19.975 5.825 20.6875 6.88333 21.2125 8.1C21.7375 9.31667 22 10.6167 22 12C22 13.3833 21.7375 14.6833 21.2125 15.9C20.6875 17.1167 19.975 18.175 19.075 19.075C18.175 19.975 17.1167 20.6875 15.9 21.2125C14.6833 21.7375 13.3833 22 12 22ZM12 20C12.8833 20 13.7167 19.8708 14.5 19.6125C15.2833 19.3542 16 18.9833 16.65 18.5C16 18.0167 15.2833 17.6458 14.5 17.3875C13.7167 17.1292 12.8833 17 12 17C11.1167 17 10.2833 17.1292 9.5 17.3875C8.71667 17.6458 8 18.0167 7.35 18.5C8 18.9833 8.71667 19.3542 9.5 19.6125C10.2833 19.8708 11.1167 20 12 20ZM12 11C12.4333 11 12.7917 10.8583 13.075 10.575C13.3583 10.2917 13.5 9.93333 13.5 9.5C13.5 9.06667 13.3583 8.70833 13.075 8.425C12.7917 8.14167 12.4333 8 12 8C11.5667 8 11.2083 8.14167 10.925 8.425C10.6417 8.70833 10.5 9.06667 10.5 9.5C10.5 9.93333 10.6417 10.2917 10.925 10.575C11.2083 10.8583 11.5667 11 12 11Z"
    //                 fill="#F5FAFF"
    //               />
    //             </g>
    //           </svg>
    //         ))}

    //       {loading ? (
    //         <div className="animate-pulse">Loading assistant...</div>
    //       ) : (
    //         <>
    //           <div className={`overflow-hidden text-ellipsis `}>
    //             {isModified &&
    //               (selectedPreset || selectedAssistant) &&
    //               'Modified '}

    //             {selectedPreset?.name ||
    //               selectedAssistant?.name ||
    //               t('Quick Settings')}
    //           </div>

    //           <svg
    //             xmlns="http://www.w3.org/2000/svg"
    //             width="16"
    //             height="16"
    //             viewBox="0 0 16 17"
    //             fill="none"
    //           >
    //             <mask
    //               id="mask0_228_269"
    //               mask-type="alpha"
    //               maskUnits="userSpaceOnUse"
    //               x="0"
    //               y="0"
    //               width="16"
    //               height="17"
    //             >
    //               <rect
    //                 x="16"
    //                 y="0.5"
    //                 width="16"
    //                 height="16"
    //                 transform="rotate(90 16 0.5)"
    //                 fill="#D9D9D9"
    //               />
    //             </mask>
    //             <g mask="url(#mask0_228_269)">
    //               <path
    //                 d="M1.92496 6.44166C1.59819 6.11489 1.59819 5.5851 1.92496 5.25833C2.25173 4.93156 2.78152 4.93156 3.10829 5.25833L7.99996 10.15L12.8916 5.25833C13.2184 4.93156 13.7482 4.93156 14.075 5.25833C14.4017 5.5851 14.4017 6.1149 14.075 6.44166L8.9192 11.5974C8.41152 12.1051 7.5884 12.1051 7.08072 11.5974L1.92496 6.44166Z"
    //                 fill="#F5FAFF"
    //               />
    //             </g>
    //           </svg>
    //         </>
    //       )}
    //     </Button>
    //   </DropdownMenuTrigger>

    //   <DropdownMenuContent className={`${styles.smoke}`} align="start">
    //     {presets.length === 0 && assistants.length === 0 ? (
    //       <div className="p-8 text-center">No items found.</div>
    //     ) : (
    //       <>
    //         <Input
    //           ref={inputRef}
    //           className="w-full"
    //           placeholder="Search..."
    //           value={search}
    //           onChange={(e) => setSearch(e.target.value)}
    //           onKeyDown={(e) => e.stopPropagation()}
    //         />

    //         {!!(selectedPreset || selectedAssistant) && (
    //           <QuickSettingOption
    //             contentType={selectedPreset ? 'presets' : 'assistants'}
    //             isSelected={true}
    //             item={
    //               selectedPreset ||
    //               (selectedAssistant as
    //                 | Tables<'presets'>
    //                 | Tables<'assistants'>)
    //             }
    //             onSelect={() => {
    //               setSelectedPreset(null);
    //               setSelectedAssistant(null);
    //             }}
    //             image={selectedPreset ? '' : selectedAssistantImage}
    //           />
    //         )}

    //         {items
    //           .filter(
    //             (item) =>
    //               item.name.toLowerCase().includes(search.toLowerCase()) &&
    //               item.id !== selectedPreset?.id &&
    //               item.id !== selectedAssistant?.id,
    //           )
    //           .map(({ contentType, ...item }) => (
    //             <QuickSettingOption
    //               key={item.id}
    //               contentType={contentType as 'presets' | 'assistants'}
    //               isSelected={false}
    //               item={item}
    //               onSelect={() =>
    //                 handleSelectQuickSetting(
    //                   item,
    //                   contentType as 'presets' | 'assistants',
    //                 )
    //               }
    //               image={
    //                 contentType === 'assistants'
    //                   ? assistantImages.find(
    //                       (image) =>
    //                         image.path ===
    //                         (item as Tables<'assistants'>).image_path,
    //                     )?.base64 || ''
    //                   : ''
    //               }
    //             />
    //           ))}
    //       </>
    //     )}
    //   </DropdownMenuContent>
    // </DropdownMenu>
  );
};
