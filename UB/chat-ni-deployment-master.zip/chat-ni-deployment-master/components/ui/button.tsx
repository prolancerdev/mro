import { Slot } from '@radix-ui/react-slot';
import * as React from 'react';

import styles from '../../styles/componentStyles/secondary.module.css';

import { cn } from '@/lib/utils';
import { type VariantProps, cva } from 'class-variance-authority';

const buttonVariants = cva(
  'ring-offset-background focus-visible:ring-ring inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors  focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50',
  {
    variants: {
      variant: {
        default: 'bg-primary text-primary-foreground ',
        destructive: 'bg-destructive text-destructive-foreground ',
        outline: 'border-input bg-background ',
        secondary: 'bg-secondary text-secondary-foreground',
        ghost: '',
        link: 'text-primary underline-offset-4 ',
      },
      size: {
        default: 'h-10 px-4 py-2',
        sm: 'h-9 rounded-md px-3',
        lg: 'h-11 rounded-md px-8',
        icon: 'size-10',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  styleName?: keyof typeof styles; // This prop will be used to apply the style
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    { className, variant, size, asChild = false, styleName, ...props }, // Destructure styleName from props
    ref,
  ) => {
    const Comp = asChild ? Slot : 'button';
    const dynamicStyle = styles[styleName ?? 'defaultButtonStyle']; // Use nullish coalescing to default to 'defaultButtonStyle' if styleName is not provided
    return (
      <Comp
        className={`${cn(buttonVariants({ variant, size }), dynamicStyle, className)}`} // Apply dynamicStyle here
        ref={ref}
        {...props}
      />
    );
  },
);
Button.displayName = 'Button';

export { Button, buttonVariants };
