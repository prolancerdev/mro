'use client';

import { IconChevronCompactRight } from '@tabler/icons-react';
import { FC, useEffect, useState } from 'react';

import { usePathname, useRouter, useSearchParams } from 'next/navigation';

import useHotkey from '@/lib/hooks/use-hotkey';

import Sidebar from '@/components/Sidebar/Sidebar';
import { SidebarSwitcher } from '@/components/Sidebar/SidebarSwitcher';
import { Button } from '@/components/ui/button';
import { Tabs } from '@/components/ui/tabs';

import styles from '../../styles/componentStyles/secondary.module.css';
import { useSelectFileHandler } from '../Chat/chat-hooks/UseSelectFileHandler';
import ContentHeader from '../ContentHeader/ContentHeader';
import { CommandK } from '../utility/command-k';

import { cn } from '@/lib/utils';
import { ContentType } from '@/types';

export const SIDEBAR_WIDTH = 350;

interface DashboardProps {
  children: React.ReactNode;
}

export const Dashboard: FC<DashboardProps> = ({ children }) => {
  useHotkey('s', () => setShowSidebar((prevState) => !prevState));

  const pathname = usePathname();
  const router = useRouter();
  const searchParams = useSearchParams(); //@ts-ignore
  const tabValue = searchParams.get('tab') || 'chats';

  const { handleSelectDeviceFile } = useSelectFileHandler();

  const [contentType, setContentType] = useState<ContentType>(
    tabValue as ContentType,
  );
  const [showSidebar, setShowSidebar] = useState(
    localStorage.getItem('showSidebar') === 'true',
  );
  const [isDragging, setIsDragging] = useState(false);

  const onFileDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();

    const files = event.dataTransfer.files;
    const file = files[0];

    handleSelectDeviceFile(file);

    setIsDragging(false);
  };

  const handleDragEnter = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(false);
  };

  const onDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  };

  const handleToggleSidebar = () => {
    setShowSidebar((prevState) => !prevState);
    localStorage.setItem('showSidebar', String(!showSidebar));
  };

  return (
    <>
      <ContentHeader handleToggleSidebar={() => setShowSidebar(!showSidebar)} />
      <div
        className={`${styles.dashboardContainer} ${styles.dashboardLeftSideBarBackground}`}
      >
        <CommandK />
        <div
          className={`${styles.sidebar} ${showSidebar ? styles.showSidebar : styles.hideSidebar}`}
          style={{
            transition: 'width ease-in-out',
          }}
        >
          <Tabs
            className="flex h-full"
            value={contentType}
            onValueChange={(tabValue) => {
              setContentType(tabValue as ContentType);
              router.replace(`${pathname}?tab=${tabValue}`);
            }}
          >
            <SidebarSwitcher onContentTypeChange={setContentType} />
            <Sidebar contentType={contentType} showSidebar={showSidebar} />
          </Tabs>
        </div>
        <div
          className={`${styles.mainContent} ${showSidebar ? '' : styles.mainContentExpanded}`}
        >
          {/* Main content logic and rendering */}
          {children}
        </div>
      </div>
    </>
  );
  return (
    <>
      <ContentHeader handleToggleSidebar={handleToggleSidebar} />
      <div
        className={`flex size-full rounded-lg  border-mint p-4 ${styles.dashboardLeftSideBarBackground}`}
      >
        <CommandK />

        {/* <Button
        className={cn(
          'absolute left-[4px] top-[50%] z-10 size-[32px] cursor-pointer',
        )}
        style={{
          marginLeft: showSidebar ? `${SIDEBAR_WIDTH}px` : '0px',
          transform: showSidebar ? 'rotate(180deg)' : 'rotate(0deg)',
        }}
        variant="ghost"
        size="icon"
        onClick={handleToggleSidebar}
      >
        <IconChevronCompactRight size={24} />
      </Button> */}

        <div
          className={cn('border-r-2 duration-200 dark:border-none')}
          style={{
            // Sidebar
            minWidth: showSidebar ? `${SIDEBAR_WIDTH}px` : '0px',
            maxWidth: showSidebar ? `${SIDEBAR_WIDTH}px` : '0px',
            width: showSidebar ? `${SIDEBAR_WIDTH}px` : '0px',
          }}
        >
          {showSidebar && (
            <Tabs
              className="flex h-full"
              value={contentType}
              onValueChange={(tabValue) => {
                setContentType(tabValue as ContentType);
                router.replace(`${pathname}?tab=${tabValue}`);
              }}
            >
              <SidebarSwitcher onContentTypeChange={setContentType} />

              <Sidebar contentType={contentType} showSidebar={showSidebar} />
            </Tabs>
          )}
        </div>

        <div
          className="bg-muted/50 flex grow flex-col"
          onDrop={onFileDrop}
          onDragOver={onDragOver}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
        >
          {isDragging ? (
            <div className="flex h-full items-center justify-center bg-black/50 text-2xl text-white">
              drop file here
            </div>
          ) : (
            <>
              {/* <div>
            <ContentHeader />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', flex: '1', overflow: "auto" }}>
            <div style={{ flex: '1' }}>
              {children}
            </div>
          </div> */}
              {children}
            </>
          )}
        </div>
      </div>
    </>
  );
};
