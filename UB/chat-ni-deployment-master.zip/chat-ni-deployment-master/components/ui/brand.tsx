// 'use client';
// import { FC } from 'react';
// import Link from 'next/link';
// import brandStyle from "../../styles/OnBoardingStyles/BrandStyle.module.css"
// import { ChatbotUISVG } from '../icons/chatbotui-svg';
// interface BrandProps {
//   theme?: 'dark' | 'light';
// }
// export const Brand: FC<BrandProps> = ({ theme = 'dark' }) => {
//   return (
//     // <Link
//     //   className="flex cursor-pointer flex-col items-center hover:opacity-50"
//     //   href="#"
//     //   onClick={(e) => e.preventDefault()}
//     //   // target="_blank"
//     //   // rel="noopener noreferrer"
//     // >
//     <div
//       className="flex-col items-center"
//       style={{
//         justifyContent: 'center',
//         display: 'flex',
//         alignItems: 'center',
//         flexDirection: 'row',
//         width: "427px",
//         marginBottom: "2rem"
//       }}
//     >
//       <div style={{width: "2.8rem",height: "3.8rem", marginRight: "1rem"}}>
//         <ChatbotUISVG theme={theme === 'dark' ? 'dark' : 'light'} scale={0.3} />
//       </div>
//       <div className={brandStyle.chatNI}>ChatNI</div>
//     </div>
//     // </Link>
//   );
// };
import { FC } from 'react';

import brandStyle from '../../styles/OnBoardingStyles/BrandStyle.module.css';
import { ChatbotUISVG } from '../icons/chatbotui-svg';

import styled from 'styled-components';

interface BrandProps {
  theme?: 'dark' | 'light';
}

const ResponsiveBrandContainer = styled.div<{ theme: 'dark' | 'light' }>`
  margin-bottom: 1.5rem;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;

  // Example media query for screens smaller than 768px
  @media (max-width: 768px) {
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }
`;

export const Brand: FC<BrandProps> = ({ theme = 'dark' }) => {
  const svgSize =
    theme === 'dark'
      ? { width: '64', height: '64' }
      : { width: '48', height: '48' };

  return (
    <ResponsiveBrandContainer theme={theme} style={{ maxWidth: '450px' }}>
      <div style={{ marginRight: '0.7rem' }}>
        <ChatbotUISVG theme={'dark'} {...svgSize} />
        {/* If you're using the inline SVG code, replace the width and height here as well */}
        {/* <svg
          xmlns="http://www.w3.org/2000/svg"
          {...svgSize}
          viewBox="0 0 35 47"
          fill="none"
        >
          // SVG paths
        </svg> */}
      </div>
      <div className={brandStyle.chatNI}>ChatNI</div>
    </ResponsiveBrandContainer>
  );
};
