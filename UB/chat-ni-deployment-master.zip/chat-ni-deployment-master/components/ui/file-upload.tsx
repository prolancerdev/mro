import * as React from 'react';

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {}

const FileUpload = React.forwardRef<HTMLInputElement, InputProps>(
  (props, ref) => {
    // State to manage the display text based on file selection
    const [fileLabel, setFileLabel] = React.useState('Select an image');

    // Event handler for file selection
    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      // Get the file name from the event
      const file = event.target.files?.[0];
      // Update the label to show the file name if a file is selected
      setFileLabel(file ? 'Select a different image' : 'Select an image');
    };

    // Reference to the hidden file input
    const fileInputRef = React.useRef<HTMLInputElement>(null);

    // Function to trigger file input when the button is clicked
    const triggerFileInput = () => {
      fileInputRef.current?.click();
    };

    return (
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-start',
          height: 'auto',
          padding: '0rem',
          marginTop: '1rem',
        }}
      >
        {/* Button to trigger file selection */}
        <button
          onClick={triggerFileInput}
          style={{
            backgroundColor: '#28282F',
            padding: '8px',
            borderRadius: '8px',
            cursor: 'pointer',
            border: 'none',
            marginRight: '1rem',
          }}
        >
          {/* Select an Image */}
          {fileLabel != 'Select an image'
            ? fileLabel
            : 'Select a different image'}
        </button>

        {/* File name label */}
        <span
          style={{
            // marginRight: '10px',
            color:
              fileLabel !== 'Select a different image' ? '#A5A5B3' : '#A5A5B3', // Change color if file is chosen
            userSelect: 'none', // Prevent text selection
          }}
        >
          {/* {fileLabel !== 'Select a different image' ? fileLabel : 'Select an image'} */}
        </span>

        {/* Hidden file input */}
        <input
          type="file"
          onChange={handleFileChange}
          ref={fileInputRef} // Assign the ref here
          style={{ display: 'none' }} // Keep the input hidden
          {...props}
        />
      </div>
    );
  },
);

FileUpload.displayName = 'FileUpload';

export { FileUpload };
