import React from 'react';
import { LiaCopyright } from 'react-icons/lia';

import LegalFooterStyles from '../../styles/OnBoardingStyles/LegalFooter.module.css';

interface LegalFooterProps {}
const LegalFooter: React.FC<LegalFooterProps> = () => {
  return (
    <>
      <div className={LegalFooterStyles.legalSectionFooter}>
        <div className={LegalFooterStyles.line3}></div>
        <div className={LegalFooterStyles.frame172}>
          <div className={LegalFooterStyles.footerText}>
            <span className={LegalFooterStyles.footerText7}>
              Terms of Service
            </span>
          </div>
          <div className={LegalFooterStyles.ellipse83}></div>
          <div className={LegalFooterStyles.footerText8}>
            <span className={LegalFooterStyles.footerText7}>
              Legal Disclaimer
            </span>
          </div>
          <div className={LegalFooterStyles.ellipse94}></div>
          <div className={LegalFooterStyles.footerText10}>
            <span className={LegalFooterStyles.footerText11}>
              Privacy Notice
            </span>
          </div>
          <div className={LegalFooterStyles.ellipse105}></div>
          <div className={LegalFooterStyles.frame133}>
            <div className={LegalFooterStyles.copyrightSymbolSvgrepoCom1}>
              <svg
                width="13"
                height="13"
                viewBox="0 0 13 13"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M6.49989 0.50061C3.19174 0.50061 0.5 3.19101 0.5 6.50001C0.5 9.8077 3.19174 12.4994 6.49989 12.4994C9.80843 12.4994 12.5 9.8077 12.5 6.50001C12.5 3.19101 9.80843 0.50061 6.49989 0.50061ZM6.49989 11.1628C3.92845 11.1628 1.83668 9.07111 1.83668 6.50004C1.83668 3.92786 3.92845 1.83621 6.49989 1.83621C9.07161 1.83621 11.1634 3.92789 11.1634 6.50004C11.1634 9.07111 9.07158 11.1628 6.49989 11.1628Z"
                  fill="#A5A5B3"
                />
                <path
                  d="M8.46926 7.58687C8.08598 8.24459 7.37326 8.65259 6.60931 8.65259C5.42295 8.65259 4.45659 7.68647 4.45659 6.50007C4.45659 5.3127 5.42295 4.34625 6.60931 4.34625C7.3733 4.34625 8.08598 4.75575 8.46926 5.41217L8.5188 5.49796H9.96481L9.87801 5.26515C9.6264 4.59855 9.18489 4.03177 8.60044 3.62723C8.01453 3.22164 7.32631 3.00647 6.60931 3.00647C4.68323 3.00647 3.11688 4.57415 3.11688 6.50007C3.11688 8.42612 4.68323 9.99234 6.60931 9.99234C7.32631 9.99234 8.0145 9.77789 8.60044 9.37168C9.18489 8.96704 9.6264 8.40046 9.87801 7.73385L9.96481 7.50091H8.5188L8.46926 7.58687Z"
                  fill="#A5A5B3"
                />
              </svg>

              {/* <LiaCopyright /> */}
              {/* <img className={LegalFooterStyles.group} /> */}
            </div>
            <span className={LegalFooterStyles.neuralInternet}>
              2023 Neural Internet
            </span>
          </div>
        </div>
      </div>
    </>
  );
};

export default LegalFooter;
