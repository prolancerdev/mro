const withBundleAnalyzer = require("@next/bundle-analyzer")({
  enabled: process.env.ANALYZE === "true"
})

/** @type {import('next').NextConfig} */
module.exports = withBundleAnalyzer({
  reactStrictMode: false,
  images: {
    remotePatterns: [
      {
        protocol: "http",
        hostname: "localhost"
      },
      {
        protocol: "http",
        hostname: "127.0.0.1"
      },
      {
        protocol: "https",
        hostname: "**"
      }
    ]
  },
  experimental: {
    serverComponentsExternalPackages: ["sharp", "onnxruntime-node"]
  }
})
// const withBundleAnalyzer = require('@next/bundle-analyzer')({
//   enabled: process.env.ANALYZE === 'true',
// });
// const withTM = require('next-transpile-modules')([
//   'react-syntax-highlighter',
//   // Add any other packages that need to be transpiled
// ]);

// module.exports = withTM(withBundleAnalyzer({
//   reactStrictMode: true,
//   images: {
//     // Specify your image configuration here
//     remotePatterns: [
//       {
//         protocol: 'http',
//         hostname: 'localhost',
//       },
//       {
//         protocol: 'http',
//         hostname: '127.0.0.1',
//       },
//       {
//         protocol: 'https',
//         hostname: '**',
//       },
//     ],
//   },
//   webpack: (config, { isServer }) => {
//     // Using null-loader to ignore .node files
//     config.module.rules.push({
//       test: /\.node$/,
//       use: 'null-loader',
//     });

//     if (!isServer) {
//       // Fixes npm packages that depend on `fs` module
//       config.resolve.fallback.fs = false;
//     }
//     config.module.rules.push({
//       test: /\.css$/,
//       use: ['style-loader', 'css-loader'],
//     });
//     return config;
//   },
//   experimental: {
//     serverComponentsExternalPackages: ['sharp', 'onnxruntime-node'],
//   },
//   // Add other configurations as needed
// }));

