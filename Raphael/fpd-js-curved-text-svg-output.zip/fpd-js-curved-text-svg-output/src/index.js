import './ui/less/main.less';
import './classes/FancyProductDesigner.js';