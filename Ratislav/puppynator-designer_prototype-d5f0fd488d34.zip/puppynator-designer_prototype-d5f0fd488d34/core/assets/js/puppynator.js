const puppynator = {};

puppynator.transformImageSvgSrc = function (stage, img, defaultColor = null) {
    let ext = $(img).attr('src').split('.').pop();

    if ('svg' === ext)
    {
        let serializer = new XMLSerializer();
        let svg, svgStr;

        let key = '#ffffff';

        if (stage.svgPathsColors === undefined || stage.svgPathsColors.length === 0) {
            return img;
        }

        $.ajax({
            url: $(img).attr('src'),
            method: 'get',
            async: false,
            success: (svgLoaded) => {

                svg = svgLoaded;

                let color = defaultColor ?? 'transparent';

                svg = recolorSvgByPaths(stage, svg, defaultColor);

                svgStr = serializer.serializeToString(svg);

                $(img).attr('src', 'data:image/svg+xml;base64,' + btoa(svgStr));

            }
        });
    }

    return img;
}

puppynator.updateSvgPathColors = function (stage, imgElement, color)
{
    let serializer = new XMLSerializer();

    let imgElementSrc = $(imgElement).attr('src');
    let svgSource = imgElementSrc.split('base64,')[1];
    if (svgSource !== undefined)
    {
        let svgStr = atob(svgSource);
        let svg = null;

        $.each($(svgStr), function (i, v) {
            if (v instanceof SVGElement) {
                svg = v;
                return false;
            }
        });

        if (null === svg) {
            return false;
        }

        svg = recolorSvgByPaths(stage, svg,  color);

        svgStr = serializer.serializeToString(svg);

        let imgElm = new Image();
        imgElm.src = 'data:image/svg+xml;base64,' + btoa(svgStr);

        let src = 'data:image/svg+xml;base64,' + btoa(svgStr);

        return src;
    }
}

let recolorSvgByPaths = function (stage, svg, colorToChange) {
    $.each(stage.svgPathsColors, function (mainColorValue, pathsColors) {

        if (colorToChange === mainColorValue) {
            $.each(pathsColors, function (pathId, pathColor) {
                if (pathColor.length > 5) {
                    let path = $(svg).find('#' + pathId);
                    if (undefined !== path) {
                        $(path).css({fill: pathColor});
                    }
                }
            });
        }
    });

    return svg;
}
