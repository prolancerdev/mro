<?php
/**
*
*	(p) package: shoptefy pdf.php
*	(c) author:	King-Theme
*	(i) website: https://www.shoptefy.com
*
*/	

global $shoptefy;

echo 434334;
