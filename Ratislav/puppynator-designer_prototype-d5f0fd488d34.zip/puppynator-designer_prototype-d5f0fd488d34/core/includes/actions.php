<?php
/**
*	
*	(p) package: shoptefy
*	(c) author:	King-Theme
*	(i) website: https://www.shoptefy.com
*
*/

if (!defined('shoptefy')) {
	header('HTTP/1.0 403 Forbidden');
	die();
}

global $shoptefy;

$shoptefy->add_action('editor-header', 'shoptefy_editor_header');

function shoptefy_editor_header() {
	
	global $shoptefy, $shoptefy_admin;
	
	if (isset($shoptefy_admin)) {
		
		$check_update = @json_decode($shoptefy->get_option('last_check_update'));
		
		if (!isset($check_update) || time()-$check_update->time > 60*60*24) {
			echo '<script>window.addEventListener("load", function(){jQuery.get("'.$shoptefy->cfg->ajax_url.'&action=check-update")});</script>';
		}
		
		return;
		
	}
	
	$url = $shoptefy->cfg->tool_url;
	$purl = parse_url($url);
	$img = $shoptefy->cfg->settings['logo'];
	$title = $shoptefy->lang($shoptefy->cfg->settings['title']);
	
	if (isset($_GET['share'])) {
		$share = $shoptefy->lib->get_share($_GET['share']);
		if ($share !== null) {
			$title = $share['name'];
			$url = str_replace('?&', '?' ,$url.(strpos($url, '?') === false ? '?' : '&').'product_base='.$share['product'].'&product_cms='.$share['product_cms'].'&share='.$share['share_id']);
			$img = $shoptefy->cfg->upload_url.'shares/'.date('Y/m/', strtotime($share['created'])).$share['share_id'].'.jpg';
		}
	}
	
	echo '		<meta name="description" content="'.$shoptefy->lang('The online product designer tool').'" />'."\n";
	echo '		<meta property="og:title" content="'.$title.'" />'."\n";
	echo '		<meta property="og:type" content="website" />'."\n";
	echo '		<meta property="og:url" content="'.$url.'" />'."\n";
	echo '		<meta property="og:image" content="'.$img.'" />'."\n";
	echo '		<meta property="og:description" content="'.$shoptefy->lang('The online product designer tool').'" />'."\n";
	echo '		<meta property="og:site_name" content="'.ucfirst($purl['host']).'" />'."\n";
	
	if ($shoptefy->cfg->settings['rtl'] == '1') {
		echo '		<link rel="stylesheet" href="'.$shoptefy->cfg->assets_url.'/assets/css/rtl.css">'."\n";
	}
	
	$favicon = $shoptefy->cfg->settings['favicon'];
	
	if (isset($favicon) && !empty($favicon)) {
		if (strpos($favicon, 'http') === false)
			$favicon = $shoptefy->cfg->upload_url.$favicon;
		echo '		<link rel="icon" type="image/x-icon" href="'.$favicon.'" />'."\n";
		echo '		<link rel="shortcut icon" type="image/x-icon" href="'.$favicon.'" />'."\n";
	}
	
	echo "\n";
	
}
