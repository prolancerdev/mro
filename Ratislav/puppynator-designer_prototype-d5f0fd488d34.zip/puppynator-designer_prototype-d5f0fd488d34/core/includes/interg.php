<?php
	
function shoptefy_cms_product_data_fields($ops, $js_cfg, $id) {
    
    global $shoptefy;
    
    $product = isset($ops['shoptefy_product_base']) ? $ops['shoptefy_product_base'] : '';
    $design = isset($ops['shoptefy_design_template']) ? $ops['shoptefy_design_template'] : '';
    $customize = isset($ops['shoptefy_customize']) ? $ops['shoptefy_customize'] : '';
    $addcart = isset($ops['shoptefy_disable_add_cart']) ? $ops['shoptefy_disable_add_cart'] : '';

    ?>
	<link rel="stylesheet" href="<?php echo $shoptefy->cfg->assets_url; ?>admin/assets/css/interg.css?version=<?php echo shoptefy; ?>" type="text/css" media="all" />
    <div id="shoptefy_product_data" class="panel woocommerce_options_panel">
        <p class="form-field shoptefy_customize_field options_group hidden" id="shoptefy-enable-customize">
			<label for="shoptefy_customize">
				<strong><?php echo $shoptefy->lang('Hide cart button'); ?>:</strong>
			</label>
			<span class="shoptefy-toggle">
				<input type="checkbox" name="shoptefy_disable_add_cart"  <?php
				if ($addcart == 'yes')echo 'checked';
			?> id="shoptefy_customize" value="yes" />
				<span class="shoptefy-toggle-label" data-on="Yes" data-off="No"></span>
				<span class="shoptefy-toggle-handle"></span>
			</span>
			<span style="float: left;margin-left: 10px;">
				<?php echo $shoptefy->lang('Hide the Add To Cart button in product details page'); ?>
			</span>
		</p>
		<p class="form-field shoptefy_customize_field options_group hidden" id="shoptefy-enable-customize">
			<label for="shoptefy_customize">
				<strong><?php echo $shoptefy->lang('Allow customize'); ?>:</strong>
			</label>
			<span class="shoptefy-toggle">
				<input type="checkbox" name="shoptefy_customize"  <?php
				if ($customize != 'no')echo 'checked';
			?> id="shoptefy_customize" value="yes" />
				<span class="shoptefy-toggle-label" data-on="Yes" data-off="No"></span>
				<span class="shoptefy-toggle-handle"></span>
			</span>
			<span style="float: left;margin-left: 10px;">
				<?php echo $shoptefy->lang('Users can change or customize the design before checkout.'); ?>
			</span>
		</p>
        <div id="shoptefy-product-base" class="options_group"></div>
        <p id="shoptefy-seclect-base">
	        <a href="#" class="shoptefy-button shoptefy-button-primary shoptefy-button-large" data-func="products">
		        <i class="fa fa-cubes"></i>
		        <?php echo $shoptefy->lang('Select product base'); ?>
		    </a>
		    &nbsp;
		    <a href="#" title="<?php echo $shoptefy->lang('Remove product base'); ?>" class="shoptefy-button shoptefy-button-link-delete shoptefy-button-large hidden" data-func="remove-base-product">
		        <i class="fa fa-trash"></i>
		        <?php echo $shoptefy->lang('Remove product'); ?>
		    </a>
        </p>
        <?php $shoptefy->do_action( 'product-shoptefy-option-tab' ); ?>
        <input type="hidden" value="<?php echo $product; ?>" name="shoptefy_product_base" id="shoptefy_product_base" />
        <input type="hidden" value="<?php echo $design; ?>" name="shoptefy_design_template" id="shoptefy_design_template" />
    </div>
<?php 
	
	$js_cfg = array_merge(array(
		'nonce_backend' => shoptefy_secure::create_nonce('shoptefy-SECURITY-BACKEND'),
		'ajax_url' => $shoptefy->cfg->ajax_url,
		'admin_ajax_url' => $shoptefy->cfg->admin_ajax_url,
		'is_admin' => is_admin(),
		'admin_url' => $shoptefy->cfg->admin_url,
		'assets_url' => $shoptefy->cfg->assets_url,
		'upload_url' => $shoptefy->cfg->upload_url,
		'inline_edit' => (isset($ops['inline_edit']) ? $ops['inline_edit'] : true),
		'current_product' => (isset($id) && !empty($id) ? $id : 0),
		'color' => explode(':', ($shoptefy->cfg->settings['colors'] ? $shoptefy->cfg->settings['colors'] : ''))[0],
		'_i42' => $shoptefy->lang('No items found'),
    	'_i62' => $shoptefy->lang('Products'),
    	'_i64' => $shoptefy->lang('Select product'),
    	'_i63' => $shoptefy->lang('Search product'),
    	'_i56' => $shoptefy->lang('Categories'),
    	'_i57' => $shoptefy->lang('All categories'),
    	'_i58' => $shoptefy->lang('Select template'),
    	'_i59' => $shoptefy->lang('Create new'),
    	'_i60' => $shoptefy->lang('Stages'),
    	'_i61' => $shoptefy->lang('Edit Product Base'),
		'_i65' => $shoptefy->lang('Start Over'),
    	'_i66' => $shoptefy->lang('Design templates'),
    	'_i67' => $shoptefy->lang('Search design templates'),
    	'_i68' => $shoptefy->lang('Load more'),
    	'_i69' => $shoptefy->lang('Clear design template'),
    	'_i70' => $shoptefy->lang('Clear'),
    	'_i71' => $shoptefy->lang('You need to choose a product base to enable shoptefy Editor for this product.'),
    	'_i72' => $shoptefy->lang('Download'),
    	'_i73' => $shoptefy->lang('Download design template'),
    	'_front' => $shoptefy->lang($shoptefy->cfg->settings['label_stage_1']),
    	'_back' => $shoptefy->lang($shoptefy->cfg->settings['label_stage_2']),
    	'_left' => $shoptefy->lang($shoptefy->cfg->settings['label_stage_3']),
    	'_right' => $shoptefy->lang($shoptefy->cfg->settings['label_stage_4']),
	), $js_cfg);
	
	echo '<script type="text/javascript">';
	echo 'var shoptefyjs='.json_encode($js_cfg).';';
	echo '</script>';
	echo '<script type="text/javascript" src="'.$shoptefy->cfg->assets_url.'admin/assets/js/interg.js?version='.shoptefy.'"></script>';

}

