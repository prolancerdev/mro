<?php
	global $shoptefy;

	$section = 'shape';
	$fields = $shoptefy_admin->process_data(array(
		array(
			'type' => 'input',
			'name' => 'name',
			'label' => $shoptefy->lang('Name'),
			'required' => true
		),
		array(
			'type' => 'shape',
			'name' => 'content',
			'label' => $shoptefy->lang('Content'),
			'desc' => $shoptefy->lang('Only accept SVG under plain text')
		),
		array(
			'type' => 'input',
			'name' => 'order',
			'type_input' => 'number',
			'label' => $shoptefy->lang('Order'),
			'default' => 0,
			'desc' => $shoptefy->lang('Ordering of item with other.')
		),
		array(
			'type' => 'toggle',
			'name' => 'active',
			'label' => $shoptefy->lang('Active'),
			'default' => 'yes',
			'value' => null
		),
	), 'shapes');

?>

<div class="shoptefy_wrapper" id="shoptefy-<?php echo $section; ?>-page">
	<div class="shoptefy_content">
		<?php
			$shoptefy->views->detail_header(array(
				'add' => $shoptefy->lang('Add new shape'),
				'edit' => $fields[0]['value'],
				'page' => $section
			));
		?>
		<form action="<?php echo $shoptefy->cfg->admin_url; ?>shoptefy-page=<?php
			echo $section.(isset($_GET['callback']) ? '&callback='.$_GET['callback'] : '');
		?>" id="shoptefy-clipart-form" method="post" class="shoptefy_form" enctype="multipart/form-data">

			<?php $shoptefy->views->tabs_render($fields); ?>

			<div class="shoptefy_form_group shoptefy_form_submit">
				<input type="submit" class="shoptefy-button shoptefy-button-primary" value="<?php echo $shoptefy->lang('Save Shape'); ?>"/>
				<input type="hidden" name="do" value="action" />
				<a class="shoptefy_cancel" href="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=<?php echo $section; ?>s">
					<?php echo $shoptefy->lang('Cancel'); ?>
				</a>
				<input type="hidden" name="shoptefy-section" value="<?php echo $section; ?>">
			</div>
		</form>
	</div>
</div>
