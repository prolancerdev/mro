<?php

	$section = 'font';
	$fields = $shoptefy_admin->process_data(array(
		array(
			'type' => 'input',
			'name' => 'name',
			'label' => $shoptefy->lang('Name'),
			'required' => true,
			'desc' => $shoptefy->lang('The names must be latin letters'),
			'default' => 'Untitled'
		),
		array(
			'type' => 'input',
			'name' => 'name_desc',
			'label' => $shoptefy->lang('Name Desciption'),
			'required' => true,
			'desc' => $shoptefy->lang('Show on frontend(design editor), default will is name'),
			'default' => ''
		),
		array(
			'type' => 'upload',
			'name' => 'upload',
			'required' => true,
			'path' => 'fonts'.DS,
			'file' => 'font',
			'file_type' => 'woff2',
			'label' => $shoptefy->lang('Upload Font'),
			'desc' => $shoptefy->lang('You can convert your *.ttf to *.woff2 by a converter online tool').
					  ' <a href="https://font-converter.net/en" target="_blank"><strong>Font-Converter.net</strong></a>'
		),
		array(
			'type' => 'upload',
			'name' => 'upload_ttf',
			'path' => 'fonts'.DS,
			'file' => 'font',
			'file_type' => 'ttf',
			'label' => $shoptefy->lang('PDF render'),
			'desc' => $shoptefy->lang('Upload *.ttf file to render PDF (in case you want to export design to PDF for printing)')
		),
		array(
			'type' => 'toggle',
			'name' => 'active',
			'label' => $shoptefy->lang('Active'),
			'default' => 'yes',
			'value' => null
		),
	), 'fonts');

?>

<div class="shoptefy_wrapper" id="shoptefy-<?php echo $section; ?>-page">
	<div class="shoptefy_content">
		<?php
			$shoptefy->views->detail_header(array(
				'add' => $shoptefy->lang('Add new font'),
				'edit' => $fields[0]['value'],
				'page' => $section
			));
		?>
		<form action="<?php echo $shoptefy->cfg->admin_url; ?>shoptefy-page=<?php
			echo $section.(isset($_GET['callback']) ? '&callback='.$_GET['callback'] : '');
		?>" id="shoptefy-clipart-form" method="post" class="shoptefy_form" enctype="multipart/form-data">

			<?php $shoptefy->views->tabs_render($fields); ?>

			<div class="shoptefy_form_group shoptefy_form_submit">
				<input type="submit" class="shoptefy-button shoptefy-button-primary" value="<?php echo $shoptefy->lang('Save Font'); ?>"/>
				<input type="hidden" name="do" value="action" />
				<a class="shoptefy_cancel" href="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=<?php echo $section; ?>s">
					<?php echo $shoptefy->lang('Cancel'); ?>
				</a>
				<input type="hidden" name="shoptefy-section" value="<?php echo $section; ?>">
			</div>
		</form>
	</div>
</div>
