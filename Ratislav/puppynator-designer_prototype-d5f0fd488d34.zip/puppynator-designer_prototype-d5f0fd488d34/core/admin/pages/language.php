<?php

	$section = 'language';

	$langs = $shoptefy->get_langs();
	$lang_map = $shoptefy->langs();

	$options = array();

	foreach ($langs as $lang) {
		if (!isset($options[$lang]) && isset($lang_map[$lang]))
			$options[$lang] = $lang_map[$lang];
	}

	$fields = $shoptefy_admin->process_data(array(
		array(
			'type' => 'input',
			'name' => 'text',
			'label' => $shoptefy->lang('Translate Text'),
			'required' => true
		),
		array(
			'type' => 'input',
			'name' => 'original_text',
			'label' => $shoptefy->lang('Original text'),
			'required' => true
		),
		array(
			'type' => 'dropbox',
			'options' => $options,
			'name' => 'lang',
			'label' => $shoptefy->lang('Language'),
		),
	), 'languages');

?>

<div class="shoptefy_wrapper" id="shoptefy-<?php echo $section; ?>-page">
	<div class="shoptefy_content">
		<?php
			$shoptefy->views->detail_header(array(
				'add' => $shoptefy->lang('Add translate text'),
				'edit' => $shoptefy->lang('Edit translate text'),
				'page' => $section
			));
		?>
		<form action="<?php echo $shoptefy->cfg->admin_url; ?>shoptefy-page=<?php
			echo $section.(isset($_GET['callback']) ? '&callback='.$_GET['callback'] : '');
		?>" id="shoptefy-clipart-form" method="post" class="shoptefy_form" enctype="multipart/form-data">

			<?php $shoptefy->views->tabs_render($fields); ?>

			<div class="shoptefy_form_group shoptefy_form_submit">
				<input type="submit" class="shoptefy-button shoptefy-button-primary" value="<?php echo $shoptefy->lang('Save Translate Text'); ?>"/>
				<input type="hidden" name="do" value="action" />
				<a class="shoptefy_cancel" href="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=<?php echo $section; ?>s">
					<?php echo $shoptefy->lang('Cancel'); ?>
				</a>
				<input type="hidden" name="shoptefy-section" value="<?php echo $section; ?>">
			</div>
		</form>
	</div>
</div>

<?php

	return;
	$title = "Edit translate text";

	if (isset($_GET['id'])) {
		$data = $shoptefy_admin->get_row_id($_GET['id'], 'shoptefy_languages');
	}


	$langs = $shoptefy->get_langs();
	$lang_map = $shoptefy->langs();

	if (!empty($_POST['save_language'])) {

		$data = array();
		$data_id = isset($_POST['id']) ? trim($_POST['id']) : '';
		$data['text'] = isset($_POST['text']) ? trim($_POST['text']) : '';
		$data['original_text'] = isset($_POST['original_text']) ? trim($_POST['original_text']) : '';
		$data['lang'] = isset($_POST['lang']) ? trim($_POST['lang']) : '';
		$data_name = isset($_POST['name_temp']) ? $_POST['name_temp'] : '';
		$errors = array();

		if (empty($data['lang'])) {
			$errors['lang'] = $shoptefy->lang('Please select language.');
		}else if (empty($data['text'])) {
			$errors['text'] = $shoptefy->lang('Please insert translate text.');
		}else if (empty($data['original_text'])) {
			$errors['original_text'] = $shoptefy->lang('Please insert original text.');
		}else{
			$check_exist = $shoptefy->db->rawQuery("SELECT `id` FROM `{$shoptefy->db->prefix}languages` WHERE `author`='{$shoptefy->vendor_id}' AND `lang` = '".$data['lang']."' AND `original_text` = '".$data['original_text']."'");
			if (count($check_exist) > 0) {
				$errors['original_text'] = $shoptefy->lang('The original text provided already exists.');
			}

		}

		if (!empty($data_id)) {
			$data['updated'] = date("Y-m-d").' '.date("H:i:s");
		} else {
			$data['created'] = date("Y-m-d").' '.date("H:i:s");
		}

		if (count($errors) == 0) {

			if (!empty($data_id)) {
				$id = $shoptefy_admin->edit_row( $data_id, $data, 'shoptefy_languages' );
			} else {
				$id = $shoptefy_admin->add_row( $data, 'shoptefy_languages' );
			}
			$shoptefy_msg = array('status' => 'success');
			$shoptefy->connector->set_session('shoptefy_msg', $shoptefy_msg);

		} else {

			$shoptefy_msg = array('status' => 'error', 'errors' => $errors);
			$shoptefy->connector->set_session('shoptefy_msg', $shoptefy_msg);
			if (!empty($data_id)) {
				$shoptefy->redirect($shoptefy->cfg->admin_url . "shoptefy-page=language&id=".$data_id);
			} else {
				$shoptefy->redirect($shoptefy->cfg->admin_url . "shoptefy-page=language");
			}
			exit;

		}

		if (isset($id) && $id == true ) {
			$shoptefy->redirect($shoptefy->cfg->admin_url . "shoptefy-page=language&id=".$id);
			exit;
		}

	}else if (count($langs) !== 0) {
		$errors['text'] = $shoptefy->lang('No language added, Please add new language before adding translate text').
		' &nbsp; <a href="'.$shoptefy->cfg->admin_url .'shoptefy-page=languages">'.$shoptefy->lang('Languages').' <i class="fa fa-arrow-circle-right"></i></a>';
		$shoptefy_msg = array('status' => 'error', 'errors' => $errors);
		$shoptefy->connector->set_session('shoptefy_msg', $shoptefy_msg);
	}

?>

<div class="shoptefy_wrapper">
	<div class="shoptefy_content">
		<div class="shoptefy_header">
			<?php

				if (!empty($data['id'])) {
					echo '<h2>'.$shoptefy->lang('Edit Translate Text').'</h2><a href="'.$shoptefy->cfg->admin_url.'shoptefy-page=language" class="add-new shoptefy-button">'.$shoptefy->lang('Add New Language').'</a>';
				} else {
					echo '<h2>'.$shoptefy->lang('Add Translate Text').'</h2>';
				}
				$shoptefy_page = isset($_GET['shoptefy-page']) ? $_GET['shoptefy-page'] : '';
				echo $shoptefy_helper->breadcrumb($shoptefy_page);

			?>
		</div>
		<?php

			$shoptefy_msg = $shoptefy->connector->get_session('shoptefy_msg');
			if (isset($shoptefy_msg) && $shoptefy_msg['status'] == 'error') { ?>

				<div class="shoptefy_message err">

					<?php foreach ($shoptefy_msg['errors'] as $val) {
						echo '<em class="shoptefy_err"><i class="fa fa-times"></i>  ' . $val . '</em>';
						$shoptefy_msg = array('status' => '');
						$shoptefy->connector->set_session('shoptefy_msg', $shoptefy_msg);
					} ?>

				</div>

			<?php }

			if (isset($shoptefy_msg) && $shoptefy_msg['status'] == 'success') { ?>

				<div class="shoptefy_message">
					<?php
						echo '<em class="shoptefy_suc"><i class="fa fa-check"></i> '.$shoptefy->lang('Your data has been successfully saved').'</em>';
						$shoptefy_msg = array('status' => '');
						$shoptefy->connector->set_session('shoptefy_msg', $shoptefy_msg);
					?>
				</div>

			<?php }

		?>
		<form action="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=language" method="post" class="shoptefy_form">
			<div class="shoptefy_form_group">
				<span><?php echo $shoptefy->lang('Translate Text'); ?><em class="required">*</em></span>
				<div class="shoptefy_form_content">
					<input type="text" name="text" value="<?php echo !empty($data['text']) ? $data['text'] : '' ?>">
					<input type="hidden" name="name_temp" value="<?php echo !empty($data['text']) ? $data['text'] : '' ?>">
				</div>
			</div>
			<div class="shoptefy_form_group">
				<span><?php echo $shoptefy->lang('Original text'); ?><em class="required">*</em></span>
				<div class="shoptefy_form_content">
					<input type="text" name="original_text" value="<?php echo !empty($data['original_text']) ? $data['original_text'] : '' ?>">
				</div>
			</div>
			<div class="shoptefy_form_group">
				<span><?php echo $shoptefy->lang('Language'); ?></span>
				<div class="shoptefy_form_content">
					<select name="lang">
						<?php
							foreach ($langs as $lang) {
								echo '<option value="'.$lang.'"'.(
									(isset($data['lang']) && $data['lang'] == $lang) ? ' selected' : ''
								).'>'.$lang_map[$lang].' - '.strtoupper($lang).'</option>';
							}
						?>
					</select>
				</div>
			</div>
			<div class="shoptefy_form_group shoptefy_form_submit">
				<input type="hidden" name="id" value="<?php echo !empty($data['id']) ? $data['id'] : '' ?>"/>
				<input type="submit" class="shoptefy-button shoptefy-button-primary" value="<?php echo $shoptefy->lang('Save Language'); ?>"/>
				<input type="hidden" name="save_language" value="true">
				<a class="shoptefy_cancel" href="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=languages">
					<?php echo $shoptefy->lang('Cancel'); ?>
				</a>
			</div>
			<?php $shoptefy->securityFrom();?>
		</form>
	</div>
</div>
