<?php
	
	global $shoptefy;

	$section = 'template';
	$id = isset($_GET['id']) ? $_GET['id'] : 0;
	$fields = $shoptefy_admin->process_data(array(
		array(
			'type' => 'input',
			'name' => 'name',
			'label' => $shoptefy->lang('Name'),
			'required' => true,
			'default' => 'Untitled'
		),
		array(
			'type' => 'input',
			'name' => 'price',
			'label' => $shoptefy->lang('Price'),
			'default' => 0,
			'numberic' => 'float',
			'desc' => $shoptefy->lang('Enter price for this template.')
		),
		array(
			'type' => 'categories',
			'cate_type' => 'templates',
			'name' => 'categories',
			'label' => $shoptefy->lang('Categories'),
			'id' => $id,
			'db' => false
		),
		array(
			'type' => 'tags',
			'tag_type' => 'templates',
			'name' => 'tags',
			'label' => $shoptefy->lang('Tags'),
			'id' => $id,
			'desc' => $shoptefy->lang('Example: tag1, tag2, tag3 ...'),
		),
		array(
			'type' => 'upload',
			'file' => 'design',
			'name' => 'upload',
			'path' => 'templates'.DS.date('Y').DS.date('m').DS,
			'thumbn' => 'screenshot',
			'label' => $shoptefy->lang('Upload template file'),
			'desc' => $shoptefy->lang('Upload the exported file *.lumi from the shoptefy Designer Tool. You can download the LUMI file via menu "File" > Save As File, or press Ctrl+Shift+S')
		),
		array(
			'type' => 'toggle',
			'name' => 'featured',
			'label' => $shoptefy->lang('Featured'),
			'default' => 'no',
			'value' => null
		),
		array(
			'type' => 'toggle',
			'name' => 'active',
			'label' => $shoptefy->lang('Active'),
			'default' => 'yes',
			'value' => null
		),
		array(
			'type' => 'input',
			'name' => 'order',
			'type_input' => 'number',
			'label' => $shoptefy->lang('Order'),
			'default' => 0,
			'desc' => $shoptefy->lang('Ordering of item with other.')
		),
	), 'templates');

?>

<div class="shoptefy_wrapper" id="shoptefy-<?php echo $section; ?>-page">
	<div class="shoptefy_content">
		<?php
			$shoptefy->views->detail_header(array(
				'add' => $shoptefy->lang('Add new template'),
				'edit' => $fields[0]['value'],
				'page' => $section
			));
		?>
		<form action="<?php echo $shoptefy->cfg->admin_url; ?>shoptefy-page=<?php
			echo $section.(isset($_GET['callback']) ? '&callback='.$_GET['callback'] : '');
		?>" id="shoptefy-<?php echo $section; ?>-form" method="post" class="shoptefy_form" enctype="multipart/form-data">

			<?php $shoptefy->views->tabs_render($fields); ?>

			<div class="shoptefy_form_group shoptefy_form_submit">
				<input type="submit" class="shoptefy-button shoptefy-button-primary" value="<?php echo $shoptefy->lang('Save Template'); ?>"/>
				<input type="hidden" name="do" value="action" />
				<a class="shoptefy_cancel" href="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=templates">
					<?php echo $shoptefy->lang('Cancel'); ?>
				</a>
				<input type="hidden" name="shoptefy-section" value="<?php echo $section; ?>">
			</div>
		</form>
	</div>
</div>
<script type="text/javascript">
	
	var shoptefy_upload_url = '<?php echo $shoptefy->cfg->upload_url; ?>',
		shoptefy_assets_url = '<?php echo $shoptefy->cfg->assets_url; ?>';
			
	document.shoptefyconfig = {
		main: 'template'
	};
</script>
