<?php
    
	$prefix = 'ops_';
    
    $order_id = isset($_REQUEST['order_id'])? $_REQUEST['order_id']: 0;
    // Search Form
	$data_search = '';
	if (isset($_POST['search_ops']) && !empty($_POST['search_ops'])) {
		
		$data_search = isset($_POST['search']) ? trim($_POST['search']) : '';

		if (empty($data_search)) {
			$errors = 'Search Product Name';
			$_SESSION[$prefix.'data_search'] = '';
		} else {
			$_SESSION[$prefix.'data_search'] = 	$data_search;
		}

	}

	if (!empty($_SESSION[$prefix.'data_search'])) {
		$data_search = '%'.$_SESSION[$prefix.'data_search'].'%';
	}
    
    $search_filter = array(
        'keyword' => $data_search,
        'fields' => 'ops.product_name'
    );
    
    $shoptefy->do_action('before_order_products', $order_id);
    
    // Sort Form
	if (!empty($_POST['sort'])) {

		$dt_sort = isset($_POST['sort']) ? $_POST['sort'] : '';
		$_SESSION[$prefix.'dt_order'] = $dt_sort;
		
		switch ($dt_sort) {

			case 'product_id_asc':
				$_SESSION[$prefix.'orderby'] = 'product_id';
				$_SESSION[$prefix.'ordering'] = 'asc';
				break;
			case 'product_id_desc':
				$_SESSION[$prefix.'orderby'] = 'product_id';
				$_SESSION[$prefix.'ordering'] = 'desc';
				break;
			case 'name_asc':
				$_SESSION[$prefix.'orderby'] = 'product_name';
				$_SESSION[$prefix.'ordering'] = 'asc';
				break;
			case 'name_desc':
				$_SESSION[$prefix.'orderby'] = 'product_name';
				$_SESSION[$prefix.'ordering'] = 'desc';
				break;
            
			default:
				break;

		}

	}
    
    if(
        $_SERVER['REQUEST_METHOD'] =='POST' &&
        (
            !empty($_POST['sort']) ||
            isset($_POST['do'])
        )
    ){
        $shoptefy->redirect($shoptefy->cfg->admin_url.'shoptefy-page=order&order_id='.$order_id);
    }

	$orderby  = (isset($_SESSION[$prefix.'orderby']) && !empty($_SESSION[$prefix.'orderby'])) ? $_SESSION[$prefix.'orderby'] : 'product_id';
	$ordering = (isset($_SESSION[$prefix.'ordering']) && !empty($_SESSION[$prefix.'ordering'])) ? $_SESSION[$prefix.'ordering'] : 'asc';
	$dt_order = isset($_SESSION[$prefix.'dt_order']) ? $_SESSION[$prefix.'dt_order'] : 'product_id_desc';
    $items = $shoptefy->connector->products_order($order_id, $search_filter, $orderby, $ordering);

    $shoptefy_printings = $shoptefy->lib->get_prints();
    $printings = array();
    foreach( $shoptefy_printings as $p ) {
        $printings[ $p['id'] ] = $p;
    }
    
?><div class="shoptefy_wrapper">
	
	<div class="shoptefy_content">

		<div class="shoptefy_header">
			<h2>
				<a href="<?php echo $shoptefy->cfg->admin_url; ?>shoptefy-page=orders"><?php echo $shoptefy->lang('All Orders'); ?></a> 
				<i class="fa fa-angle-right"></i> 
				<?php printf($shoptefy->lang('Order %s'), '#'.$_REQUEST['order_id']) ?>
			</h2>
			<?php
				$shoptefy_page = isset($_GET['shoptefy-page']) ? $_GET['shoptefy-page'] : '';
				echo $shoptefy_helper->breadcrumb($shoptefy_page);
			?>
            <div class="shoptefy-order-details shoptefy_option">
                <div class="col-3">
                    <h4><?php echo $shoptefy->lang('General Details'); ?></h4>
                    <p>
                        <strong><?php echo $shoptefy->lang('Total Price:'); ?></strong>
                        <span><?php echo $shoptefy->lib->price($items['order']['total']);?></span>
                    </p>
                    <p>
                        <strong><?php echo $shoptefy->lang('Created At:'); ?></strong>
                        <span><?php echo $items['order']['created'];?></span>
                    </p>
                    <p>
                        <strong><?php echo $shoptefy->lang('Updated At:'); ?></strong>
                        <span><?php echo $items['order']['updated'];?></span>
                    </p>
                    <?php if(isset($items['order']['payment'])): ?>
                    <p>
                        <strong><?php echo $shoptefy->lang('Payment:'); ?></strong>
                        <span class="shoptefy-payment-method"><?php echo isset($items['order']['payment'])? $items['order']['payment']: '';?></span>
                    </p>
                    <?php endif; ?>
                    <div class="order_status">
                        <strong><?php echo $shoptefy->lang('Status:'); ?></strong>
                    
                        <form action="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=order&order_id=<?php echo $order_id;?>" method="post">
                            <?php $shoptefy->views->order_statuses($items['order']['status'], true);?>
                            <input type="hidden" name="do" value="action"/>
                        </form>
                    </div>
                </div>
                <?php if(isset($items['billing']) && count($items['billing'])>0):?>
                <div class="col-3">
                	<h4><?php echo $shoptefy->lang('Billing details'); ?></h4>
                    <p>
                        <strong><?php echo $shoptefy->lang('Name:'); ?></strong>
                        <span><?php echo isset($items['billing']['name'])? $items['billing']['name'] : '';?></span>
                    </p>
                	<p>
                		<strong><?php echo $shoptefy->lang('Address:'); ?></strong>
                		<span><?php echo isset($items['billing']['address'])? $items['billing']['address'] : '';?></span>
                	</p>
                	<p>
                		<strong><?php echo $shoptefy->lang('Email address:'); ?></strong>
                		<span><?php echo isset($items['billing']['email'])? $items['billing']['email'] : '';?></span>
                	</p>
                	<p>
                		<strong><?php echo $shoptefy->lang('Phone:'); ?></strong>
                		<span><?php echo isset($items['billing']['phone'])? $items['billing']['phone'] : '';?></span>
                	</p>
                	
                </div>
                <?php endif;?>
            </div>
            
		</div>

            <div class="shoptefy_option">
                <div class="left">
                    <form action="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=order&order_id=<?php echo $order_id;?>" method="post">
                        <?php $shoptefy->securityFrom();?>
                    </form>
                </div>
                <div class="right">
                    <form action="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=order&order_id=<?php echo $order_id;?>" method="post">
                        <input type="text" name="search" class="search" placeholder="<?php echo $shoptefy->lang('Search ...'); ?>" value="<?php if(isset($_SESSION[$prefix.'data_search'])) echo $_SESSION[$prefix.'data_search']; ?>">
                        <input  class="shoptefy_submit" type="submit" name="search_ops" value="<?php echo $shoptefy->lang('Search'); ?>">
                        <?php $shoptefy->securityFrom();?>

                    </form>
                </div>
            </div>
        
        <div class="shoptefy_wrap_table">
			<table class="shoptefy_table shoptefy_ops shoptefy_order_details">
				<thead>
					<tr>
						<th width="5%"><?php echo $shoptefy->lang('ID'); ?></th>
						<th width="5%"><?php echo $shoptefy->lang('Product ID'); ?></th>
						<th><?php echo $shoptefy->lang('Product Name'); ?></th>
						<th><?php echo $shoptefy->lang('Thumbnail'); ?></th>
						<th><?php echo $shoptefy->lang('Attributes'); ?></th>
                        <th width="5%"><?php echo $shoptefy->lang('Subtotal'); ?></th>
                        <th width="30%"><?php echo $shoptefy->lang('Print'); ?></th>
					</tr>
				</thead>
				<tbody>
	                <?php
	                
	                if (count($items['rows']) > 0) {
	                    foreach($items['rows'] as $item):
	                    
	                    $scrs = array();
	                    $pdfid = '';
	                    $sc = @json_decode($item['screenshots']);
						$prt = @json_decode($item['print_files'], true);
						
						$pdfid = $item['cart_id'];
						
						foreach ($sc as $i => $s) {
							array_push($scrs, array(
								"url" => is_array($prt) && isset($prt[$i]) ? $shoptefy->cfg->upload_url.'orders/'.$prt[$i] : '#',
								"screenshot" => $shoptefy->cfg->upload_url.'orders/'.$s,
								"download" => true
							));
						}
	                ?>
	                <tr>
						<td>#<?php echo $item['id'];?></td>
						<td><?php echo $item['product_id'];?></td>
						<td><?php echo $item['product_name'] . ' x ' .$item['qty'];?></td>
						<td>
                            <?php
                            $product = $shoptefy->lib->get_product($item['product_base']);
                            if(isset($item['screenshots']) && $item['screenshots'] != null){
                                $screenshots = json_decode($item['screenshots']);
                                foreach ($screenshots as $screenshot) {
                					echo '<img src="'.$shoptefy->cfg->upload_url.'orders/'.$screenshot.'" class="shoptefy-order-thumbnail" />';
                				}
                            }
                            if(isset($item['custom']) && !$item['custom']){
                                
                                if(isset($product['thumbnail_url']))
                                    echo '<img src="'.$product['thumbnail_url'].'" class="shoptefy-order-thumbnail" />';
                            }
                            ?>
                        </td>
                        <td><?php
	                        
                            $data_obj = $shoptefy->lib->dejson($item['data']);
                            
                            if ( isset($data_obj->attributes) ) {
	                            
                                foreach ($data_obj->attributes as $id => $attr ) {
	                                
	                                if (
	                                	is_object($attr) && 
	                                	isset($attr->name)
	                                ) {
		                                
		                                if (isset($attr->value)) {
			                                
		                                    echo "<strong>{$attr->name}:</strong> ";
		                                    
		                                    if (
		                                    	$attr->type == 'color' || 
		                                    	$attr->type == 'product_color'
		                                    ) {
			                                    
			                                    $col = $attr->value;
			                                    
			                                   	if (
			                                   		is_object($attr->values) && 
			                                   		is_array($attr->values->options)
			                                   	) {
				                                   	foreach ($attr->values->options as $op) {
					                                   	if ($op->value == $attr->value)
					                                   		$col = htmlentities($op->title);
				                                   	}
			                                   	}
												echo '<span title="'.htmlentities($attr->value).'" style="background: '.$attr->value.';padding: 2px 5px;border-radius: 2px;">'.$col.'</span>';
		                                    } else echo htmlentities($attr->value);
		                                    
		                                    echo "<br>";
		                                }
		                                
                                    } else {
	                                    
	                                    echo "<strong>$id:</strong>";
	                                    if (is_array($values)){
	                                        foreach($values as $att_val){
	                                            echo "<dt>$attr</dt>";
	                                        }
	                                    } 
                                    }
	                            }
	                          
                            }
                            
                            if( 
                                isset($data_obj->printing) 
                                && is_array($printings) 
                                && isset($printings[ $data_obj->printing]) 
                            ){
                                $pmethod = $printings[ $data_obj->printing];
                                echo "<strong>".$shoptefy->lang('Printing Type').":</strong>";
                                echo "<dt>".$pmethod['title']."</dt>";
                            }
                            
                            if( isset($data_obj->color) ){
                                echo "<strong>".$shoptefy->lang('Color').":</strong>";
                                echo "<dt>".(($data_obj->color != $data_obj->color_name)? $data_obj->color . ' - '. $data_obj->color_name : $data_obj->color)."</dt>";
                            }
                        ?></td>
                        <td><?php echo $shoptefy->lib->price($item['product_price']);?></td>
                        <td>
	                        <?php
                               
		                        if (count($scrs) > 0) {
                                   
		                        	$key = $shoptefy->get_option('purchase_key');
									$key_valid = ($key === null || empty($key) || strlen($key) != 36 || count(explode('-', $key)) != 5) ? false : true;
                                    
 
			
									$is_query = explode('?', $shoptefy->cfg->tool_url);
													
									$url = $shoptefy->cfg->tool_url.(isset($is_query[1])? '&':'?');

									if (!empty($item['design'])) {
										$url .= '&design_print='.str_replace('.lumi', '', $item['design']);
										$url .= '&order_print='.$item['order_id'];
										if($shoptefy->connector->platform == 'woocommerce'){
											$order = wc_get_order($item['order_id']);
											foreach ( $order->get_items() as $item_id => $order_item ) {
												if($order_item->get_product_id() == $item['product_id'] && $order_item->get_meta( 'shoptefy_data', true )){
													if($order_item->get_variation_id()){
														$url .= '&product_base='.'variable:'.$order_item->get_variation_id();
														$url .=  '&product_cms=' . $item['product_id'];
													}else{
														$url .= '&product_base='.$item['product_base'];
														$url .= '&product_cms=' . $item['product_id'];
													}
													break;
												}
											};
										}
										if($shoptefy->connector->platform == 'php'){
											$url .= '&product_base='.$item['product_base'];
										}
									}
									
									$url = str_replace('?&', '?', $url);
									$html = '<p>';
									$prtable = false; 
									
									if($key_valid) {
										foreach ($scrs as $i => $scr) {
											
											$html .= '<a ';
											
											if ($scr['download'] === true) {
												$html .= 'href="'.$scr['url'].'" download="order_id#'.$item['id'].' (stage '.($i+1).').png"';
												$prtable = true;
											} else {
												$html .= 'href="'.(!empty($scr['url']) ? $scr['url'] : $url).'" target=_blank';
											}
											$html .= '><img width="80" src="'.$scr['screenshot'].'" /></a>';
										}
									}
									
									
									$html .= '</p>';
									
									if ($prtable === true && $key_valid) {
										$html .= '<p><font color="#e74c3c">(*) ';
										$html .= $shoptefy->lang('Click on each image above to download the printable file <b>(.PNG)</b>').'</font></p>';
									}
									
									$html .= '<p>';
									if(!$key_valid){
										$html .= '<p style="font-size:14px;"><font color="#E91E63">(*) ';
										$html .= $shoptefy->lang('<span>Please enter your purchase code to display and download file designs</span></br>
<b><a target="_blank" href="'.$shoptefy->cfg->admin_url.'shoptefy-page=license"style="font-weight: 700; text-decoration: underline; font-style: italic;">Enter purchase code now</a></b></br>
<span>Notice: Each License can only be used for one domain.</br><a href="https://codecanyon.net/licenses/standard" target="blank" style="font-weight: 700; text-decoration: underline; font-style: italic;">Click to learn more about license term in Envato.</a></span>').'</font></p>';
									}
									
									if (!empty($pdfid)) {
										$link = $shoptefy->cfg->tool_url;
										if(strpos($link, '?') !== false && substr($link, -1) != '?'){
											$link .= '&pdf_download='.$pdfid;
										} 
										if(strpos($link, '?') !== false && substr($link, -1) == '?') {
											$link .= 'pdf_download='.$pdfid;
										}
										if(strpos($link, '?') === false) {
											$link .= '?pdf_download='.$pdfid;
										}
										if($key_valid) {
											$html .= '<a href="'.$link.'" target=_blank class="shoptefy-button shoptefy-button-primary" style="margin-bottom:5px;">'.$shoptefy->lang('Download designs as PDF').'</a>  &nbsp; <a href="#" data-href="'.$link.'" target=_blank class="shoptefy-button shoptefy-button-primary" onclick="let r = prompt(\'Enter bleed range in mimilet (Typically it is 2mm)\', \'2\');if (r){this.href = this.dataset.href+\'&bleed=\'+r;return true;}else return false;" style="margin-bottom:5px;">'.$shoptefy->lang('PDF cropmarks & bleed').'</a> &nbsp; ';
										}
									}	
									
									if($key_valid) {
										$html .= '<a href="'.$url.'" target=_blank class="shoptefy-button">'.$shoptefy->lang('View in shoptefy editor').'</a>';
									}
									
									$html .= '</p>';
									
									echo $html;
									
								}
		                        
	                        ?>
		                </td>
					</tr>
	                    <?php
	                    endforeach;
	                }
	                else {
	                ?>
	                <tr>
	                    <td colspan="6">
	                        <p class="no-data"><?php echo $shoptefy->lang('Apologies, but no results were found'); ?></p>
	                    </td>
	                </tr>
	                    
	                    
	                <?php
	                }
	                ?>
				</tbody>
                <tfoot class="no-border">
                    <tr>
                        <td colspan="3"></td>
                        <td></td>
                        <td colspan="2">
                            <strong style="float: right;"><?php echo $shoptefy->lang('Order Total:'); ?></strong>
                        </td>
                        <td>
                            <?php echo $shoptefy->lib->price($items['order']['total']); ?>
                        </td>
                    </tr>
                </tfoot>
			</table>
        </div>
		
	</div>

</div>
