<?php
	global $shoptefy;
	$checked = @json_decode($shoptefy->get_option('last_check_update'));
?>

<div class="shoptefy_wrapper">

	<div id="shoptefy-updates">
		<h1><?php echo $shoptefy->lang('shoptefy Updates'); ?></h1>
		<?php $shoptefy->views->header_message(); ?>
		<form action="" method="POST">
			<?php echo $shoptefy->lang('Last checked on ').' '.(isset($checked->time) ? 
				'<span id="write-time-check"><script>var tm = new Date('.$checked->time.'000), mt = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]; document.getElementById("write-time-check").innerHTML = tm.getHours()+"h:"+(tm.getMinutes()<10 ? "0"+tm.getMinutes() : tm.getMinutes())+" - "+tm.getDate()+" "+mt[tm.getMonth()]+" "+tm.getFullYear();</script></span>' 
				: '<b>Recently</b>'); ?>.
			&nbsp; 
			<button type="submit" class="shoptefy_btn loaclik" data-func="check"><?php echo $shoptefy->lang('Check again'); ?></button>
			<input type="hidden" name="do_action" value="check-update" />
		</form>
		<?php
			if (!empty($checked) && isset($checked->version) && version_compare(shoptefy, $checked->version, '<')) {
			?>
			<h3>
				<?php echo $shoptefy->lang('An updated version of shoptefy is available'); ?>. 
				<?php echo $shoptefy->lang('New version').' '.$checked->version; ?>
			</h3>
			<div class="shoptefy-update-notice">
				<b><?php echo $shoptefy->lang('Important'); ?></b>: 
				<?php echo $shoptefy->lang('before updating, please back up your database and files of shoptefy'); ?>
			</div>
			<form action="" method="POST">
				<button class="shoptefy_btn primary loaclik"><?php echo $shoptefy->lang('Update Now'); ?></button> 
				&nbsp; 
				<a class="shoptefy_btn" href="https://www.shoptefy.com/changelogs/<?php echo $shoptefy->connector->platform; ?>?utm_source=client-site&utm_medium=text&utm_campaign=update-page&utm_term=links&utm_content=<?php echo $shoptefy->connector->platform; ?>" target=_blank>
					<?php echo $shoptefy->lang(' Changelogs'); ?>
				</a>
				<input type="hidden" name="do_action" value="do-update" />
			</form>
			<?php	
			} else {
			?>
			<h2><?php echo $shoptefy->lang('Great! You have the latest version of shoptefy'); ?>.</h2>
			<?php	
			}
		?>
	</div>

</div>
