<?php

	$section = 'addon';
	$name = isset($_GET['name']) ? $_GET['name'] : '';
	
	if (
		!isset($shoptefy->addons->storage->{$name}) ||
		!method_exists($shoptefy->addons->storage->{$name}, 'settings')
	) {
	?>
	<div class="shoptefy_wrapper">
		<div class="shoptefy_content">
			<div class="shoptefy_header">
				<h2>
					<a href="<?php echo $shoptefy->cfg->admin_url?>shoptefy-page=addons" title="<?php echo $shoptefy->lang('Back to Addons'); ?>">
						<?php echo $shoptefy->lang('Addons'); ?>
					</a>
					<i class="fa fa-angle-right"></i>
					<?php echo str_replace(array('_', '-'), ' ', $name); ?>
				</h2>
			</div>
			<?php 
				if (!method_exists($shoptefy->addons->storage->{$name}, 'help'))
					echo '<h3 class="no-available">'.$shoptefy->lang('This addon has no options').'</h3>';
				else $shoptefy->addons->storage->{$name}->help();
			?>
		</div>
	</div>
	<?php
		return;
	}
		
	$args = $shoptefy->addons->storage->{$name}->settings();
	$fields = $shoptefy_admin->process_settings_data($args);

?>

<div class="shoptefy_wrapper" id="shoptefy-<?php echo $section; ?>-page">
	<div class="shoptefy_content">
		<div class="shoptefy_header">
			<h2>
				<a href="<?php echo $shoptefy->cfg->admin_url?>shoptefy-page=addons" title="<?php echo $shoptefy->lang('Back to Addons'); ?>">
					<?php echo $shoptefy->lang('Addons'); ?>
				</a>
				<i class="fa fa-angle-right"></i>
				<?php echo str_replace(array('_', '-'), ' ', $name); ?>
			</h2>
		</div>
		<form action="<?php echo $shoptefy->cfg->admin_url; ?>shoptefy-page=addon&name=<?php echo $name; ?>" id="shoptefy-clipart-form" method="post" class="shoptefy_form" enctype="multipart/form-data">

			<?php 
				$shoptefy->views->header_message();
				$shoptefy->views->tabs_render($fields); 
			?>

			<div class="shoptefy_form_group shoptefy_form_submit">
				<input type="submit" class="shoptefy-button shoptefy-button-primary" value="<?php echo $shoptefy->lang('Save Addon Settings'); ?>"/>
				<input type="hidden" name="do" value="action" />
				<a class="shoptefy_cancel" href="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=<?php echo $section; ?>s">
					<?php echo $shoptefy->lang('Cancel'); ?>
				</a>
				<input type="hidden" name="shoptefy-section" value="<?php echo $section; ?>">
				<input type="hidden" name="shoptefy-redirect" value="<?php echo $shoptefy->cfg->admin_url; ?>shoptefy-page=addon&name=<?php echo $name; ?>">
			</div>
		</form>
		<?php
			if (method_exists($shoptefy->addons->storage->{$name}, 'help'))
				$shoptefy->addons->storage->{$name}->help();
		 ?>
	</div>
</div>
