<?php

	global $shoptefy;
	$section = 'category';
	$type = isset($_GET['type']) ? $_GET['type'] : '';
	
	$fields = $shoptefy_admin->process_data(array(
		array(
			'type' => 'input',
			'name' => 'name',
			'label' => $shoptefy->lang('Name'),
			'required' => true
		),
		array(
			'type' => 'parent',
			'cate_type' => $type,
			'name' => 'parent',
			'label' => $shoptefy->lang('Parent'),
			'id' => isset($_GET['id'])? $_GET['id'] : 0
		),
		array(
			'type' => 'upload',
			'name' => 'upload',
			'path' => 'thumbnails'.DS,
			'thumbn' => 'thumbnail_url',
			'label' => $shoptefy->lang('Thumbnail'),
			'desc' => $shoptefy->lang('Supported files svg, png, jpg, jpeg. Max size 5MB')
		),
		array(
			'type' => 'input',
			'name' => 'order',
			'type_input' => 'number',
			'label' => $shoptefy->lang('Order'),
			'default' => 0,
			'desc' => $shoptefy->lang('Ordering of item with other.')
		),
		array(
			'type' => 'toggle',
			'name' => 'active',
			'label' => $shoptefy->lang('Active'),
			'default' => 'yes',
			'value' => null
		),
		array(
			'type' => 'input',
			'type_input' => 'hidden',
			'name' => 'type',
			'default' => $type,
		)
	), 'categories');

?>

<div class="shoptefy_wrapper">
	<div class="shoptefy_content">
		<?php
			$shoptefy->views->detail_header(array(
				'add' => $shoptefy->lang('Add New Category'),
				'edit' => $fields[0]['value'],
				'page' => $section,
				'pages' => 'categories',
				'type' => $type
			));
		?>
		<form action="<?php echo $shoptefy->cfg->admin_url; ?>shoptefy-page=<?php
			echo $section.(isset($_GET['callback']) ? '&callback='.$_GET['callback'] : '');
		?>" id="shoptefy-clipart-form" method="post" class="shoptefy_form" enctype="multipart/form-data">

			<?php $shoptefy->views->tabs_render($fields); ?>

			<div class="shoptefy_form_group shoptefy_form_submit">
				<input type="submit" class="shoptefy-button shoptefy-button-primary" value="<?php echo $shoptefy->lang('Save Category'); ?>"/>
				<input type="hidden" name="do" value="action" />
				<a class="shoptefy_cancel" href="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=categories&type=<?php echo $type; ?>">
					<?php echo $shoptefy->lang('Cancel'); ?>
				</a>
				<input type="hidden" name="shoptefy-section" value="<?php echo $section; ?>">
			</div>
		</form>
	</div>
</div>
