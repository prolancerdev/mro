<?php
	global $shoptefy;

	$section = 'clipart';
	$fields = $shoptefy_admin->process_data(array(
		array(
			'type' => 'input',
			'name' => 'name',
			'label' => $shoptefy->lang('Name'),
			'required' => true,
			'default' => 'Untitled'
		),
		array(
			'type' => 'categories',
			'cate_type' => 'cliparts',
			'name' => 'categories',
			'label' => $shoptefy->lang('Categories'),
			'id' => isset($_GET['id'])? $_GET['id'] : 0,
			'db' => false
		),
		array(
			'type' => 'tags',
			'tag_type' => 'cliparts',
			'name' => 'tags',
			'label' => $shoptefy->lang('Tags'),
			'id' => isset($_GET['id'])? $_GET['id'] : 0,
			'desc' => $shoptefy->lang('Example: tag1, tag2, tag3 ...'),
		),
		array(
			'type' => 'upload',
			'name' => 'upload',
			'path' => 'cliparts'.DS.date('Y').DS.date('m').DS,
			'thumbn' => 'thumbnail_url',
			'label' => $shoptefy->lang('Upload design file'),
			'desc' => $shoptefy->lang('Supported files svg, png, jpg, jpeg. Max size 5MB')
		),
		array(
			'type' => 'input',
			'name' => 'price',
			'label' => $shoptefy->lang('Price'),
			'default' => 0
		),
		array(
			'type' => 'toggle',
			'name' => 'featured',
			'label' => $shoptefy->lang('Featured'),
			'default' => 'no',
			'value' => null
		),
		array(
			'type' => 'toggle',
			'name' => 'active',
			'label' => $shoptefy->lang('Active'),
			'default' => 'yes',
			'value' => null
		),
		array(
			'type' => 'input',
			'name' => 'order',
			'type_input' => 'number',
			'label' => $shoptefy->lang('Order'),
			'default' => 0,
			'desc' => $shoptefy->lang('Ordering of item with other.')
		),
	), 'cliparts');

?>

<div class="shoptefy_wrapper" id="shoptefy-<?php echo $section; ?>-page">
	<div class="shoptefy_content">
		<?php
			$shoptefy->views->detail_header(array(
				'add' => $shoptefy->lang('Add new clipart'),
				'edit' => $fields[0]['value'],
				'page' => $section
			));
		?>
		<form action="<?php echo $shoptefy->cfg->admin_url; ?>shoptefy-page=<?php
			echo $section.(isset($_GET['callback']) ? '&callback='.$_GET['callback'] : '');
		?>" id="shoptefy-clipart-form" method="post" class="shoptefy_form" enctype="multipart/form-data">

			<?php $shoptefy->views->tabs_render($fields); ?>

			<div class="shoptefy_form_group shoptefy_form_submit">
				<input type="submit" class="shoptefy-button shoptefy-button-primary" value="<?php echo $shoptefy->lang('Save Clipart'); ?>"/>
				<input type="hidden" name="do" value="action" />
				<a class="shoptefy_cancel" href="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=cliparts">
					<?php echo $shoptefy->lang('Cancel'); ?>
				</a>
				<input type="hidden" name="shoptefy-section" value="<?php echo $section; ?>">
			</div>
		</form>
	</div>
</div>
