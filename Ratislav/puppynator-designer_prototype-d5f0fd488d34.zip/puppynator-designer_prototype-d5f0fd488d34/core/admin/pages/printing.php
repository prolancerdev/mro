<?php
	global $shoptefy;

	$section = 'printing';
	$fields = $shoptefy_admin->process_data(array(
		array(
			'type' => 'input',
			'name' => 'title',
			'label' => $shoptefy->lang('Printing Title'),
			'required' => true,
			'default' => 'Untitled'
		),
		array(
			'type' => 'upload',
			'name' => 'upload',
			'thumbn' => 'thumbnail',
			'thumbn_width' => 320,
			'path' => 'printings'.DS,
			'label' => $shoptefy->lang('Printing thumbnail'),
			'desc' => $shoptefy->lang('Supported files svg, png, jpg, jpeg. Max size 5MB'),
		),
		array(
			'type' => 'text',
			'name' => 'description',
			'label' => $shoptefy->lang('Description'),
		),
		array(
			'type' => 'print',
			'name' => 'calculate',
			'label' => $shoptefy->lang('Calculation Price'),
			'prints_type' => $shoptefy->lib->get_print_types()
		),
		array(
			'type' => 'toggle',
			'name' => 'active',
			'label' => $shoptefy->lang('Active'),
			'default' => 'yes',
			'value' => null
		),
	), 'printings');

?>

<div class="shoptefy_wrapper" id="shoptefy-<?php echo $section; ?>-page">
	<div class="shoptefy_content">
		<?php
			$shoptefy->views->detail_header(array(
				'add' => $shoptefy->lang('Add new printing'),
				'edit' => $fields[0]['value'],
				'page' => $section
			));
		?>
		<form action="<?php echo $shoptefy->cfg->admin_url; ?>shoptefy-page=<?php
			echo $section.(isset($_GET['callback']) ? '&callback='.$_GET['callback'] : '');
		?>" id="shoptefy-<?php echo $section; ?>-form" method="post" class="shoptefy_form" enctype="multipart/form-data">

			<?php $shoptefy->views->tabs_render($fields); ?>

			<div class="shoptefy_form_group shoptefy_form_submit">
				<input type="submit" class="shoptefy-button shoptefy-button-primary" value="<?php echo $shoptefy->lang('Save Printing'); ?>"/>
				<input type="hidden" name="do" value="action" />
				<a class="shoptefy_cancel" href="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=<?php echo $section; ?>s">
					<?php echo $shoptefy->lang('Cancel'); ?>
				</a>
				<input type="hidden" name="shoptefy-section" value="<?php echo $section; ?>">
			</div>
		</form>
	</div>
</div>
