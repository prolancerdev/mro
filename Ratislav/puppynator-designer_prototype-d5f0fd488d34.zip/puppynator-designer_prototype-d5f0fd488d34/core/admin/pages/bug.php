<?php

	global $shoptefy;
	$section = 'bug';

	$fields = $shoptefy_admin->process_data(array(
		array(
			'type' => 'text',
			'name' => 'content',
			'label' => $shoptefy->lang('Content')
		),
		array(
			'type' => 'dropbox',
			'name' => 'status',
			'label' => $shoptefy->lang('Status'),
			'options' => array(
				'new' => 'New',
				'pending' => 'Pending',
				'fixed' => 'Fixed',
			)
		),
	), 'bugs');

?>

<div class="shoptefy_wrapper">
	<div class="shoptefy_content">
		<?php
			$shoptefy->views->detail_header(array(
				'add' => $shoptefy->lang('Add new Bbug'),
				'edit' => '#'.isset($_GET['id']) ? intval($_GET['id']) : '',
				'page' => $section
			));
		?>
		<form action="<?php echo $shoptefy->cfg->admin_url; ?>shoptefy-page=<?php
			echo $section.(isset($_GET['callback']) ? '&callback='.$_GET['callback'] : '');
		?>" id="shoptefy-clipart-form" method="post" class="shoptefy_form" enctype="multipart/form-data">

			<?php $shoptefy->views->tabs_render($fields); ?>

			<div class="shoptefy_form_group shoptefy_form_submit">
				<input type="submit" class="shoptefy-button shoptefy-button-primary" value="<?php echo $shoptefy->lang('Save Bug'); ?>"/>
				<input type="hidden" name="do" value="action" />
				<a class="shoptefy_cancel" href="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=bugs">
					<?php echo $shoptefy->lang('Cancel'); ?>
				</a>
				<input type="hidden" name="shoptefy-section" value="<?php echo $section; ?>">
			</div>
		</form>
	</div>
</div>
