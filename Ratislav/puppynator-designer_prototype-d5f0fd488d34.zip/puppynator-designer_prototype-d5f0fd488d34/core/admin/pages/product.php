<?php
	
	global $shoptefy;
	
	$arg = array(

		'tabs' => array(

			'details:' . $shoptefy->lang('Details') => array(
				array(
					'type' => 'input',
					'name' => 'name',
					'label' => $shoptefy->lang('Name'),
					'required' => true,
					'default' => 'Untitled'
				),
				(
					$shoptefy->connector->platform == 'php'? 
					array(
						'type' => 'input',
						'name' => 'price',
						'label' => $shoptefy->lang('Price'),
						'default' => '0',
						'desc' => $shoptefy->lang('Enter the base price for this product.')
					) : null
				),
				(
					$shoptefy->connector->platform == 'php' ?
					array(	
						'type' => 'upload',
						'name' => 'thumbnail',
						'thumbn' => 'thumbnail_url',
						'path' => 'thumbnails'.DS,
						'label' => $shoptefy->lang('Product thumbnail'),
						'desc' => $shoptefy->lang('Supported files svg, png, jpg, jpeg. Max size 5MB')
					)
					:
					array(
						'type' => 'input',
						'name' => 'product',
						'label' => $shoptefy->lang('CMS Product'),
						'default' => '0',
						'desc' => $shoptefy->lang('This product will not be listed if this field value is zero. It will set automatically when you select this product base for a Woocommerce Product'),
						'readonly' => true
					)
				)
				,
				array(
					'type' => 'text',
					'name' => 'description',
					'label' => $shoptefy->lang('Description')
				),
				array(
					'type' => 'toggle',
					'name' => 'active_description',
					'label' => $shoptefy->lang('Active description'),
					'default' => 'no',
					'value' => null,
					'desc' => $shoptefy->lang('Show description on editor design.')
				),
				array(
					'type' => 'categories',
					'cate_type' => 'products',
					'name' => 'categories',
					'label' => $shoptefy->lang('Categories'),
					'id' => isset($_GET['id'])? $_GET['id'] : 0
				),
				array(
					'type' => 'printing',
					'name' => 'printings',
					'label' => $shoptefy->lang('Printing Techniques'),
					'desc' => $shoptefy->lang('Select Printing Techniques with price calculations for this product').'<br>'.$shoptefy->lang('Drag to arrange items, the first one will be set as default').'. <br><a href="'.$shoptefy->cfg->admin_url.'shoptefy-page=printings" target=_blank>'.$shoptefy->lang('You can manage all Printings here').'.</a>'
				),
				array(
					'type' => 'toggle',
					'name' => 'active',
					'label' => $shoptefy->lang('Active'),
					'default' => 'yes',
					'value' => null,
					'desc' => $shoptefy->lang('Deactivate does not affect the selected products. It will only not show in the switching products.')
				),
				array(
					'type' => 'input',
					'name' => 'order',
					'type_input' => 'number',
					'label' => $shoptefy->lang('Order'),
					'default' => 0,
					'desc' => $shoptefy->lang('Ordering of item with other.')
				),
			),

			'design:' . $shoptefy->lang('Designs') => array(
				array(
					'type' => 'stages',
					'name' => 'stages'
				)
			),
			
			'variations:' . $shoptefy->lang('Variations') => array(
				array(
					'type' => 'variations',
					'name' => 'variations'
				)
			),

			'attributes:' . $shoptefy->lang('Attributes') => array(
				array(
					'type' => 'attributes',
					'name' => 'attributes'
				),
			)
		)
	);
	
	$fields = $shoptefy_admin->process_data($arg, 'products');
	
?>

<div class="shoptefy_wrapper" id="shoptefy-product-page">
	<div class="shoptefy_content">
		<?php

			$shoptefy->views->detail_header(array(
				'add' => $shoptefy->lang('Add New Product'),
				'edit' => $fields['tabs']['details:' . $shoptefy->lang('Details')][0]['value'],
				'page' => 'product'
			));

		?>
		<form action="<?php
			echo $shoptefy->cfg->admin_url;
		?>shoptefy-page=product<?php
			if (isset($_GET['callback']))
				echo '&callback='.$_GET['callback'];
		?>" id="shoptefy-product-form" method="POST" class="shoptefy_form" enctype="multipart/form-data">

			<?php $shoptefy->views->tabs_render($fields, 'products'); ?>

			<div class="shoptefy_form_group" style="margin-top: 20px">
				<input type="submit" class="shoptefy-button shoptefy-button-primary" value="<?php echo $shoptefy->lang('Save Product'); ?>"/>
				<input type="hidden" name="do" value="action" />
				<input type="hidden" name="shoptefy-section" value="product">
			</div>
		</form>
	</div>
</div>
