<?php
	$title = "Edit Design";

	$arr = Array ("name");
	$design = $shoptefy_admin->get_rows_custom($arr,'shoptefy_designs');

	if (isset($_GET['id'])) {
		$data = $shoptefy_admin->get_row_id($_GET['id'], 'shoptefy_designs');
	}

	if (!empty($_POST['save_design'])) {

		$data = array();
		$data_id = isset($_POST['id']) ? trim($_POST['id']) : '';
		$data['name'] = isset($_POST['name']) ? trim($_POST['name']) : '';
		$data['screenshot'] = isset($_POST['screenshot']) ? trim($_POST['screenshot']) : '';
		$data['sharing'] = isset($_POST['sharing']) ? $_POST['sharing'] : '';
		$data['active'] = isset($_POST['active']) ? $_POST['active'] : '';
		$data_name = isset($_POST['name_temp']) ? $_POST['name_temp'] : '';
		$errors = array();

		if (empty($data['name'])) {
			$errors['name'] = $shoptefy->lang('Please Insert Name.');
		} else {

			$data['name'] = trim($data['name']);
			if (is_array($design) && count($design) >0) {
				foreach ($design as $value) {
					if ($value['name'] == $data['name'] && $data['name'] != $data_name) {
						$errors['name'] = $shoptefy->lang('The name provided already exists.');
					}
				}
			}
			
		}

		if (!empty($data['sharing'])) {
			$data['sharing'] = 1;
		} else {
			$data['sharing'] = 0;
		}

		if (!empty($data['active'])) {
			$data['active'] = 1;
		} else {
			$data['active'] = 0;
		}

		$data['updated'] = date("Y-m-d").' '.date("H:i:s");
		
		if (count($errors) == 0) {

			if (!empty($data_id)) {
				$id = $shoptefy_admin->edit_row( $data_id, $data, 'shoptefy_designs' );
			} else {
				$id =$shoptefy_admin->add_row( $data, 'shoptefy_designs' );
			}
			$shoptefy_msg = array('status' => 'success');
			$shoptefy->connector->set_session('shoptefy_msg', $shoptefy_msg);

		} else {

			$shoptefy_msg = array('status' => 'error', 'errors' => $errors);
			$shoptefy->connector->set_session('shoptefy_msg', $shoptefy_msg);
			if (!empty($data_id)) {
				$shoptefy->redirect($shoptefy->cfg->admin_url . "shoptefy-page=design&id=".$data_id);
			} else {
				$shoptefy->redirect($shoptefy->cfg->admin_url . "shoptefy-page=design");
			}
			exit;

		}

		if (isset($id) && $id == true ) {
			$shoptefy->redirect($shoptefy->cfg->admin_url . "shoptefy-page=design&id=".$id);
			exit;
		}

	}

?>

<div class="shoptefy_wrapper">
	<div class="shoptefy_content">
		<div class="shoptefy_header">
			<?php

				if (isset($_GET['id'])) {
					echo '<h2>'.$shoptefy->lang('Edit Design').'</h2><a href="'.$shoptefy->cfg->admin_url.'shoptefy-page=design" class="add-new shoptefy-button">'.$shoptefy->lang('Add New Design').'</a>';
				} else {
					echo '<h2>'.$shoptefy->lang('Add Design').'</h2>';
				}
				$shoptefy_page = isset($_GET['shoptefy-page']) ? $_GET['shoptefy-page'] : '';
				echo $shoptefy_helper->breadcrumb($shoptefy_page); 

			?>
		</div>
		<?php 

			$shoptefy_msg = $shoptefy->connector->get_session('shoptefy_msg');
			if (isset($shoptefy_msg['status']) && $shoptefy_msg['status'] == 'error') { ?>
				
				<div class="shoptefy_message err">

					<?php foreach ($shoptefy_msg['errors'] as $val) {
						echo '<em class="shoptefy_err"><i class="fa fa-times"></i>  ' . $val . '</em>';
						$shoptefy_msg = array('status' => '');
						$shoptefy->connector->set_session('shoptefy_msg', $shoptefy_msg);
					} ?>

				</div>
				
			<?php }

			if (isset($shoptefy_msg['status']) && $shoptefy_msg['status'] == 'success') { ?>
				
				<div class="shoptefy_message"> 
					<?php
						echo '<em class="shoptefy_suc"><i class="fa fa-check"></i> '.$shoptefy->lang('Your data has been successfully saved').'</em>';
						$shoptefy_msg = array('status' => '');
						$shoptefy->connector->set_session('shoptefy_msg', $shoptefy_msg);
					?>
				</div>

			<?php }

		?>
		<form action="<?php echo $shoptefy->cfg->admin_url;?>shoptefy-page=design" method="post" class="shoptefy_form">
			<div class="shoptefy_form_group">
				<span><?php echo $shoptefy->lang('Name'); ?><em class="required">*</em></span>
				<div class="shoptefy_form_content">
					<input type="text" name="name" value="<?php echo !empty($data['name']) ? $data['name'] : '' ?>">
					<input type="hidden" name="name_temp" value="<?php echo !empty($data['name']) ? $data['name'] : '' ?>">
				</div>
			</div>
			<div class="shoptefy_form_group">
				<span><?php echo $shoptefy->lang('Screenshot'); ?></span>
				<div class="shoptefy_form_content">
					<textarea name="screenshot"><?php echo !empty($data['screenshot']) ? $data['screenshot'] : '' ?></textarea>
				</div>
			</div>
			<div class="shoptefy_form_group">
				<span><?php echo $shoptefy->lang('Sharing'); ?></span>
				<div class="shoptefy_form_content">
					<div class="shoptefy-toggle">
						<?php 
							$check = '';
							if (isset($data['sharing']) && $data['sharing'] == 1) {
								$check = 'checked';
							}
						?>
						<input type="checkbox" name="sharing" <?php echo $check; ?>>
						<span class="shoptefy-toggle-label" data-on="Yes" data-off="No"></span>
						<span class="shoptefy-toggle-handle"></span>
					</div>
				</div>
			</div>
			<div class="shoptefy_form_group">
				<span><?php echo $shoptefy->lang('Active'); ?></span>
				<div class="shoptefy_form_content">
					<div class="shoptefy-toggle">
						<?php 
							$check = '';
							if (isset($data['active']) && $data['active'] == 1) {
								$check = 'checked';
							}
						?>
						<input type="checkbox" name="active" <?php echo $check; ?>>
						<span class="shoptefy-toggle-label" data-on="Yes" data-off="No"></span>
						<span class="shoptefy-toggle-handle"></span>
					</div>
				</div>
			</div>
			<div class="shoptefy_form_group">
				<input type="hidden" name="id" value="<?php echo !empty($data['id']) ? $data['id'] : '' ?>"/>
				<input type="submit" class="shoptefy-button shoptefy-button-primary" value="<?php echo $shoptefy->lang('Save Design'); ?>"/>
				<input type="hidden" name="save_design" value="true">
			</div>
			<?php $shoptefy->securityFrom();?>
		</form>
	</div>
</div>
