<?php

//defines

if (!defined('TS'))
	define('TS', DIRECTORY_SEPARATOR);

if (!defined('shoptefy_ADMIN_PATH'))
    define('shoptefy_ADMIN_PATH', dirname(__FILE__));

if (!defined('shoptefy_ADMIN'))
    define('shoptefy_ADMIN', true);

date_default_timezone_set('UTC');

class shoptefy_router {

	protected $_action;
	protected $_load_assets;
	protected $_asset_uri;
	protected $_allow = false;
	protected $_is_ajax = false;
	protected $_shoptefy = false;
	protected $_shoptefy_page = false;
	protected $_cfg = false;
	protected $_admin_path;

	public $menus;
	public $check_update;

	public function __construct($shoptefy_page = '', $load_assets = true) {

        global $shoptefy;
        $this->_shoptefy = $shoptefy;
        $this->_admin_path = $shoptefy->cfg->root_path.'admin'.DS;

		$this->check_update = @json_decode($shoptefy->get_option('last_check_update'));
		$this->menus =  $shoptefy->apply_filters('admin_menus', array(
			'dashboard' => array(
				'title' => $shoptefy->lang('Dashboard'),
				'icon'  => '<i class="fa fa-home"></i>',
				'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=dashboard',
				'child'	=> array(
					'dashboard' => array(
						'title' => $shoptefy->lang('Home'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=dashboard',
					),
					'updates' => array(
						'title' => $shoptefy->lang('Updates').(!empty($this->check_update) && isset($this->check_update->version) && version_compare(shoptefy, $this->check_update->version, '<') ? ' <span class="update-notice">1</span>' : ''),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=updates',
					),
					'license' => array(
						'title' => $shoptefy->lang('License'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=license',
					),
					'system' => array(
						'title' => $shoptefy->lang('Status'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=system',
					)
				),
				'capability' => 'shoptefy_read_dashboard'
			),
			'products' => array(
				'title' => $shoptefy->lang('Products Base'),
				'icon'  => '<i class="fa fa-cube"></i>',
				'child' => array(
					'products'   => array(
						'type'   => '',
						'title'  => $shoptefy->lang('All Products Base'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=products',
						'hidden' => false,
					),
					'product' => array(
						'type'   => '',
						'title'  => $shoptefy->lang('Add New Product Base'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=product',
						'hidden' => false,
					),
					'categories' => array(
						'type'   => 'products',
						'title'  => $shoptefy->lang('Product Categories'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=categories&type=products',
						'hidden' => false,
					),
					'category' => array(
						'type'   => 'products',
						'title'  => $shoptefy->lang('Add New Category'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=category&type=products',
						'hidden' => true,
					),
				),
				'capability' => 'shoptefy_read_products'
			),
			'templates' => array(
				'title' => $shoptefy->lang('Design Templates'),
				'icon'  => '<i class="fa fa-paper-plane-o"></i>',
				'child' => array(
					'templates'   => array(
						'type'   => '',
						'title'  => $shoptefy->lang('All Templates'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=templates',
						'hidden' => false,
					),
					'template' => array(
						'type'   => '',
						'title'  => $shoptefy->lang('Add New Template'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=template',
						'hidden' => false,
					),
					'categories' => array(
						'type'   => 'templates',
						'title'  => $shoptefy->lang('Categories'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=categories&type=templates',
						'hidden' => false,
					),
					'category' => array(
						'type'   => 'templates',
						'title'  => $shoptefy->lang('Add New Category'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=category&type=templates',
						'hidden' => true,
					),
					'tags' => array(
						'type'   => 'templates',
						'title'  => $shoptefy->lang('Tags'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=tags&type=templates',
						'hidden' => false,
					),
					'tag' => array(
						'type'   => 'templates',
						'title'  => $shoptefy->lang('Add New Tag'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=tag&type=templates',
						'hidden' => true,
					),
				),
				'capability' => 'shoptefy_read_templates'
			),
			'cliparts' => array(
				'title' => $shoptefy->lang('Cliparts'),
				'icon'  => '<i class="fa fa-file-image-o"></i>',
				'child' => array(
					'cliparts'   => array(
						'type'   => '',
						'title'  => $shoptefy->lang('All Cliparts'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=cliparts',
						'hidden' => false,
					),
					'clipart' => array(
						'type'   => '',
						'title'  => $shoptefy->lang('Add New Clipart'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=clipart',
						'hidden' => false,
					),
					'categories' => array(
						'type'   => 'cliparts',
						'title'  => $shoptefy->lang('Categories'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=categories&type=cliparts',
						'hidden' => false,
					),
					'category' => array(
						'type'   => 'cliparts',
						'title'  => $shoptefy->lang('Add New Category'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=category&type=cliparts',
						'hidden' => true,
					),
					'tags' => array(
						'type'   => 'cliparts',
						'title'  => $shoptefy->lang('Tags'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=tags&type=cliparts',
						'hidden' => false,
					),
					'tag' => array(
						'type'   => 'cliparts',
						'title'  => $shoptefy->lang('Add New Tag'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=tag&type=cliparts',
						'hidden' => true,
					),
				),
				'capability' => 'shoptefy_read_cliparts'
			),
			'shapes' => array(
				'title' => $shoptefy->lang('Shapes'),
				'icon'  => '<i class="fa fa-cube"></i>',
				'child' => array(
					'shapes'   => array(
						'type'   => '',
						'title'  => $shoptefy->lang('All shapes'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=shapes',
						'hidden' => false,
					),
					'shape' => array(
						'type'   => '',
						'title'  => $shoptefy->lang('Add New Shape'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=shape',
						'hidden' => false,
					),
				),
				'capability' => 'shoptefy_read_shapes'
			),
			'printings' => array(
				'title' => $shoptefy->lang('Printing Type'),
				'icon'  => '<i class="fa fa-print"></i>',
				'child' => array(
					'printings'   => array(
						'type'   => '',
						'title'  => $shoptefy->lang('All Printing Type'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=printings',
						'hidden' => false,
					),
					'printing' => array(
						'type'   => '',
						'title'  => $shoptefy->lang('Add New Printing'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=printing',
						'hidden' => false,
					),
				),
				'capability' => 'shoptefy_read_printings'
			),
			'fonts' => array(
				'title' => $shoptefy->lang('Fonts'),
				'icon'  => '<i class="fa fa-font"></i>',
				'child' => array(
					'fonts'   => array(
						'type'   => '',
						'title'  => $shoptefy->lang('All Fonts'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=fonts',
						'hidden' => false,
					),
					'font' => array(
						'type'   => '',
						'title'  => $shoptefy->lang('Add New Font'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=font',
						'hidden' => false,
					),
				),
				'capability' => 'shoptefy_read_fonts'
			),
			'languages' => array(
				'title' => $shoptefy->lang('Languages'),
				'icon'  => '<i class="fa fa-language"></i>',
				'child' => array(
					'languages'   => array(
						'type'   => '',
						'title'  => $shoptefy->lang('Languages'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=languages',
						'hidden' => false,
					),
					'language' => array(
						'type'   => '',
						'title'  => $shoptefy->lang('Add Translate Text'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=language',
						'hidden' => false,
					),
				),
				'capability' => 'shoptefy_read_languages'
			),
			'orders' => array(
				'title' => $shoptefy->lang('Orders'),
				'icon'  => '<i class="fa fa-shopping-bag"></i>',
				'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=orders',
				'child' => array(
					'orders'   => array(
						'type'   => '',
						'title'  => $shoptefy->lang('All Orders'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=orders',
						'hidden' => false,
					),
					'order'   => array(
						'type'   => '',
						'title'  => $shoptefy->lang('Order'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=order',
						'hidden' => true,
					)
				),
				'capability' => 'shoptefy_read_orders'
			),
			'shares' => array(
				'title' => $shoptefy->lang('Shares'),
				'icon'  => '<i class="fa fa-share-alt"></i>',
				'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=shares',
				'capability' => 'shoptefy_read_shares'
			),
			'bugs' => array(
				'title' => $shoptefy->lang('Bugs'),
				'icon'  => '<i class="fa fa-bug"></i>',
				'child' => array(
					'bugs'   => array(
						'type'   => '',
						'title'  => $shoptefy->lang('All Bugs'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=bugs',
						'hidden' => false,
					),
					'bug' => array(
						'type'   => '',
						'title'  => $shoptefy->lang('Add New Bug'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=bug',
						'hidden' => false,
					),
				),
				'capability' => 'shoptefy_read_bugs'
			),
			'addons' => array(
				'title' => $shoptefy->lang('Addons'),
				'icon'  => '<i class="fa fa-plug"></i>',
				'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=addons',
				'child' => array(
					'explore-addons' => array(
						'type'   => '',
						'title'  => $shoptefy->lang('Explore'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=explore-addons',
					),
					'addons' => array(
						'type'   => '',
						'title'  => $shoptefy->lang('Installed'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=addons',
					),
					'addon' => array(
						'type'   => '',
						'title'  => $shoptefy->lang('Detail'),
						'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=addon',
						'hidden' => true,
					),
				),
				'capability' => 'shoptefy_read_addons',
			),
			'settings' => array(
				'title' => $shoptefy->lang('Settings'),
				'icon'  => '<i class="fa fa-cog"></i>',
				'link'   => $shoptefy->cfg->admin_url.'shoptefy-page=settings',
				'capability' => 'shoptefy_read_settings'
			),
		));

		$this->_load_assets = $load_assets;

		if (empty($shoptefy_page) && isset($_REQUEST['shoptefy-page']))
			$this->_shoptefy_page = $_REQUEST['shoptefy-page'];
		else
			$this->_shoptefy_page = 'dashboard';

		foreach ($this->menus as $key => $menu) {

			if ($key == $this->_shoptefy_page)
				$this->_allow = true;
			if (isset($menu['child']) && is_array($menu['child'])) {
				foreach ($menu['child'] as $k => $ch) {
					if ($k == $this->_shoptefy_page)
						$this->_allow = true;
				}
			}
		}

        if ((isset($_REQUEST['shoptefy_ajax']) && $_REQUEST['shoptefy_ajax'] == 1) || $_SERVER['REQUEST_METHOD'] =='POST')
            $this->_is_ajax = true;

		$this->check_caps();

	}

	public function check_caps () {

		global $shoptefy;
		$page = isset($_GET['shoptefy-page']) ? $_GET['shoptefy-page'] : '';

		$cap = (
			isset($this->menus[$page]) &&
			isset($this->menus[$page]['capability'])
		) ? $this->menus[$page]['capability'].'-s' : '';

		if ($cap == '') {
			foreach ($this->menus as $key => $val) {
				if (
					isset($this->menus[$key]['capability']) &&
					isset($val['child']) &&
					isset($val['child'][$page])
				)$cap = $this->menus[$key]['capability'].'-s';
			}
		}

		$cap = str_replace(array('s-s', '-s'), array('', ''), $cap);
		$cap2 = str_replace('_read_', '_edit_', $cap);
		$cap3 = str_replace('_read_', '_edit_', $cap.'s');

		if (
			!$shoptefy->caps($cap) &&
			!$shoptefy->caps($cap.'s') &&
			!$shoptefy->caps($cap2) &&
			!$shoptefy->caps($cap3)
		) $this->_allow = false;

	}

	public function update_notice() {

		global $shoptefy;
		$lpage = isset($_GET['shoptefy-page']) ? $_GET['shoptefy-page'] : '';

		if(
			$lpage != 'updates' &&
			$lpage != 'license' &&
			!empty($this->check_update) &&
			isset($this->check_update->version) &&
			version_compare(shoptefy, $this->check_update->version, '<')
		) {

		?>
		<div class="shoptefy_container">
			<div class="shoptefy-col shoptefy-col-12">
				<div class="shoptefy-update-notice top">
					<a href="https://www.shoptefy.com/changelogs/<?php echo $shoptefy->connector->platform; ?>?utm_source=client-site&utm_medium=text&utm_campaign=update-page&utm_term=links&utm_content=<?php echo $shoptefy->connector->platform; ?>" target=_blank>shoptefy <?php echo $this->check_update->version; ?></a>
					<?php echo $shoptefy->lang('is available'); ?>!
					<a href="<?php echo $shoptefy->cfg->admin_url; ?>shoptefy-page=updates"><?php echo $shoptefy->lang('Please update now'); ?></a>.
				</div>
			</div>
		</div>
		<?php

		}

	}

	public function display() {

		global $shoptefy_router, $shoptefy, $shoptefy_helper, $shoptefy_admin;

		$shoptefy->do_action('admin-verify');

		require_once($this->_admin_path.'admin.php');

        if(!isset($_POST['do']) && !isset($_POST['action_submit'])) {
            include($this->_admin_path . 'partials' .DS. 'header.php');
		}

		$page = $shoptefy->apply_filters('admin_page', $this->_admin_path . 'pages' .DS. $this->_shoptefy_page . '.php', $this->_shoptefy_page);

		if ($this->_allow && is_file($page)) {
			$this->update_notice();
			include($page);
		} else {
			echo '<div class="shoptefy_container">';
			echo '<div class="shoptefy-col shoptefy-col-12">';
			echo '<div class="shoptefy-update-notice top">';
			if (!$this->_allow && is_file($page))
				echo $shoptefy->lang('Sorry, you are not allowed to access this page.');
			else echo $shoptefy->lang('File not found').': <i>'.$page.'</i>';
			echo '</div>';
			echo '</div>';
			echo '</div>';
		}

        if(!isset($_POST['do'])) {
             include($this->_admin_path . 'partials' .DS. 'footer.php');
		}
	}

}

/*===================================*/

global $shoptefy_router;
$shoptefy_router = new shoptefy_router();
$shoptefy_router->display();
