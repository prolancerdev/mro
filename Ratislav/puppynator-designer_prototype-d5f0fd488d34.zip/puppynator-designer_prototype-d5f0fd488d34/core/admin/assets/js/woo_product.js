jQuery(document).ready(function($){
	
	let lightbox = function(ops) {

		if (ops == 'close') {
			$('body').css({overflow: ''});
			return $('#shoptefy-lightbox').remove();
		}
		
		var tmpl = '<div id="shoptefy-lightbox" class="shoptefy-lightbox" style="display:block">\
						<div id="shoptefy-lightbox-body">\
							<div id="shoptefy-lightbox-content" class="%class%" style="min-width:%width%px">\
								%content%\
							</div>\
							%footer%\
							<a class="kalb-close" href="#close" title="Close">\
								<i class="dashicons dashicons-no-alt"></i>\
							</a>\
						</div>\
						<div class="kalb-overlay"></div>\
					</div>',
			cfg = $.extend({
				width: 1000,
				class: '',
				footer: '',
				content: '',
				onload: function(){},
				onclose: function(){}
			}, ops);

		if (cfg.footer !== '')
			cfg.footer = '<div id="shoptefy-lightbox-footer">'+cfg.footer+'</div>';

		tmpl = $(tmpl.replace(/\%width\%/g, cfg.width).
					replace(/\%class\%/g, cfg.class).
					replace(/\%content\%/g, cfg.content).
					replace(/\%footer\%/g, cfg.footer));

		$('.shoptefy-lightbox').remove();
		$('body').append(tmpl).css({overflow: 'hidden'});

		cfg.onload(tmpl);
		tmpl.find('a.kalb-close,div.kalb-overlay').on('click', function(e){
			cfg.onclose(tmpl);
			$('.shoptefy-lightbox').remove();
			$('body').css({overflow: ''});
			e.preventDefault();
		});

	};

	
	/*
	* Show shoptefy configuration in variations
	*/
	
	$(document).on('click', (e) => {
		if (
			e.target.getAttribute('data-shoptefy-frame') || 
			e.target.parentNode.getAttribute('data-shoptefy-frame')
		) {
			
			let el = e.target.parentNode.getAttribute('data-shoptefy-frame') ? e.target.parentNode : e.target,
				fn = el.getAttribute('data-shoptefy-frame'),
				src = fn+'&nonce=shoptefy-SECURITY-BACKEND:'+shoptefyjs.nonce_backend,
				id = el.parentNode.getAttribute('data-id'),
				inp = window['variable-shoptefy-'+id],
				val = inp.value;
			
			
			if (fn == 'paste') {
				
				e.preventDefault();
				
				if (!localStorage.getItem('shoptefy-VARIATION-COPY'))
					return alert('Error, You must copy one config before pasting');
					
				$(inp).val(localStorage.getItem('shoptefy-VARIATION-COPY')).change();
				$('button#shoptefy-config-'+id).click().parent().attr('data-empty', 'false');
				
				return;	
				
			} else if (fn == 'clear') {
				
				e.preventDefault();
				
				if (confirm('Are you sure that you want to clear this config?')) {
					$(inp).val('').change();
					$(el).parent().attr('data-empty', 'true');
				};
				
				return;	
				
			} else if (fn == 'list') {
				
				e.preventDefault();
				
				load_product_bases(
					{
						'product_source': 'woo-variation'
					}, 
					{
						'can_create_new': false,
						'action_text': 'Select this config',
						'action_fn': (product) => {
							$(inp).val(product.shoptefy_data).change();
							$('button#shoptefy-config-'+id).click().parent().attr('data-empty', 'false');
						}
					}
				);
				
				return;	
				
			};
			
			$(el).before(
				'<iframe id="shoptefy-variation-'+id+'" name="shoptefy-variation-'+id+'" style="width: 100%;min-height:150px;border: none;" src="'+
					(val === '' ? src : '')+
				'"></iframe>'
			).closest('div.variable_shoptefy_data').attr('data-loading', 'Loading..').addClass('hasFrame');;
			
			if (val !== '') {
				
				let form = $('<form action="'+src+'" method="post" target="shoptefy-variation-'+id+'"><textarea name="data">'+val.replace(/\<textarea/g, '&lt;textarea').replace(/\<\/textarea\>/g, '&lt;/textarea&gt;')+'</textarea></form>');	
				
				$('body').append(form);
				
			    form.submit().remove();	
				
			}
			
			e.preventDefault();
		}
	});
	
});
