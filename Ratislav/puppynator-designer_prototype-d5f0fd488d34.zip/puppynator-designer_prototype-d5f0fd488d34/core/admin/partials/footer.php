<?php
	global $shoptefy;
?><script>
	var shoptefyDesign = {
		url : "<?php echo htmlspecialchars_decode($shoptefy->cfg->url); ?>",
		admin_url : "<?php echo htmlspecialchars_decode($shoptefy->cfg->admin_url); ?>",
		ajax : "<?php echo htmlspecialchars_decode($shoptefy->cfg->admin_ajax_url); ?>",
		assets : "<?php echo $shoptefy->cfg->assets_url; ?>",
		jquery : "<?php echo $shoptefy->cfg->load_jquery; ?>",
		nonce : "<?php echo shoptefy_secure::create_nonce('shoptefy_ADMIN') ?>",
		filter_ajax: function(ops) {
			return ops;
		},
		js_lang : <?php echo json_encode($shoptefy->cfg->js_lang); ?>,
	};
</script>
<script src="<?php echo $shoptefy->cfg->admin_assets_url;?>js/vendors.js?version=<?php echo shoptefy; ?>"></script>
<script src="<?php echo $shoptefy->cfg->admin_assets_url;?>js/tag-it.min.js?version=<?php echo shoptefy; ?>"></script>
<script src="<?php echo $shoptefy->cfg->admin_assets_url;?>js/jscolor.min.js?version=<?php echo shoptefy; ?>"></script>
<script src="<?php echo $shoptefy->cfg->admin_assets_url;?>js/main.js?version=<?php echo shoptefy; ?>"></script>
<?php

	$shoptefy->do_action('editor-footer');

	if ($shoptefy->connector->platform == 'php') {
		echo '</body></html>';
	}
?>
