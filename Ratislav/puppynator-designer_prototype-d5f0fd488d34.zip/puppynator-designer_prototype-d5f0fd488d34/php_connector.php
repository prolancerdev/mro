<?php

class shoptefy_connector {

    public $platform;
    public $config;

    protected $order_statuses;

    public function __construct() {

		global $shoptefy;

		if (empty($_COOKIE['shoptefySESSID'])
		) {
			$sessid = strtoupper(substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 20));
			@setcookie('shoptefySESSID', $sessid, time() + (86400 * 30), '/');
			$_COOKIE['shoptefySESSID'] = $sessid;
		}

        $this->platform = 'php';
        $url = $this->url(1);

        $order_statuses = array(
            'pending' => 'Pending',
            'complete' => 'Complete',
            'processing' => 'Processing',
            'cancel' => 'Cancel',
        );

        $this->config = array(
			"url" => $url,
			"tool_url" => $url.'editor.php',
			"logo" => $url. 'core/assets/images/logo.v3.png',
			"ajax_url" => $url.'editor.php?shoptefy-router=ajax',
			"admin_ajax_url" => $url.'editor.php?shoptefy-router=ajax',
            "checkout_url" => $url.'editor.php?shoptefy-router=cart',
			"assets_url" => $url.'core/',
			"load_jquery" => true,
			"root_path" => dirname(__FILE__).DS.'core'.DS,

            "upload_path" => '/var/www/shoptefy.com/app/public/data/',
			"upload_url" => 'https://app.shoptefy.com/data/',
            "admin_assets_url" => $url.'core/admin/assets/',
            "admin_url" => $url.'admin.php?',

			"database" => array(
                "host" => 'localhost',
                "user" => 'shoptefy',
                "pass" => 'x5Lvsy8P02gO',
                "name" => 'shoptefy',
                "prefix" => 'shoptefy_'
            )
		);

        if(isset($shoptefy)){
            $this->order_statuses = array(
                'pending' => $shoptefy->lang('Pending'),
                'complete' => $shoptefy->lang('Complete'),
                'processing' => $shoptefy->lang('Processing'),
                'cancel' => $shoptefy->lang('Cancel'),
            );
        }


        if(isset($shoptefy)){
            $shoptefy->add_action('admin-verify', array(&$this, 'admin_verify'));
            $shoptefy->add_action('before_order_products', array(&$this, 'update_order_status'));
            $shoptefy->add_action('before_orders', array(&$this, 'update_orders'));
    		$shoptefy->add_filter('order_status', array(&$this, 'order_status_name'));
        }
    }

    public function url($f = 0) {

	    global $shoptefy;

	    if ($f === 0)
	    	$uri = '';
	    else if ($f === 1)
	    	$uri = (dirname($_SERVER['SCRIPT_NAME']) == '/')? '/' : dirname($_SERVER['SCRIPT_NAME']).'/';
	    else $uri = $_SERVER['REQUEST_URI'];

	    $scheme = 'http';

	    if (
		    (isset($_SERVER['HTTP_CF_VISITOR']) && isset($_SERVER['HTTP_CF_VISITOR']->scheme) && $_SERVER['HTTP_CF_VISITOR']->scheme == 'https') ||
		    (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') ||
		    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') ||
		    $_SERVER['SERVER_PORT'] == 443
	    ) $scheme = 'https';

		return $scheme."://".$_SERVER['HTTP_HOST'].$uri;

	}


	public function admin_verify() {

		if (isset($_POST['nonce']))
			$this->process_login();

		if (isset($_POST['reset-token']))
			$this->process_reset();

		if (!$this->is_admin()) {

			include 'login.php';
			exit;
		} else if (isset($_GET['signout']) && $_GET['signout'] == 'true') {
			$this->process_logout();
		}

	}

	public function process_login() {

		global $shoptefy;
		$action = isset($_POST['action']) ? $_POST['action'] : '';
		$redirect = isset($_POST['redirect']) && !empty($_POST['redirect']) ? $_POST['redirect'] : $this->config->url.'?shoptefy-router=admin';
		$msg = array();
		$nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
		$limit = $this->get_session('LIMIT');

		if ($limit[0] >= 5 && time()-$limit[1] < 60*60) {
			header('location:'.urldecode($redirect));
			exit;
		}

		$admin_email = $shoptefy->get_option('admin_email');

		$email = $_POST['email'];
		$password = $_POST['password'];

		if ($limit === null || !is_array($limit) || time()-$limit[1] > 60*60)
			$limit = array(0, time());

        $check = shoptefy_secure::check_nonce('LOGIN-SECURITY', $nonce);
		if (!$check) {
			$limit[0] += 1;
			$limit[1] = time();
			array_push($msg, array(
				'type' => 'error',
				'content' => $shoptefy->lang('Invalid login token').', '.$limit[0].' '.$shoptefy->lang('failed login attempts.')
			));
		}else
		if ($action == 'login') {

			if (!isset($admin_email) || empty($admin_email)) {
				$limit[0] += 1;
				$limit[1] = time();
				array_push($msg, array(
					'type' => 'error',
					'content' => $shoptefy->lang('The admin account has not been setup').', '.$limit[0].' '.$shoptefy->lang('failed login attempts.')
				));
			}else{

				if (empty($email)) {
					array_push($msg, array(
						'type' => 'error',
						'content' => $shoptefy->lang('Your email is empty')
					));
				}
				else if (empty($password)) {
					array_push($msg, array(
						'type' => 'error',
						'content' => $shoptefy->lang('Your password is empty')
					));
				}
				else if ($admin_email != $email || $shoptefy->get_option('admin_password', '') != md5($password)) {
					array_push($msg, array(
						'type' => 'error',
						'content' => $shoptefy->lang('Your email or password is incorrect')
					));
				}

				if (count($msg) > 0) {
					$limit[0] += 1;
					$limit[1] = time();
					$msg[count($msg)-1]['content'] .= ', '.$limit[0].' '.$shoptefy->lang('failed login attempts.');
				}else{
					$this->set_session('UID', $email);
					$this->set_session('ROLE', 1);
					header('location:'.urldecode($redirect));
					exit;
				}
			}

		}else
		if ($action == 'setup') {

			if (!isset($admin_email) || empty($admin_email)) {

				$password2 = $_POST['password2'];

				if (strpos($email, '@') === false || strpos($email, '.') === false) {
					array_push($msg, array(
						'type' => 'error',
						'content' => $shoptefy->lang('Your email is invalid')
					));
				}

				if (strlen($password) < 8) {
					array_push($msg, array(
						'type' => 'error',
						'content' => $shoptefy->lang('Your password must be at least 8 characters')
					));
				}

				if ($password != $password2) {
					array_push($msg, array(
						'type' => 'error',
						'content' => $shoptefy->lang('Repeat passwords do not match')
					));
				}

				if (count($msg) === 0) {
					$shoptefy->set_option('admin_email', $email);
					$shoptefy->set_option('admin_password', md5($password));
					$this->set_session('UID', $email);
					$this->set_session('ROLE', 1);
					header('location:'.urldecode($redirect));
					exit;
				}

			}else{
				$limit[0] += 1;
				$limit[1] = time();
				array_push($msg, array(
					'type' => 'error',
					'content' => $shoptefy->lang('The admin account has been setup').', '.$limit[0].' '.$shoptefy->lang('failed login attempts.')
				));
			}
		}else
		if ($action == 'reset') {

			if (
				!isset($_POST['password']) ||
				empty($_POST['password']) ||
				empty($_POST['password2']) ||
				$_POST['password'] != $_POST['password2'] ||
				strlen($_POST['password']) < 8
			) {
				array_push($msg, array(
					'type' => 'error',
					'content' => $shoptefy->lang('Passwords do not match or less than 8 characters')
				));
				$this->set_session('login-msg', $msg);
			} else {
				$shoptefy->set_option('admin_password', md5(trim($_POST['password'])));
				array_push($msg, array(
					'type' => 'success',
					'content' => $shoptefy->lang('Your password has been changed successfully')
				));
				$this->set_session('login-msg', $msg);
				header('location:'.$shoptefy->cfg->admin_url.'ref=reset');
				exit;
			}

		}else{
			$limit[0] += 1;
			$limit[1] = time();
			array_push($msg, array(
				'type' => 'error',
				'content' => $shoptefy->lang('Invalid action').', '.$limit[0].' '.$shoptefy->lang('failed login attempts.')
			));
		}

		$this->set_session('LIMIT', $limit);
		$this->set_session('login-msg', $msg);

		if ($limit[0] >= 5 && time()-$limit[1] < 60*60) {
			header('location:'.urldecode($redirect));
			exit;
		}

	}

	public function process_logout() {

		global $shoptefy;

		$this->set_session('UID', null);
		$this->set_session('ROLE', null);

		header('location:'.$shoptefy->cfg->admin_url.'ref=signout');

	}

	public function process_reset() {

		global $shoptefy;

		$nonce = isset($_POST['reset-token']) ? $_POST['reset-token'] : '';
		$limit = $this->get_session('LIMIT');
		$email = $_POST['email'];
		$msg = array();

		if ($limit === null || !is_array($limit) || time()-$limit[1] > 60*60)
			$limit = array(0, time(), 0, time());

		if (!shoptefy_secure::check_nonce('RESET-SECURITY', $nonce)) {
			$limit[2] += 1;
			$limit[3] = time();
			array_push($msg, array(
				'type' => 'error',
				'content' => $shoptefy->lang('Invalid reset token').', '.$limit[0].' '.$shoptefy->lang('failed reset attempts.')
			));
		}else{
			if ($limit[2] >= 5 && time()-$limit[3] < 60*60) {
				array_push($msg, array(
					'type' => 'error',
					'content' => $shoptefy->lang('You have failed reseting for 5 times. For the security, please try again in ').round(60-((time()-$limit[3])/60)).' '.$shoptefy->lang('minutes')
				));
			}else if ($shoptefy->get_option('admin_email', '') != $email) {
				if ($limit[2] < 5)
					$limit[2] += 1;
				else $limit[2] = 1;
				$limit[3] = time();
				array_push($msg, array(
					'type' => 'error',
					'content' => $shoptefy->lang('The email does not exist').', '.$limit[2].' '.$shoptefy->lang('failed reset attempts.')
				));
			}else{

				$token = $shoptefy->generate_id();
				$shoptefy->set_option('reset_token', $token);
				$shoptefy->set_option('reset_expires', time()+(60*10));


				$to      =  $shoptefy->cfg->settings['admin_email'];
				$subject = 'shoptefy - Reset control panel password';
				$message = "Please click to the link bellow to reset your password.\nThis link will expire within 10 minutes.\n".
					   $shoptefy->cfg->admin_url."reset-password=".$token;
				$message = wordwrap($message,70);
				$url = parse_url($shoptefy->cfg->url);
				$headers = 'From: no-reply@'.$url['host'] . "\r\n" .
				    'Reply-To: no-reply@'.$url['host'] . "\r\n" .
				    'X-Mailer: PHP/' . phpversion();

				if (mail($to, $subject, $message, $headers)) {
					$limit[2] = 0;
					$limit[3] = time();
					unset($_POST['action']);
					array_push($msg, array(
						'type' => 'success',
						'content' => $shoptefy->lang('A reset email has been sent, please check your inbox (including spam box)')
					));
				}else if (mail($to, $subject, $message, $headers)) {
					$limit[3] = time();
					array_push($msg, array(
						'type' => 'error',
						'content' => $shoptefy->lang('Could not send mail, ensure that the mail() function on your webserver can work')
					));
				}
			}
		}

		$this->set_session('LIMIT', $limit);
		$this->set_session('login-msg', $msg);

	}

    public function get_session($name) {
        return isset($_SESSION[$name]) ? $_SESSION[$name] : null;
    }

    public function set_session($name, $value) {
        $_SESSION[$name] = $value;
    }

    public function cookie($name) {
        return isset($_COOKIE[$name]) ? $_COOKIE[$name] : $_COOKIE['shoptefySESSID'] . $name;
    }

    public function is_admin() {

		// return user is admin

		global $shoptefy;

		return ($this->get_session('ROLE') === 1 && $this->get_session('UID') !== null);

	}

	public function is_login() {

		// return user id, 0 if not login

		global $shoptefy;
		return $shoptefy->connector->cookie('uid') || 0;

	}

    public function get_currency() {
        return "$";
    }

    public function filter_product($data) {

        return $data;

    }

    public function filter_products($products) {

		return $results;

    }

	public function add_to_cart($data){

		global $shoptefy;
    	return $shoptefy->cfg->editor_url.'cart.php';

	}

    public function save_order(){

		global $shoptefy;
		$db = $shoptefy->get_db();

		$cart_data = $this->get_session('shoptefy_cart');

		$date = @date ("Y-m-d H:i:s");

        $guest_data = array(
            'name' => $_POST['first_name'] . ' ' . $_POST['last_name'],
            'email' => $_POST['email'],
            'address' => $_POST['address'],
            'zipcode' => $_POST['zip'],
            'city' => $_POST['city'],
            'country' => $_POST['country'],
            'phone' => $_POST['phone'],
            'created' => $date,
            'updated' => $date
        );

        $guest_id = $db->insert ('guests', $guest_data);

        $order_data = array(
			'total' => $cart_data['total'],
			'status' => 'pending',
			'currency' => $shoptefy->cfg->settings['currency'],
			'user_id' => $guest_id,
            'payment' => $_POST['payment'],
            'txn_id' => '',
			'created' => $date,
			'updated' => $date
		);

		$order_id = $db->insert ('orders', $order_data);

        $order = $this->get_session('shoptefy_cart');

        $order['user'] = $guest_data;
        $order['created'] = $date;
        $order['id'] = $order_id;
        $order['payment'] = $_POST['payment'];
        $order['status'] = 'pending';

        $order_data['id'] = $order_id;

        $this->set_session('shoptefy_justcheckout', $order);

        $cart_data = $this->get_session('shoptefy_cart');

		$store = $shoptefy->lib->store_cart($order_id, $cart_data);

        if (!$store)
        	return $store;

        $data = array(
            'order_id' => $order_id,
            'order_data' => $order_data,
            'user_data' => $guest_data,
        );

		return $data;

	}

	public function orders($filter, $orderby, $ordering, $limit, $limit_start) {

		global $shoptefy;
        $db = $shoptefy->get_db();


		$ops = $db->prefix . 'order_products';
		$os = $db->prefix . 'orders';

		$where = '';

		if (is_array($filter) && isset($filter['keyword']) && !empty($filter['keyword'])) {

            $where = array();
            $fields = explode(',', $filter['fields']);
            $arr_keyword = array();
            for ($i = 0; $i < count($fields); $i++) {
                $arr_keyword[] = sprintf(" %s LIKE '%s' ", $fields[$i], $filter['keyword']);
            }

            $fields = implode(' OR ', $arr_keyword);

            $where[] = $fields;

            if (count($where) > 0)
                $where = (count($where) > 0) ? ' WHERE ' . implode(' AND ', $where) : '';
        }


		$orderby_str = '';
        if ($orderby != null && $ordering != null)
            $orderby_str = ' ORDER BY ' . $orderby . ' ' . $ordering;

		$sql = "SELECT SQL_CALC_FOUND_ROWS "
		. " os.*, os.id as order_id "
		. " FROM $ops as ops "
		. " INNER JOIN $os as os ON os.id = ops.order_id"
		. $where
		. " GROUP BY ops.order_id "
		. $orderby_str
		. " LIMIT $limit_start, $limit";

		$items['rows'] = $db->rawQuery($sql);

		$sql = "SELECT FOUND_ROWS() as total";

        $total_count = $db->rawQuery($sql);

        $items['total_count'] = $total_count[0]['total'];

        if($limit != null)
        	$items['total_page'] = ceil($total_count[0]['total'] / $limit) ;
        else $items['total_page'] = 1;

        return $items;
	}

	public function redirect($url) {

		if (empty($url))
			return;

		ob_clean();

		@header("location: " . $url);
		exit;

	}

	public function products_order($order_id, $filter, $orderby, $ordering){

		global $shoptefy;

        $db = $shoptefy->get_db();

		$items = array('rows' => array());

		$ops = $db->prefix . 'order_products';
		$os = $db->prefix . 'orders';
		$usertb = $db->prefix . 'guests';

		$where = array();

		$where[] = 'ops.order_id = '. $order_id;

		if (is_array($filter) && isset($filter['keyword']) && !empty($filter['keyword'])) {

			$fields = explode(',', $filter['fields']);
			$arr_keyword = array();
			for ($i = 0; $i < count($fields); $i++) {
				$arr_keyword[] = sprintf(" %s LIKE '%s' ", $fields[$i], $filter['keyword']);
			}

			$fields = '(' . implode(' OR ', $arr_keyword) . ')';

			$where[] = $fields;

		}


		$orderby_str = '';
		if ($orderby != null && $ordering != null)
			$orderby_str = ' ORDER BY ' . $orderby . ' ' . $ordering;

		$sql = "SELECT "
			. "SQL_CALC_FOUND_ROWS *"
			. " FROM $ops as ops "
			. ' WHERE '. implode(' AND ', $where)
			. ' GROUP BY ops.id '
			. $orderby_str;

		$items['rows'] = $db->rawQuery($sql);

		$sql = "SELECT FOUND_ROWS() as total";

        $total_count = $db->rawQuery($sql);

        $items['total_count'] = $total_count[0]['total'];
        $items['total_page'] = 1;

		//get order data
		$sql = "SELECT "
			. "*"
			. " FROM $os as os "
			. ' WHERE id = '. $order_id;


		$order = $db->rawQuery($sql);
        $user = array();
        //get order data
        if(isset($order[0]['user_id'])){
            $sql = "SELECT "
    			. "*"
    			. " FROM $usertb as user "
    			. ' WHERE id = '. $order[0]['user_id'];

            $user = $db->rawQuery($sql);
        }
		$items['billing'] = (count($user)>0)? $user[0] : array();

        if(count($items['billing'])>0){
            $items['billing']['address'] = $items['billing']['address'].
            ', '.
            $items['billing']['city'].
            ', '.
            $items['billing']['country'];
        }

		$items['order'] = $order[0];

		return $items;
	}

    public function update_orders(){

        if(isset($_REQUEST['action'])){

            global $shoptefy;
            $id = $_REQUEST['id'];

            switch (trim($_REQUEST['action'])) {

                case 'delete':

                    $shoptefy->lib->delete_row($id, 'orders');
                    $shoptefy->lib->delete_order_products($id);
                    $shoptefy_msg = array(
                        'status' => 'success',
                        'msg' => sprintf($shoptefy->lang('Order #%s deleted.'), $id)
                    );
        			$shoptefy->connector->set_session('shoptefy_msg', $shoptefy_msg);
                    $shoptefy->redirect($shoptefy->cfg->admin_url.'shoptefy-page=orders');
                    break;

                default:

                    break;
            }
        }
    }

    public function update_order_status($order_id){

        if(isset($_POST['order_status'])){
            global $shoptefy;

            $db = $shoptefy->get_db();
            $db->where ('id', $order_id)->update ('orders', array(
                'status' => $shoptefy->lib->sql_esc($_POST['order_status']),
                'updated' => @date ("Y-m-d H:i:s")
            ));
        }
    }

    public function statuses(){
        return $this->order_statuses;
    }

    public function order_status_name($status){
        return isset($this->order_statuses[$status]) ? $this->order_statuses[$status] : $status;
    }

	public function update() {

		global $shoptefy;

		$shoptefy_path = dirname(__FILE__);
		$update_path = $shoptefy->cfg->upload_path.'tmpl'.DS.'shoptefy';
		$backup_path = $shoptefy->cfg->upload_path.'update_backup';

		$shoptefy->lib->delete_dir($backup_path);

		$connector_content = @file_get_contents($update_path.DS.'php_connector-sample.php');

		if (!empty($connector_content)) {

			$connector_content = str_replace(array(
				'/var/www/shoptefy.com/app/public/data/',
				'https://app.shoptefy.com/data/',
				'localhost',
                'shoptefy',
                'x5Lvsy8P02gO',
                'shoptefy',
                'shoptefy_'
			), array(
				$this->config['upload_path'],
				$this->config['upload_url'],
				$this->config['database']['host'],
				$this->config['database']['user'],
				$this->config['database']['pass'],
				$this->config['database']['name'],
				$this->config['database']['prefix']
			), $connector_content);

			@file_put_contents($update_path.DS.'php_connector.php', $connector_content);

			/*
			*	Start replace files
			*/

			$dir = @opendir($update_path);
			$err = 0;

		    while (false !== ($file = @readdir($dir))) {

		        if ($file != '.' && $file != '..') {

			        if (is_dir($update_path.DS.$file)) {

			            if (is_dir($shoptefy_path.DS.$file))
			            	$shoptefy->lib->delete_dir($shoptefy_path.DS.$file);

			            $err += (@rename($update_path.DS.$file, $shoptefy_path.DS.$file) ? 0 : 1);

			        } else if (is_file($update_path.DS.$file)) {

				    	if (is_file($shoptefy_path.DS.$file))
				    		$err += (@unlink($shoptefy_path.DS.$file) ? 0 : 1);

				    	$err += (@rename($update_path.DS.$file, $shoptefy_path.DS.$file) ? 0 : 1);

			        }
		        }
		    }

			return $err === 0 ? true : false;

		}

		return false;
	}

}
