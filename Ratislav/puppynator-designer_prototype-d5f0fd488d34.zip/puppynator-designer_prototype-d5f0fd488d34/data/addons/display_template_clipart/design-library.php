<?php 
require('autoload.php');
include(theme('header.php'));
?>
<div id="lumise_template_clipart_list" per_page="30" left_column="true" columns="4" search="true"></div>
<?php
include(theme('footer.php'));

