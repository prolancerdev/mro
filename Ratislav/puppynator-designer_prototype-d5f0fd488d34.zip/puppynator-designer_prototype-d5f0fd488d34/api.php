<?php
    
require('autoload.php');

global $shoptefy;

if ($shoptefy->connector->platform == 'php') {
    $shoptefy->do_action('api_request');
}
