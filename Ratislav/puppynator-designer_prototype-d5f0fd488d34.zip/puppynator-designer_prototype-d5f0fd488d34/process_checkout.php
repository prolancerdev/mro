<?php 
	
require('autoload.php');
global $shoptefy, $shoptefy_helper;

if(isset($_POST['action'])){
    
    $data = $shoptefy->connector->save_order();
	    
    if(isset($data['order_id'])){
		//add action before redirect for process payment.
		$shoptefy_helper->process_payment($data['order_data']);
        $shoptefy_helper->redirect($shoptefy->cfg->url. 'success.php?order_id='. $data['order_id']);
    } else {
	    print_r($data);
	    return;
    }
}
$shoptefy_helper->redirect($shoptefy->cfg->url. 'checkout.php');
