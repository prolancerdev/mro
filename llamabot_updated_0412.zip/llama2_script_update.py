import pandas as pd
from torch import cuda, bfloat16
from langchain import PromptTemplate
import transformers
from langchain.llms import HuggingFacePipeline
from utils import *
import re
import time
import os

import constants


def format_sample_prompt_from_column(index):

    formatted_string = ""

    for i, text in enumerate(constants.context):
        formatted_string = formatted_string + "Context:" + text + "\n"
        formatted_string = formatted_string + "Question:"
        question = constants.questions[index]

        formatted_string += question
        formatted_string += "\nAnswer:"
        formatted_string += constants.answers[i][index]
        formatted_string += "\n"

    return formatted_string


def get_possible_answers_from_column(index):

    return constants.possible_answers[index]


model_id = 'meta-llama/Llama-2-70b-chat-hf'

device = f'cuda:{cuda.current_device()}' if cuda.is_available() else 'cpu'

# set quantization configuration to load large model with less GPU memory
# this requires the `bitsandbytes` library
bnb_config = transformers.BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type='nf4',
    bnb_4bit_use_double_quant=True,
    bnb_4bit_compute_dtype=bfloat16
)

# begin initializing HF items, need auth token for these
hf_auth = ''
model_config = transformers.AutoConfig.from_pretrained(
    model_id,
    use_auth_token=hf_auth
)

model = transformers.AutoModelForCausalLM.from_pretrained(
    model_id,
    trust_remote_code=True,
    config=model_config,
    quantization_config=bnb_config,
    device_map='auto',
    use_auth_token=hf_auth
)
model.eval()
print(f"Model loaded on {device}")

tokenizer = transformers.AutoTokenizer.from_pretrained(
    model_id,
    use_auth_token=hf_auth
)

generate_text = transformers.pipeline(
    model=model, tokenizer=tokenizer,
    return_full_text=True,  # langchain expects the full text
    task='text-generation',
    # we pass model parameters here too
    temperature=0.0,  # 'randomness' of outputs, 0.0 is the min and 1.0 the max
    max_new_tokens=512,  # mex number of tokens to generate in the output
    repetition_penalty=1.1  # without this output begins repeating
)

llm = HuggingFacePipeline(pipeline=generate_text)


# Import all data from csv file:
filepath = "data.csv"
df = pd.read_csv(filepath, keep_default_na=False)[:200]
df = df.drop(['[CHECK] Other notes'], axis=1)


# Extract check and context questions
content_questions = list(df.columns[5:16])

# Extract texts, weblink and titles
texts = list(df["Article content"])

possible_answers = ""

B_INST, E_INST = "[INST]", "[/INST]"
B_SYS, E_SYS = "<<SYS>>\n", "\n<</SYS>>\n\n"

format_instructions = "You will be provided all the possible answers separated by the character '|' Do not write any other text\n The possible answers are as follows:\n {possible_answers}\nI will give you a text I will give you a text, ask a a questions about it and then you will provide a response."

sample_prompt = "{prompt_sample}"

system_prompt = B_INST + B_SYS + \
    """You are a mexican journalist.\nI will give you a context, ask a question about it and then you will provide a response.\nUse the following instructions for your response:\n""" + \
    format_instructions + """\n""" + E_SYS


user_prompt = """Context:{text}
Question:{question}
Answer:
"""


full_prompt = system_prompt + sample_prompt + \
    user_prompt + "\n\n" + E_INST


content_answers = []

# Max number of retries for a single prompt
attempt_limits = 10

# Main loop, each iteration picks a row in the dataset and sends request to Llama2 model
with open('output.txt', 'a') as file:
    for i, text in enumerate(texts):
        print("Text is as follows", file=file)
        print(text, file=file)
        print("Answers are as follows", file=file)
        long_result = ""
        for index, quiz in enumerate(constants.questions):

            possible_answers = get_possible_answers_from_column(index)
            prompt_sample = format_sample_prompt_from_column(index)
            # Send prompt about content questions
            prompt = PromptTemplate(template=full_prompt, input_variables=[
                                    "possible_answers", "prompt_sample", "text", "question"])

            result = llm(prompt.format(possible_answers=possible_answers,
                                       prompt_sample=prompt_sample, text=text, question=quiz)).replace("\n", "")

            if len(long_result) == 0:
                long_result = long_result + result
            else:
                long_result = long_result + "," + result
            # Wait 0.2 seconds before new prompt

            time.sleep(0.2)

        content_answers.append(long_result)
        print("This is answers separted by ,")
        print(long_result, file=file)

        print("\n", file=file)
# formatted_answers = []
# for content_answer in content_answers:
#     co = format_answers(content_answer)
#     formatted_answers.append(co)

# answer_df = pd.DataFrame()
# for i in range(len(content_questions)):
#     topic_name = re.search(r"\[(.+)\]", content_questions[i]).group(1)
#     answer_df[f"Q{i+1}-{topic_name}-ORIGINAL"] = df[content_questions[i]
#                                                     ].iloc[0:len(content_answers)]
#     answer_df[f"Q{i+1}-{topic_name}-LLAMA2"] = [formatted_answers[j][i]
#                                                 for j in range(len(content_answers))]


# answer_df = post_processing(answer_df)

# answer_df.to_csv("answer_table_all_questions.csv", index=False)
