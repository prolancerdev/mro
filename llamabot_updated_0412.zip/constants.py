context = [
    """"Secciones Lo mÃ¡s leÃ­do Â¿No tienes cuenta? Â¿Ya eres usuario? O conÃ©ctate con Por YazmÃ­n FerreyraMÃ©xico.- Un nuevo tÃºnel fue descubierto al interior delÂ cereso de la ciudad de Uruapan por el cual pretendÃ­an escapar varios reos. Este es el tercer tÃºnel descubierto por las autoridades de seguridad del estado en menos de dos meses en el mismo penal considerado de mediana seguridad El orificio tenia 58 metros de longitud por dos metros de diÃ¡metro, estaba equipado con energÃ­a elÃ©ctrica y un sistema de ventilaciÃ³n. SegÃºn informaciÃ³n de la SecretarÃ­a de Seguridad PÃºblica el hallazgo ocurriÃ³ cuando personal de custodia realizaba una revisiÃ³n en la zona y fueron descubiertos al menos 15 presos que realizaban excavaciones en el lugar Se informÃ³ que los internos sorprendidos se encuentran procesados por los delitos de secuestro y homicidio Tras el hallazgo, las autoridades sellaron el tÃºnel y reforzaron la seguridad en la cÃ¡rcel local. Hay que recordar que los dÃ­as 7 y 21 de diciembre pasado fueron localizados dos tÃºneles; uno de 5 metros de longitud y el otro de 8 metros  Escucha la radio en vivo Elige una ciudad Caracol Radio      ProgramaciÃ³n Ãšltimo Corte Informativo Ciudades Elige una ciudad Caracol Radio Compartir 
Copiar
"
""",
    """"Recordar mi usuario Â¿Olvidaste tu contraseÃ±a? Consulta la ediciÃ³n digital y contenidos exclusivos. SÃ© parte de El Economista Club y de la biblioteca virtual Leader Summaries. Disfruta de nuestras promociones.  
									BogotÃ¡.- La capital colombiana se transformarÃ¡ desde este viernes en una gigantesca carpa que aglutinarÃ¡ las mÃ¡s importantes manifestaciones de las artes escÃ©nicas del mundo, en el XIII Festival Iberoamericano de Teatro de BogotÃ¡ (FITB), que durarÃ¡ hasta el 8 de abril. 
 
 La ""Fiesta de las mil caras"", como se le ha denominado a esta ediciÃ³n del Festival que se realiza cada dos aÃ±os en BogotÃ¡, 
reunirÃ¡ a 63 compaÃ±Ã­as internacionales de 32 paÃ­ses de cinco continentes y a mÃ¡s de 180 grupos colombianos, indicaron los organizadores. 
 
 Un total de 22 salas, 11 parques, tres centros comunitarios, un centro comercial, la plaza de toros, un coliseo deportivo y un teatro al aire libre serÃ¡n los escenarios en los cuales 2.000 artistas entregarÃ¡n lo mejor de su repertorio en cerca de 1.000 funciones, a las cuales se espera asistan un millÃ³n de espectadores. 
 
 A ello se suma el complejo de la CorporaciÃ³n de Ferias y Exposiciones (Corferias) que se convertirÃ¡ en una gran Ciudad Teatro, en donde ademÃ¡s de espectÃ¡culos callejeros, stand up comedy y narradores orales de JapÃ³n, Egipto, EspaÃ±a, MÃ©xico y Chile, se podrÃ¡n encontrar obras especialmente dedicadas a niÃ±os y jÃ³venes. 
 
 La rumba tambiÃ©n tendrÃ¡ su espacio en la carpa cabaret, localizada en Corferias, en donde todas las noches las mejores agrupaciones colombianas pondrÃ¡n a bailar a los cientos de artistas y turistas que llegan a BogotÃ¡ para la ocasiÃ³n. 
 
 La programaciÃ³n al aire libre del Festival contempla la presentaciÃ³n de 18 obras colombianas, ocho internacionales, 13 comparsas, tres bandas de marcha y mÃ¡s de 2,000 personajes entre actores, acrÃ³batas, zanqueros, clowns y bailarines. 
 
 Seis grandes montajes llegan este aÃ±o a BogotÃ¡: ""VoalÃ¡"" de EspaÃ±a, ""Tom Tom Crew"" y ""Cantina"" de Australia, ""Los ciegos"" de Polonia, ""La Puerta de la Ley"" de Alemania, ""Leonardo, Estudio PrÃ¡ctico No. 1"" de Argentina y la sÃºper Big Band ""Sing! Sing! Sing!"" de EspaÃ±a. 
 
 Rumania es el paÃ­s invitado especial a la ediciÃ³n XIII del FITB, que traerÃ¡ como uno de sus principales exponentes al destacado director Silviu Purcarete, con la obra ""Esperando a Godot"". 
 
 Rumania presentarÃ¡ tambiÃ©n la obra ""Electra"" del Teatro Nacional Radu Stanca de Sibiu, bajo la direcciÃ³n de Mihai Maniutiu, y ""Leonce y Lena"", del Teatro Cluj, con la direcciÃ³n de GÃ¡bor Tompa. 
 
 Entre homenajes, adaptaciones literarias y clÃ¡sicos de teatro, se destacan obras como ""1984"", de The Actor's Gang de Estados Unidos, con la direcciÃ³n de Tim Robbins; ""La luna luna"", montaje de la compaÃ±Ã­a alemana Ton Und Kirschen, dirigida por David Johnston y Margarete Biereye y, ""Lo que pasÃ³ cuando Nora dejÃ³ a su marido"", a cargo del Teatro Nacional de Praga, con direcciÃ³n de Michal Docekal. 
 
 TambiÃ©n estarÃ¡n ""Donka, una carta a Chejov"", de la compaÃ±Ã­a suiza Finzi Pasca y Chekhov International Theatre Festival, bajo la direcciÃ³n de Daniele Finzi Pasca; y ""Hamlet"" de la compaÃ±Ã­a Street Theatre Troupe, de Corea del Sur. 
 
 Por JapÃ³n participarÃ¡ la compaÃ±Ã­a Shizuoka Performing Arts Center, con la obra ""Peer Gynt"", con la direcciÃ³n de Satoshi Miyagi, en tanto que por Francia estarÃ¡n presentes, entre otras, la compaÃ±Ã­a Productions IllimitÃ©es y Compagnie des Indes, con ""Cocorico"". 
 
 Entre las producciones colombianas destacan ""PersecuciÃ³n y asesinato de Jean-Paul Marat"", del Teatro Libre que dirige Ricardo Camacho; ""La Tempestad"", a cargo del teatro Varasanta, con la direcciÃ³n de Piotr Borowsky y ""Las danzas privadas"", del Teatro Matacandelas, dirigido por CristÃ³bal PelÃ¡ez. 
 
 BVC Archivado en: 
Por JosÃ© Antonio Rivera
 
														Por Jorge Monroy 
														Por Lourdes Flores 
														Por Reuters Donald Trump AndrÃ©s Manuel LÃ³pez Obrador Recibe nuestro newsletter diario con los contenidos mÃ¡s destacados de las ediciones print y digital de El Economista En las redes sociales publicamos noticias de Ãºltima hora, contenidos exclusivos y promociones. Son una vÃ­a para que estÃ©s en contacto directo con nuestra redacciÃ³n. 
														
															Por Jorge Monroy 
														
															Por Jorge Monroy 
														
															Por Elizabeth Meza RodrÃ­guez 
														
															Por Jorge Monroy 
						 						Jorge Monroy Coronavirus 
						 						Jorge Monroy Pandemia 
						 						Ricardo Quiroga Ganadora del Premio Alfaguara de Novela 2021 
						 						Magaly Olivera / ColaboraciÃ³n especial Durante la pandemia 
						 						Nelly Toche El desafÃ­o de la igualdad entre mujeres y hombres 
						 						RubÃ©n Ortega ANIVERSARIO DE PLATA  
						 						RedacciÃ³n DÃ­a Mundial de la Escritura a Mano es una empresa de Copyright Â© 1988-2015 PeriÃ³dico El Economista S.A. de C.V. All Rights Reserved. Derechos Reservados NÃºmero de reserva al TÃ­tulo en Derechos de Autor 04-2010-062510353600-203 Al visitar esta pÃ¡gina, usted estÃ¡ de acuerdo con los tÃ©rminos del servicio A travÃ©s de este formulario podrÃ¡ compartir la nota que estÃ¡ leyendo. 
				Todos los campos son obligatorios. Debes completar todos los campos. Tu nota fue enviada con Ã©xito."
""",
    """"9 diciembre, 2020 26 julio, 2020 5 mayo, 2020 9 octubre, 2019 18 agosto, 2019 11 enero, 2021 11 enero, 2021 10 enero, 2021 10 enero, 2021 10 enero, 2021 10 enero, 2021 10 enero, 2021 10 enero, 2021 7 enero, 2021 7 enero, 2021 11 enero, 2021 11 enero, 2021 11 enero, 2021 11 enero, 2021 10 enero, 2021 11 enero, 2021 11 enero, 2021 8 enero, 2021 8 enero, 2021 7 enero, 2021 10 enero, 2021 10 enero, 2021 6 enero, 2021 4 enero, 2021 18 diciembre, 2020 Por: Staff El Incorrecto / @elincorrectomx Agentes ministeriales de la regiÃƒÂ³n de Tecali de Herrera capturaron al ex policÃƒÂ­a federal que se encontraba prÃƒÂ³fugo de la justicia luego de que fuera seÃƒÂ±alado como el presunto responsable del feminicidio de su esposa Nancy N, de 31 aÃƒÂ±os de edad, el pasado 25 de febrero en el municipio antes citado. Se trata de Antonio N, de 35 aÃƒÂ±os, el cual tenÃƒÂ­a pendiente una orden de aprehensiÃƒÂ³n por el delito de feminicidio. Fuentes extraoficiales indicaron que el arresto de este hombre, quien estaba asignado al estado de Hidalgo, ocurriÃƒÂ³ este 29 de marzo en Tecali de Herrera, de donde era vecino y de donde escapÃƒÂ³ tras perpetrar el crimen. Una vez que fue detenido, el presunto asesino fue llevado ante las autoridades correspondientes a fin de que se determine su situaciÃƒÂ³n legal una vez que se lleven a cabo las audiencias correspondientes. Fue el pasado 25 de febrero cuando, la vÃƒÂ­ctima y su esposo discutieron e instantes despuÃƒÂ©s el ex policÃƒÂ­a habrÃƒÂ­a tomado un arma de fuego para dispararle en la cabeza a Nancy, cuyo cuerpo fue localizado en el baÃƒÂ±o de su domicilio. Vecinos de la zona al percatarse del crimen solicitaron la intervenciÃƒÂ³n de los paramÃƒÂ©dicos y autoridades policiacas, quienes confirmaron los hechos y encabezaron las diligencias del levantamiento de cadÃƒÂ¡ver. A partir de ese dÃƒÂ­a, el esposo de la mujer que dejÃƒÂ³ a tres pequeÃƒÂ±os en la orfandad, fue colocado como el principal sospechoso del delito. Con informaciÃƒÂ³n de e-consulta / Alberto Montero TelÃƒÂ©fono: 222 234 2314
DirecciÃƒÂ³n: Avenida JuÃƒÂ¡rez 2713, Dpto 404, La Paz, 72160, Puebla, Pue.
Mail:  [emailÂ protected] 
Este sitio web utiliza cookies para mejorar su experiencia. Asumiremos que estÃƒÂ¡ de acuerdo con esto, pero puede optar por no participar si lo desea. Aceptar Leer mas "
""",
    """"CompÃ¡rtelo Tweet CompÃ¡rtelo CompÃ¡rtelo 0 respuestas Fuera del camino se encontraron con un mototaxi inmÃ³vil y a tres personas baleadas; pidieron ayuda para los heridos, sin embargo, dos ya estaban muertos. No hay datos del agresor, salvo lo cartuchos usados que dejÃ³ su arma. En el camino En el tramo entre JuchitÃ¡n y Playa Vicente a poco menos de 500 metros de las instalaciones de tratado de aguas negras, tres personas que viajaban en un mototaxi fueron agredidas con un arma de fuego, los que escucharon pidieron policÃ­as en el lugar, de nuevo la zozobra se apoderÃ³ de ellos. A las 15:00 horas la PolicÃ­a Municipal arribÃ³, los uniformados se aproximaron hasta la unidad y reportaron que dos hombres estaban muertos. Pero necesitaban de los paramÃ©dicos porque el tercero aÃºn respiraba. Anotaron las caracterÃ­sticas de la unidad convertida en tumba: mototaxi en color rojo y con el nÃºmero econÃ³mico MT-R021. Los minutos de espera fueron eternos, cuando llegÃ³ la ambulancia, el tercer herido ya habÃ­a muerto. Ante aquel escenario dantesco se empezÃ³ la Cadena de Custodia. Municipales dieron aviso del multihomicidio a la Agencia Estatal de Investigaciones (AEI). Todos saben menos la autoridad Desde antes de la llegada de los municipales la noticia se habÃ­a esparcido; los uniformados no sabÃ­an el nombre de los tres infortunados hombres. Sin embargo, la gente sÃ­, sÃ³lo que no se los dijeron a ellos. Testigos avisaron a los familiares que fueron mÃ¡s rÃ¡pidos que los ministeriales, rompieron el perÃ­metro marcado por la lÃ­nea amarilla para enfrentar el horror que habÃ­a ante sus ojos, y les lloraron con amargura, algunos parecieron extraviar la razÃ³n en aquel llanto. Otros no perdieron tiempo y bajaron los ensangrentados cuerpos, en grupos tomaron los cadÃ¡veres y los llevaron a otro mototaxi, vehÃ­culo que se convirtiÃ³ en su Ãºltimo reposo, ante la mirada y pasividad de policÃ­as, agentes y bomberos. Nadie tuvo el valor de impedirlo. Pasajeros y conductor MÃ¡s tarde fueron identificadas las tres vÃ­ctimas: Jaime S.S., de 25 aÃ±os, y con domicilio en la colonia 25 de Mayo;Â  Pedro G.E., de 41 aÃ±os ,y de la colonia La Amistad; el tercero es Irving, de 25 aÃ±os, y vecino de la Novena SecciÃ³n. En la escena se encontraron varios casquillos percutidos de un arma calibre 45 mm, fueron recogidos y asegurados como indicios balÃ­sticos. La primeras diligencias apuntan a que hubo un agresor, pero lo que se ignora es si el multihomicida iba sobre las tres personas, por quÃ© los matÃ³ y cÃ³mo huyÃ³ del lugar. Se abrieron las carpetas de averiguaciÃ³n previa a pesar de que los cuerpos fueron extraÃ­dos del sitio por los familiares. Noticias Voz e imagen de Oaxaca Tu direcciÃ³n de correo electrÃ³nico no serÃ¡ publicada. Los campos obligatorios estÃ¡n marcados con * Comentario  Nombre *  Correo electrÃ³nico *  Web   

 Reconoce congreso a mujeres y hombres que luchan en primera lÃ­nea contra el COVID Filtran demandas y nÃºmeros de expedientes contra NicolÃ¡s Feria Romero, Presidente Municipal de Juxtlahuaca. PRD OAXACA NO IRÃ EN ALIANZA CON EL PRI EN LOS PRÃ“XIMOS COMICIOS ELECTORALES Elisa Zepeda Diputada de Morena defrauda a LÃ³pez Obrador y a los principios de la 4T Un verdadero cochinero en la administraciÃ³n de NicolÃ¡s Feria presidente de Santiago Juxtlahuca. HipÃ³crates Nolasco, el falso defensor de los mezcaleros Asesinan a sexo servidora en Bar de San Jacinto Amilpas, el flamante director de la policÃ­a Jorge MartÃ­nez permitÃ­a que el bar trabajara a puerta cerrada MANUEL VELASCO ALCÃNTARA NUEVO PRESIDENTE DEL PLENO DEL TRIBUNAL DE JUSTICIA ADMINISTRATIVA Y DE LA SALA SUPERIOR Copyright Â© 2018 LÃ­nea ejecutiva DiseÃ±o y sistemas #MakingSolutions"
"""
]


questions = [
    "[CHECK] Is the content in column C more or less identical to what you see using the weblink? Put 1 for yes, 0 for no, and 2 for unable to open URL.",
    "[CHECK] Is the title in column B more or less identical to what you see using the weblink? Put 1 for yes, 0 for no, and 2 for unable to open URL.",
    "[TOPIC] Does the article describe a homicide or other type of violent crime? Answer 'yes' if it does and 'no' if it does not.",
    "[DETAILS] Does the article provide graphic or gory details about a homicide or other type of violent crime? Answer 'yes' if the article contains graphic or gory details and 'no' if it does not; if no homicide or other type of violent crime is described, answer 'NA'.",
    "[CARTEL INVOLVED?] If the article describes a homicide or other type of violent crime, was a drug cartel or organized crime group noted as being potentially responsible for it? Answer 'yes' if a drug cartel or organized crime group is noted as being potentially responsible and 'no' if it is not; if no homicide or other type of violent crime is described, answer 'NA'.",
    "[CARTEL SENTIMENT] If the article describes a homicide or other type of violent crime and drug cartels or organized crime groups are also mentioned in the article, is the article positive, negative, or neutral toward the drug cartels or organized crime groups? Answer 'positive', 'neutral', 'negative', or 'mixed'; if no homicide or other type of violent crime is described or no drug cartel or organized crime group is mentioned, answer 'NA'.",
    "[POLICE MENTIONED] Is any branch of the Mexican police, whether municipal, state, or federal, mentioned in this article? Your answer should be either (1) 'no', if no police force is mentioned or (2) a list with the types of polices which are mentioned. For example, answer 'municipal police' if  municipal police is mentioned, 'state police' if state police is mentioned, or 'federal police' if federal police is mentioned. Your answer cannot contain any police type other than 'state police', 'municipal police' and 'federal police'. Your answer can contain more than one police types separed by the word 'and'. For example: 'state police and federal police'.",
    "[POLICE SENTIMENT] If a police force is mentioned in this article, is the article positive, neutral, or negative toward that police force? Answer 'positive', 'neutral', or 'negative'; if no police force is mentioned, answer 'NA'.",
    "[MUNICIPALITY GOVERNMENT MENTIONED] Is the municipal government of the municipality where a homicide or violent crime occurred mentioned in this article? Answer 'yes' or 'no'.",
    "[MUNICIPALITY GOVERNMENT SENTIMENT] If the municipal government is mentioned, is the article positive, neutral, or negative toward that municipal government? Answer 'positive', 'neutral', or 'negative'; if no municipal government is mentioned, answer 'NA'.",
    "[AUTHORSHIP] Is authorship of the article attributed to a single person, an editorial team, or is there no author byline? Answer either 'single person', 'general group', or 'no byline'. Don't provide any other answer other than  'single person', 'general group', or 'no byline'.",
    "[DRAMA] Is the tone of the article sensationalist or mostly factual? Answer 'sensationalist' or 'factual'.",
    "[VOICE] Does the article predominantly use active or passive voice to report on the event described? Answer 'active' or 'passive'.",
]

answers = [
    ["1", "1", "no", "NA", "NA",	"NA", "federal police",	"neutral",
        "no", "NA", "single person", "factual",	"passive"],
    ["1", "1", "no", "NA", "NA",	"NA", "no",	"NA",
        "no", "NA", "general group", "factual",	"active"],
    ["1", "1", "yes", "no", "no", "NA", "municipal",	"neutral",
        "no", "NA", "general group", "factual",	"active"],
    ["2", "2", "yes", "yes",	"no", "NA", "municipal police",
        "negative", 	"yes", "negative",	"no byline", "sensationalist",	"active"],

]

possible_answers = [
    "0|1|2",
    "0|1|2",
    "yes|no",
    "yes|no|NA",
    "yes|no|NA",
    'positive|neutral|negative|mixed|NA',
    'no|federal police|state police|municipal police|state police and municipal police|federal police and state police|federal police and munical police|federal police and state police and municipal police',
    'positive|neutral|negative|NA',
    'yes|no',
    'positive|neutral|negative|NA',
    'single person|general group|no byline',
    'sensationalist|factual',
    'active|passive'
]
